# Introduction 
This is the core serverless API functionality for Notifications.

Specifically, this API is used by any SpheraCloud application to push and store notifications / messages to users.  It also supports integration with third party providers to enable email and sms messaging as well.

This is currently version 1.0.0.  No other versions exist at the current time

See [detailed design documents for additional details](./noptifications-design.md).

# Prerequisites
This code-base is targeted for the Azure Platform and is built on node.js with typescipt and used to target Azure App Functions and the Azure API Management Services.

1.	Install node.js and typescript in the editor of choice
2.	If using Microsoft VSCode, install the Azure extensions for API Management and Azure Functions.
3.  Install testing frameworks Mocha, Chai, and NYC (code coverage).

# Configuration
Create a ```local.settings.json``` file and populate the following key value pairs or create environment variables (```process.env.XXX```) with the following:
   
   | Field | value | Format | Description                          |
| ----- |:--:| ------| -----------------------------------|
| db_server | server name | string | sql server name |
| db_database | database name | string | database name |
| db_username | sql user name | string | sql server user name |
| db_password | sql password | string | sql server user password |
| sb_conn | connection string | string | azure servicebus connection string |
| sms_accountId | id | string | provider sms account identifier |
| sms_authtoken | key | string | provider sms auth token |
| sms_sourcenumber | key | number | provider sms source number |
| sms_statushook | url | string | provider sms call back url |
| sms_statusqueue | queue name | string | provider sms send queue |
| mail_key | key | string | aprovider email key |
| mail_statusqueue | queue name | string | provider email send queue |
| cache_location | cache uri | string | cache url |
| cache_port | cache port | string | cache port |
| cache_key | cache key | string | cache access key |
| cache_expiry | cache expiry | integer | default cache expiration in seconds |

# Installing and running code locally 

1.  Clone code from the devOps repository
2.  Run the included script "rebuild" defined in package.json.  This will add all node_models required by the application.

# Running Tests

All tests are included as part of the code repository under the tests folder.  That can be run by executing the included script "test" defined within the package.json file.

The code has coverage in greater than 90% of all code paths.  Any changes to the existing code-base should include sufficient tests to maintain a 90% coverage rate.

# Deployment

The service should automatically be built and deployed to a dev environment as part of the defined devOps pipeline (CI/CD).  Optionally, the service can be deployed directly from VSCODE or Visual Studio using Azure Extensions.

# Versioning

This service is currently version 1.0.0.

| Version | Description                          | Date | Changed By |
| ------- | -------------------------------------| -----| -----------|
| 1.0.0 | Initial Version | 2019-12-01 | [Jerry Shaughnessy](mailto:jshaughnessy@spherasolutions.com) |

# Authors

* [Jerry Shaughnessy](mailto:jshaughnessy@spherasolutions.com) - *initial work*

# API Hosting references:

   * [Hosted Azure Function App](https://portal.azure.com/#blade/WebsitesExtension/FunctionsIFrameBlade/id/%2Fsubscriptions%2F3b9aa441-4ced-4007-82a9-b4d4af15d363%2FresourceGroups%2FRG_PLATFORM_DEV%2Fproviders%2FMicrosoft.Web%2Fsites%2Fplatform-sc-productentitlements-api-dev)
  
   * [Hosted API Management Gateway](https://portal.azure.com/#@spherasolutions.onmicrosoft.com/resource/subscriptions/3b9aa441-4ced-4007-82a9-b4d4af15d363/resourceGroups/RG_PLATFORM_DEV/providers/Microsoft.ApiManagement/service/platform-api-dev/overview)
  
   * [Developer Portal](https://platform-api-dev.portal.azure-api.net/)
