# Notifications Service
## Description
The Notification Service is designed and built to send and track notifications (messages) sent to users.  Messages sent through this service are stored in a repository and are available for users to browse at any time.  

Optionally, in addition to storing and displaying messages through a notifications screen, messages can also be specified to be sent via email or SMS protocols directly to a user as well.  Any message sent via an external provider are tracked and updated automatically based on factors such as sent status, delivery, read, etc...

Any SpheraCloud application can leverage this module to send and manage messages / notifications for users.
