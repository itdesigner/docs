# Notifications Messaging Operations

## General

The Notifications service interacts with the primary SpheraCloud EventHub via a topic channel 
(```NotifiationsChange```) that is restricted to a select set of registered senders.  

The private channel is *ONLY* for use by the Notifications Service at this time.  In the future, depending on needs of the organization, Calling applications can either choose to submit notifications on this topic or utilize the appropriate API endpoints, which essentially put those requests on this channel for them.  At the present time, all interatctions should only occur through the designated API endpoints.

In addition, this service utilizes four (4) internal private queue to manage interactions with external service providers for email and sms.  One each for sending messages as well as one each for receiving status events - [see logical construction for details on this interation](./notifications-logical.md).

## Security 

The primary security for the ServiceBus interactions is through the locked down publish to topic capability.  Only those applications with an authorized client id or sufficient credentials will be allowed to publish to this topic.  Additionaly, the topic publishing capability can be locked down to a specific IP white list if desired although this is not currently enabled.

## Message contract

The primary contract for all topic interactions that the service makes are identical and based on the ```Message object``` defined in the ServiceCode models folder in the project.

It consists of the following object represented as JSON:

```json

    {
        'id': 'string',
        'correlationid': 'string',
        'priority': Priority,
        'subject': string,
        'message': string,
        'source:' string,
        'deliveryType': DeliveryType,
        'recipients': Recipient[],
    }
```

See the code for more details on DeliveryType options.  The recipients is simply an array of strings each containing an email address.


