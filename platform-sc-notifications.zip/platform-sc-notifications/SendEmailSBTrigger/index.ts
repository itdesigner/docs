import { AzureFunction, Context } from "@azure/functions";
import { Email } from '../ServiceCode/providers';

const serviceBusQueueTrigger: AzureFunction = async function(context: Context, mySbMsg: any): Promise<void> {
    context.log('SendEmail ServiceBus queue trigger function processed message', mySbMsg);
    const content = JSON.parse(mySbMsg);
    if (content) {
        const mail: Email = new Email();
        const id: string = content.id;
        const to: string = content.to;
        const from: string = content.from;
        const subj: string = content.subj;
        const msg: string = content.msg;
        await mail.send(id, to, from, subj, msg);
    }
};

export default serviceBusQueueTrigger;
