import { AzureFunction, Context, HttpRequest } from "@azure/functions";
import { Configuration } from '../ServiceCode/config';
import { TopicSender } from '../ServiceCode/utilities';

const httpTrigger: AzureFunction = async function (context: Context, req: HttpRequest): Promise<void> {
    context.log('HTTP DeleteNotification trigger function processed a request.');
    if (req && req.params && req.params.id) {
        const msgId: string = req.params.id;
        const cfg: Configuration = new Configuration();
        const itemMsg = {
            id: msgId,
        }
        await TopicSender.send(itemMsg, cfg.notification_changetopic, 'notifyDeleteById');
        context.res = {
            status: 200, /* Defaults to 200 */
        };
    } else {
        context.res = {
            status: 400,
            body: 'Please pass a Message in the request body',
        };
    }
};

export default httpTrigger;
