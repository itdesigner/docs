import {IReadMany, IReadOne} from './IRead';
import {ICreate, IEdit } from './IWrite';

export {IReadOne, IReadMany, ICreate, IEdit};
