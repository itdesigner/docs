
/**
 * represents a read action that returns a single item
 */
export interface IReadOne<T> {
    /**
     * returns a single item based on its primary key
     * @param id primary key of item to find
     */
    findOne(id: number | string): Promise<T | undefined>;
}
/**
 * represents a read action that returns multiple items
 */
export interface IReadMany<T> {
    /**
     * retrieves a collection of items based on the parameters provided
     * @param key primary key to search by
     * @param limit maximum number of items to return
     * @param skip number of records to skip
     */
    find(key: number | string, limit?: number, skip?: number): Promise<T | undefined>;
    /**
     * retrieves a collection of active items based on the parameters provided
     * @param key primary key to search by
     * @param limit maximum number of items to return
     * @param skip number of records to skip
     */
    findActive(key: number | string, limit?: number, skip?: number): Promise<T | undefined>;
    /**
     * retrieves a collection of items based on the key provided
     * @param key primary key to search by
     * @param limit maximum number of items to return
     * @param skip number of records to skip
     */
    findByAlternateId(key: number | string, limit?: number, skip?: number): Promise<T | undefined>;
    /**
     * retrieves a collection of items based on the parameters provided
     * @param key primary key to search by
     * @param limit maximum number of items to return
     * @param skip number of records to skip
     */
    findByCorrelation(key: number | string, limit?: number, skip?: number): Promise<T | undefined>;
}
