
import { IdentityKey } from '../../model';

/**
 * data edit interfaces
 */
export interface IEdit<T> {
    /**
     * updates an item based on its key
     * @param id key for record to edit
     * @param item item values for the edit
     */
    update(id: number | string, item: T): Promise<boolean | undefined>;
    /**
     * deletes an item b ased on its key
     * @param id key for record to delete
     */
    delete(id: number | string): Promise<boolean | undefined>;
    /**
     * deletes an item b ased on its correlation key
     * @param id correlation key for record to delete
     */
    deleteByCorrelation(id: number | string): Promise<boolean | undefined>;
}
/**
 * data creation interfaces
 */
export interface ICreate<T> {
    /**
     * adds an item to the repository
     * @param item item to create
     */
    create(item: T): Promise<IdentityKey | boolean | undefined>;
    /**
     * adds a collection of items to a repository
     * @param items collection to add
     */
    bulkCreate(items: T[]): Promise<IdentityKey[] | boolean | undefined>;
}
