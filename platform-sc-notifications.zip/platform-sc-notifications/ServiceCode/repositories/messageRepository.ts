
import * as sql from 'mssql';
import { Collection, DeliveryType, IdentityKey, MessageDetailDTO, MessageDTO, Parameter, Status, StatusLookup } from '../model';
import {BaseRepository} from './base/BaseRepository';
import {ICreate, IEdit, IReadMany, IReadOne} from './interfaces';

/**
 * MessageDetail Datastore Repository
 *
 * @class MessageRepository
 * @extends {BaseRepository<MessageDetail>}
 * @implements {IRead<MessageDetail>}
 * @implements {IWrite<MessageDetail>}
 */
class MessageRepository extends BaseRepository implements IReadOne<MessageDetailDTO>, IReadMany<Collection<MessageDetailDTO>>, ICreate<MessageDTO>, IEdit<MessageDetailDTO> {

    /**
     * Creates an instance of MessageDetail Repository.
     * @param {sql.ConnectionPool} pool connection pool
     * @memberof MessageRepository
     */
    constructor(pool: sql.ConnectionPool) {
        super(pool);
    }

    /**
     * Adds a single MessageDetail in the datastore
     *
     * @param {MessageDTO} item
     * @returns {Promise<IdentityKey>}
     * @memberof MessageRepository
     */
    /* istanbul ignore next */
    public create(dto: MessageDTO): Promise<IdentityKey> {
        return new Promise<IdentityKey>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('correlationID', sql.UniqueIdentifier, dto.correlationid));
            params.push(new Parameter('userId', sql.UniqueIdentifier, dto.userId));
            params.push(new Parameter('email', sql.NVarChar(1000), dto.email));
            params.push(new Parameter('phone', sql.NVarChar(50), dto.phone));
            params.push(new Parameter('companyId', sql.UniqueIdentifier, dto.companyId));
            params.push(new Parameter('priority', sql.Int, dto.priority));
            params.push(new Parameter('deliverytype', sql.Int, dto.deliveryType));
            params.push(new Parameter('subject', sql.NVarChar(200), dto.subject));
            params.push(new Parameter('message', sql.NVarChar(4000), dto.message));
            params.push(new Parameter('source', sql.NVarChar(1000), dto.source));
            params.push(new Parameter('postedTime', sql.DateTime, new Date()));
            params.push(new Parameter('status', sql.Int, Status.UNPROCESSED));
            const promisedInsert = BaseRepository.executeSPQuery('usp_Notifications_Insert', params);
            promisedInsert.then((result) => {
                if (result && result.recordsets && result.recordsets.length > 0) {
                    const recordset = result.recordsets[0];
                    /* istanbul ignore else  */
                    if (recordset && recordset.length > 0) {
                        resolve(recordset[0] as IdentityKey);
                    }
                } else {
                    const err: Error = new Error('insert failed');
                    reject(err);
                }
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Bulk creates notifications in the datastore
     *
     * @param {MessageDTO[]} items
     * @returns {Promise<boolean>}
     * @memberof MessageRepository
     */
    /* istanbul ignore next  */
    public bulkCreate(items: MessageDTO[]): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            if (items && items.length > 0) {
                const table = new sql.Table('Notifications');
                table.columns.add('correlationId', sql.UniqueIdentifier, {nullable: true, primary: false});
                table.columns.add('userId', sql.UniqueIdentifier, {nullable: false, primary: false});
                table.columns.add('companyId', sql.UniqueIdentifier, {nullable: false, primary: false});
                table.columns.add('deliveryType', sql.Int, {nullable: false, primary: false});
                table.columns.add('priority', sql.Int, {nullable: false, primary: false});
                table.columns.add('subject', sql.NVarChar(200), {nullable: true, primary: false});
                table.columns.add('message', sql.NVarChar(4000), {nullable: false, primary: false});
                table.columns.add('source', sql.NVarChar(1000), {nullable: false, primary: false});
                table.columns.add('email', sql.NVarChar(2000), {nullable: true, primary: false});
                table.columns.add('phone', sql.NVarChar(50), {nullable: true, primary: false});
                table.columns.add('postedTime', sql.DateTime, {nullable: true, primary: false});
                table.columns.add('status', sql.Int, {nullable: false, primary: false});
                items.forEach((item) => {
                    const pTime: Date = new Date();
                    table.rows.add(item.correlationid, item.userId, item.companyId, item.deliveryType, item.priority, item.subject, item.message, item.source, item.email, item.phone, pTime, Status.UNPROCESSED);
                });

                const promisedBulkInsert = BaseRepository.executeBulkInsert(table);
                promisedBulkInsert.then((success) => {
                    resolve(success);
                })
                .catch((reason) => {
                    /* istanbul ignore next  */
                    reject(reason);
                });
            } else {
                reject('no messages to insert');
            }
        });
    }
    /**
     * Updates a single MessageDetail in the datastore
     *
     * @param {string} id
     * @param {MessageDetailDTO} item
     * @returns {Promise<boolean>}
     * @memberof MessageRepository
     */
    /* istanbul ignore next */
    public update(id: string, dto: MessageDetailDTO): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            params.push(new Parameter('sentTime', sql.DateTime, new Date(dto.sentTime)));
            params.push(new Parameter('deliveredTime', sql.DateTime, new Date(dto.deliveredTime)));
            params.push(new Parameter('readTime', sql.DateTime, new Date(dto.readTime)));
            params.push(new Parameter('status', sql.Int, dto.status));
            const promisedUpdate = BaseRepository.executeSPCommand('usp_Notifications_Update', params);
            promisedUpdate.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Updates a single MessageDetail in the datastore based on its FK
     *
     * @param {string} fk - foreign send key
     * @returns {Promise<boolean>}
     * @memberof MessageRepository
     */
    /* istanbul ignore next */
    public updateStatus(fk: string, source: DeliveryType, statuslookup: StatusLookup, ts: Date, status): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const stringsource: string = (source === DeliveryType.SMS) ? 'sms' : 'email';
            let statuslookupstring: string = '';
            switch (statuslookup) {
                case StatusLookup.sent:
                    statuslookupstring = 'sent';
                    break;
                case StatusLookup.delivered:
                    statuslookupstring = 'delivered';
                    break;
                case StatusLookup.read:
                    statuslookupstring = 'read';
                    break;
                case StatusLookup.deleted:
                    statuslookupstring = 'deleted';
                    break;
                default:
                    statuslookupstring = 'posted';
                    break;
            }
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('fk', sql.NVarChar(1000), fk));
            params.push(new Parameter('timestamp', sql.DateTime, new Date(ts)));
            params.push(new Parameter('type', sql.NVarChar(20), statuslookupstring));
            params.push(new Parameter('source', sql.NVarChar(20), stringsource));
            params.push(new Parameter('status', sql.Int, status));
            const promisedUpdate = BaseRepository.executeSPCommand('usp_Notifications_UpdateByFK', params);
            promisedUpdate.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * used to set any foreign keys for message tracking
     * @param smsfk - sms foreign key
     * @param emailfk - email foreign key
     * @param id - message id
     */
    public updateFK(id: string, emailfk: string, smsfk: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            params.push(new Parameter('smsFK', sql.NVarChar(1000), smsfk));
            params.push(new Parameter('emailFK', sql.NVarChar(1000), emailfk));
            const promisedUpdate = BaseRepository.executeSPCommand('usp_Notifications_UpdateFK', params);
            promisedUpdate.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Deletes a single MessageDetail from the datastore
     *
     * @param {string} id
     * @returns {Promise<boolean>}
     * @memberof MessageRepository
     */
    /* istanbul ignore next */
    public delete(id: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            const spName: string = 'usp_Notifications_Delete';
            const promisedDelete = BaseRepository.executeSPCommand(spName, params);
            promisedDelete.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Deletes a collection of MessageDetail from the datastore by CorrelationId
     *
     * @param {string} id
     * @returns {Promise<boolean>}
     * @memberof MessageRepository
     */
    /* istanbul ignore next */
    public deleteByCorrelation(id: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('correlationId', sql.UniqueIdentifier, id));
            const spName: string = 'usp_Notifications_DeleteByCorrelation';
            const promisedDelete = BaseRepository.executeSPCommand(spName, params);
            promisedDelete.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Retrieves all items from the datastore for a given id (userid)
     * @param id user id
     * @param limit number of notifications to return
     * @param skip number of notifications to skip
     */
    public find(id: string, limit?: number, skip?: number): Promise<Collection<MessageDetailDTO>> {
        return new Promise<Collection<MessageDetailDTO>>((resolve, reject) => {
            let collection: Collection<MessageDetailDTO>;
            const items: MessageDetailDTO[] = new Array<MessageDetailDTO>();
            const params: Parameter[] = new Array<Parameter>();
            if (limit != null) {
                params.push(new Parameter('limit', sql.Int, limit));
            }
            if (skip != null) {
                params.push(new Parameter('skip', sql.Int, skip));
            }
            if (id != null) {
                params.push(new Parameter('userId', sql.UniqueIdentifier, id));
            } else {
                reject('invalid user id supplied');
            }
            const promisedResult = BaseRepository.executeSPQuery('usp_getNotifications_ByUserId', params);
            promisedResult.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            const r = MessageDetailDTO.Clone(row as MessageDetailDTO);
                            items.push(r);
                        });
                    });
                    collection = new Collection<MessageDetailDTO>(items, items.length, result.returnValue);
                }
                resolve(collection);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Retrieves all non-deleted messages for a user from the datastore
     * @param id user id
     * @param limit number of notifications to return
     * @param skip number of notifications to skip
     */
    public findActive(id: string, limit?: number, skip?: number): Promise<Collection<MessageDetailDTO>> {
        return new Promise<Collection<MessageDetailDTO>>((resolve, reject) => {
            let collection: Collection<MessageDetailDTO>;
            const items: MessageDetailDTO[] = new Array<MessageDetailDTO>();
            const params: Parameter[] = new Array<Parameter>();
            if (limit) {
                params.push(new Parameter('limit', sql.Int, limit));
            }
            if (skip) {
                params.push(new Parameter('skip', sql.Int, skip));
            }
            if (id) {
                params.push(new Parameter('userId', sql.UniqueIdentifier, id));
            } else {
                reject('invalid id supplied');
            }
            const promisedProjects = BaseRepository.executeSPQuery('usp_getNotifications_Active_ByUserId', params);
            promisedProjects.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            const r = MessageDetailDTO.Clone(row as MessageDetailDTO);
                            items.push(r);
                        });
                    });
                    collection = new Collection<MessageDetailDTO>(items, items.length, result.returnValue);
                }
                resolve(collection);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Retrieves all items from the datastore for a given alternate (company) id
     * @param id companyid
     * @param limit number of notifictions to return
     * @param skip number of notifications to skip
     */
    public findByAlternateId(id: string, limit?: number, skip?: number): Promise<Collection<MessageDetailDTO>> {
        return new Promise<Collection<MessageDetailDTO>>((resolve, reject) => {
            let collection: Collection<MessageDetailDTO>;
            const items: MessageDetailDTO[] = new Array<MessageDetailDTO>();
            const params: Parameter[] = new Array<Parameter>();
            if (limit != null) {
                params.push(new Parameter('limit', sql.Int, limit));
            }
            if (skip != null) {
                params.push(new Parameter('skip', sql.Int, skip));
            }
            if (id != null) {
                params.push(new Parameter('companyId', sql.UniqueIdentifier, id));
            } else {
                reject('invalid company id supplied');
            }
            const promisedResult = BaseRepository.executeSPQuery('usp_getNotifications_ByCompanyId', params);
            promisedResult.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            const r = MessageDetailDTO.Clone(row as MessageDetailDTO);
                            items.push(r);
                        });
                    });
                    collection = new Collection<MessageDetailDTO>(items, items.length, result.returnValue);
                }
                resolve(collection);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Retrieves all items from the datastore for a given correlation id
     * @param id correlation id
     * @param limit maximjm number of records to return
     * @param skip number of records to skip
     */
    public findByCorrelation(id: string, limit?: number, skip?: number): Promise<Collection<MessageDetailDTO>> {
        return new Promise<Collection<MessageDetailDTO>>((resolve, reject) => {
            let collection: Collection<MessageDetailDTO>;
            const items: MessageDetailDTO[] = new Array<MessageDetailDTO>();
            const params: Parameter[] = new Array<Parameter>();
            if (limit) {
                params.push(new Parameter('limit', sql.Int, limit));
            }
            if (skip) {
                params.push(new Parameter('skip', sql.Int, skip));
            }
            if (id) {
                params.push(new Parameter('correlationId', sql.UniqueIdentifier, id));
            } else {
                reject('invalid correlation id supplied');
            }
            const promisedResult = BaseRepository.executeSPQuery('usp_getNotifications_ByCorrelationId', params);
            promisedResult.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            const r = MessageDetailDTO.Clone(row as MessageDetailDTO);
                            items.push(r);
                        });
                    });
                    collection = new Collection<MessageDetailDTO>(items, items.length, result.returnValue);
                }
                resolve(collection);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Retrieves a specific MessageDetail from the datastore
     * @param id notification id
     */
    public findOne(id: string): Promise<MessageDetailDTO> {
        return new Promise<MessageDetailDTO>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            const promisedProjects = BaseRepository.executeSPQuery('usp_getNotifications_ById', params);
            promisedProjects.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets && result.recordsets.length > 0) {
                    const recordset = result.recordsets[0];
                    if (recordset && recordset.length > 0) {
                        const r = MessageDetailDTO.Clone(recordset[0] as MessageDetailDTO);
                        resolve(r);
                    } else {
                        const err: Error = new Error('item not found');
                        reject(err);
                    }
                } else {
                    const err: Error = new Error('item not found');
                    reject(err);
                }
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
}

export {MessageRepository as MessageRepository};
