
import * as sql from 'mssql';
import {Connection, Request, TYPES} from 'tedious';
import {Parameter} from '../../model';

/**
 * base repository class that executes actions against a repository
 */
class BaseRepository {

    /**
     * the connection pool
     */
    public static pool: sql.ConnectionPool;

    /**
     * executes a stored procedure that returns a result set
     * @param spName stored procedure name
     * @param parameters parameters array for the stored procedure
     */
    public static async executeSPQuery(spName: string, parameters: Parameter[]) {
        await BaseRepository.pool;
        try {
            const req: sql.Request = BaseRepository.pool.request();
            /* istanbul ignore else  */
            if (parameters) {
                parameters.forEach((p) => {
                    req.input(p.name, p.type, p.value);
                });
            }
            const result = await req.execute(spName);
            /* istanbul ignore else  */
            if (result) {
                return result;
            } else {
                return undefined;
            }
        } catch (err) {
            /* istanbul ignore next  */
            return undefined;
        }
    }
    /**
     * executes a stored procedure command against a repository
     * @param spName stored procedure name
     * @param parameters paramter collection for specified stored procedure
     */
    /* istanbul ignore next  */
    public static async executeSPCommand(spName: string, parameters: Parameter[]) {
        await BaseRepository.pool;
        try {
            const req: sql.Request = BaseRepository.pool.request();
            /* istanbul ignore else  */
            if (parameters) {
                parameters.forEach((p) => {
                    req.input(p.name, p.type, p.value);
                });
            }
            const result = await req.execute(spName);
            /* istanbul ignore else  */
            if (result) {
                /* istanbul ignore else  */
                if (result.returnValue === 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (err) {
            /* istanbul ignore next  */
            return undefined;
        }
    }
    /**
     * provides a method for performing a bulk insert into a repository
     * @param table a table to be bulk inserted
     */
    /* istanbul ignore next  */
    public static async executeBulkInsert(table: sql.Table) {
        await BaseRepository.pool;
        try {
            if (table != null) {
                const req: sql.Request = BaseRepository.pool.request();
                const result = await req.bulk(table);
                if (result) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (err) {
            /* istanbul ignore next  */
            return undefined;
        }
    }

    /**
     * constructor
     * @param pool connection pool
     */
    constructor(pool: sql.ConnectionPool) {
        BaseRepository.pool = pool;
    }

}
export  {BaseRepository};
