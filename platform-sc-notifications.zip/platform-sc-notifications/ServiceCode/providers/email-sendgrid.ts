import sgMail from '@sendgrid/mail';
import * as sql from 'mssql';
import { Configuration } from '../config';
import { IdentityKey } from '../model/identitykey';
import { MessageRepository } from '../repositories';
import {IEmail} from './interfaces';

export class Email {
    private cfg: Configuration = new Configuration();
    private pool: sql.ConnectionPool;

    public async send(msgId: string, toAddress: string, fromAddress: string, subj: string, msg: string) {
        let key: IdentityKey;
        const cfg: Configuration = new Configuration();
        sgMail.setApiKey(cfg.mail_key);
        const message = {
            to: toAddress,
            from: fromAddress,
            subject: subj,
            text: msg,
            html: msg,
        };
        const result = await sgMail.send(message);
        const status: number = result[0].statusCode;
        const emailId: string | string[] = result[0].headers['x-message-id'];
        if (typeof emailId === 'string') {
            await this.updateFK(msgId, emailId);
        } else {
            // tslint:disable-next-line: no-console
            console.log('more than one id returned');
        }
        return result;
    }
    /**
     * creates a connection pool
     * @param config config object
     */
    private async createPool(config: sql.config) {
        const initPool = new sql.ConnectionPool(config);
        this.pool = await initPool.connect();
    }
    private async updateFK(msgId: string, emailId: string) {
        this.createPool(this.cfg.db_config).then(async () => {
            const repo: MessageRepository = new MessageRepository(this.pool);
            const result =  await repo.updateFK(msgId, emailId, null);
            return result;
        }).catch((err) => {
            console.error('error occurred => ' + err);
        });
    }
}
