
export enum TwilioStatus {
    accepted,
    queued,
    sending,
    sent,
    failed,
    delivered,
    undelivered,
    receiving,
    received,
    read,
}
