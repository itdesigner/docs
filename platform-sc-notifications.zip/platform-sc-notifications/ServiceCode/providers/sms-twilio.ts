
import * as sql from 'mssql';
import twilio = require('twilio');
import { Configuration } from '../config';
import { MessageRepository } from '../repositories';

export class SMS {
    private cfg: Configuration = new Configuration();
    private pool: sql.ConnectionPool;

    public async send(msgId: string, toPhone: string, msg: string): Promise<string> {
        const cfg: Configuration = new Configuration();
        const client = twilio(cfg.sms_accountid, cfg.sms_authtoken);
        if (!toPhone.startsWith('+')) { toPhone = '+' + toPhone; }
        try {
            const response = await client.messages.create({
                body: msg,
                from: cfg.sms_sourcenumber,
                to: toPhone,
                statusCallback: cfg.sms_statushook,
            });
            await this.updateFK(msgId, response.sid);
            return response.sid;
        } catch (err) {
            console.error(err);
        }
    }
    /**
     * creates a connection pool
     * @param config config object
     */
    private async createPool(config: sql.config) {
        const initPool = new sql.ConnectionPool(config);
        this.pool = await initPool.connect();
    }
    private async updateFK(msgId: string, smsId: string) {
        this.createPool(this.cfg.db_config).then(async () => {
            const repo: MessageRepository = new MessageRepository(this.pool);
            console.log('inside update FK');
            const result =  await repo.updateFK(msgId, null, smsId);
            console.log('post update');
            return result;
        }).catch((err) => {
            console.error('error occurred => ' + err);
        });
    }
}
