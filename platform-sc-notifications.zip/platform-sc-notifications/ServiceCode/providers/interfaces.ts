import { IdentityKey } from '../model';

export interface IEmail {
    send(to: string, from: string, subj: string, body: string): Promise<IdentityKey>;
}
export interface ISms {
    send(to: string, msg: string): Promise<IdentityKey>;
}