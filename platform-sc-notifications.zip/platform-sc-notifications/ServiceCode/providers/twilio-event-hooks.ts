
import * as sql from 'mssql';
import * as twilio from 'twilio';
import { Configuration } from '../config';
import { Collection, DeliveryType, IdentityKey, Link, linkTypeEnum, Message, MessageDetail, MessageDetailDTO, MessageDTO, Status, StatusLookup } from '../model';
import { MessageRepository } from '../repositories';
import { TwilioStatus } from './twilio-enumerations';

export class TwilioStatusProcessor {
    private cfg: Configuration = new Configuration();
    private pool: sql.ConnectionPool;


    public async processHook(content: any) {
        const msgId: string = content.sms_id;
        const smsStatus = content.event;
        const eventTime = content.timestamp;
        if (msgId != null && smsStatus != null) {
            const status: TwilioStatus = TwilioStatus[smsStatus as keyof typeof TwilioStatus];

            switch (status) {
                case TwilioStatus.sent:
                    await this.updateStatus(msgId, DeliveryType.SMS, StatusLookup.sent, Status.SENT);
                    break;
                case TwilioStatus.delivered:
                    await this.updateStatus(msgId, DeliveryType.SMS, StatusLookup.delivered, Status.DELIVERED);
                    break;
                case TwilioStatus.read:
                    await this.updateStatus(msgId, DeliveryType.SMS, StatusLookup.read, Status.READ);
                    break;
                case TwilioStatus.undelivered:
                    break;
                case TwilioStatus.failed:
                    break;
            }
        }
    }
    /**
     * creates a connection pool
     * @param config config object
     */
    private async createPool(config: sql.config) {
        const initPool = new sql.ConnectionPool(config);
        this.pool = await initPool.connect();
    }
    private async updateStatus(msgId: string, deliveryType: DeliveryType, statuslookup: StatusLookup, status: Status) {
        this.createPool(this.cfg.db_config).then(async () => {
            const repo: MessageRepository = new MessageRepository(this.pool);
            return repo.updateStatus(msgId, deliveryType, statuslookup, new Date(), status);
        }).catch((err) => {
            console.error('error occurred => ' + err);
        });
    }
}


