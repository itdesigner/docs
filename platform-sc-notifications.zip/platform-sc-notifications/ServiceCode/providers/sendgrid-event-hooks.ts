import { AzureFunction, Context, HttpRequest } from '@azure/functions';
import * as sql from 'mssql';
import * as twilio from 'twilio';
import { Configuration } from '../config';
import { Collection, DeliveryType, IdentityKey, Link, linkTypeEnum, Message, MessageDetail, MessageDetailDTO, MessageDTO, Status, StatusLookup } from '../model';
import { MessageRepository } from '../repositories';

export class SendgridStatusProcessor {
    private cfg: Configuration = new Configuration();
    private pool: sql.ConnectionPool;


    public async processHook(content: any, context: Context) {
        let smsStatus: string = null;
        let msgId: string = null;
        let ts: Date;
        context.log(content);
        // content from sendgrid is an array object at this point

        content.forEach(async (eventhook) => {
            const eventType: string = eventhook.event;
            const emailId: string = eventhook.sg_message_id.split('.filter')[0];   // up to the firt .filter
            const ts: Date = await this.convertToDate(eventhook.timestamp);
            switch (eventType) {
                case 'processed':
                    await this.updateStatus(emailId, DeliveryType.EMAIL, StatusLookup.sent, Status.SENT, ts);
                    break;
                case 'delivered':
                    await this.updateStatus(emailId, DeliveryType.EMAIL, StatusLookup.delivered, Status.DELIVERED, ts);
                    break;
                case 'opened':
                    await this.updateStatus(emailId, DeliveryType.EMAIL, StatusLookup.read, Status.READ, ts);
                    break;
            }
        });
    }
    /**
     * creates a connection pool
     * @param config config object
     */
    private async createPool(config: sql.config) {
        const initPool = new sql.ConnectionPool(config);
        this.pool = await initPool.connect();
    }
    private async updateStatus(msgId: string, deliveryType: DeliveryType, statuslookup: StatusLookup, status: Status, ts: Date) {
        this.createPool(this.cfg.db_config).then(async () => {
            const repo: MessageRepository = new MessageRepository(this.pool);
            return repo.updateStatus(msgId, deliveryType, statuslookup, ts, status);
        }).catch((err) => {
            console.error('error occurred => ' + err);
        });
    }
    private async cleanInt(x) {
        x = Number(x);
        return x >= 0 ? Math.floor(x) : Math.ceil(x);
    }
    private async convertToDate(x) {
        const d = await this.cleanInt(x) * 1000;
        return new Date(d);
    }
}


