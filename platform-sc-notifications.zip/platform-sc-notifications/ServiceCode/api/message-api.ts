
import * as sql from 'mssql';
import { Configuration } from '../config';
import { Collection, IdentityKey, Link, linkTypeEnum, Message, MessageDetail, MessageDetailDTO, MessageDTO, DeliveryType } from '../model';
import { MessageRepository } from '../repositories';
import { QueueSender } from '../utilities/queue-sender';

/**
 * the notifications / messaging api
 */
export class MessageAPI {

    private cfg: Configuration = new Configuration();
    private pool: sql.ConnectionPool;

    /* ******************************** */
    /* ******** FIND METHODS ********** */
    /* ******************************** */

    /**
     * returns notifications for a user, active and deleted
     * @param id user id
     * @param activeOnly restrict to only non-deleted notifications
     * @param limit maximum number of records to return
     * @param skip number of records to skip
     */
    public async GetUserNotifications(id: string, activeOnly: boolean, limit?: number, skip?: number): Promise<Collection<MessageDetail>> {
        if (activeOnly) {
            return this.GetActiveUserNotifications(id, limit, skip);
        } else {
            return this.GetAllUserNotifications(id, limit, skip);
        }
    }
    /**
     * returns all notifications for a company, active and deleted
     * @param id company id
     * @param limit maximum number of records to return
     * @param skip number of records to skip
     */
    public async GetNotificationsByCompany(id: string, limit?: number, skip?: number): Promise<Collection<MessageDetail>> {
        return new Promise<Collection<MessageDetail>>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                if (!limit) { limit = 100; }
                if (!skip) { skip = 0; }
                const resultMessages: Collection<MessageDetail> = Collection.Empty<MessageDetail>();
                const repo: MessageRepository = new MessageRepository(this.pool);
                repo.findByAlternateId(id, limit, skip).then((collection) => {
                    const items: MessageDetailDTO[] = collection.items;
                    items.forEach((element) => {
                        const dm: MessageDetail = element.toMessage();
                        const l: Link = new Link('/api/notifications/' + element.id, 'self', linkTypeEnum.GET);
                        dm.links = new Array<Link>(l);
                        resultMessages.items.push(dm);
                    });
                    resultMessages.itemCount = collection.itemCount;
                    resultMessages.totalCount = collection.totalCount;
                    if (limit != null && skip != null) {
                        if (collection.totalCount > skip + limit) {
                            const nextSkip: number = skip + limit;
                            const lnext: Link = new Link('/api/notifications/company?limit=' + limit + '&skip=' + nextSkip, 'next', linkTypeEnum.GET);
                            collection.addLink(lnext);
                        }
                        if (skip > 0) {
                            const prevSkip = ((skip - limit) > 0) ? (skip - limit) : 0;
                            const lprev: Link = new Link('/api/notifications/company?limit=' + limit + '&skip=' + prevSkip, 'previous', linkTypeEnum.GET);
                            collection.addLink(lprev);
                        }
                    }
                    resolve(resultMessages);
                })
                .catch((err) => {
                    reject(err);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * returns all notifications for a correlation, active and deleted
     * @param id correlation id
     * @param limit maximum number of records to return
     * @param skip number of records to skip
     */
    public async GetNotificationsByCorrelation(id: string, limit?: number, skip?: number): Promise<Collection<MessageDetail>> {
        return new Promise<Collection<MessageDetail>>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                if (!limit) { limit = 100; }
                if (!skip) { skip = 0; }
                const resultMessages: Collection<MessageDetail> = Collection.Empty<MessageDetail>();
                const repo: MessageRepository = new MessageRepository(this.pool);
                repo.findByCorrelation(id, limit, skip).then((collection) => {
                    const items: MessageDetailDTO[] = collection.items;
                    items.forEach((element) => {
                        const dm: MessageDetail = element.toMessage();
                        const l: Link = new Link('/api/notifications/' + element.id, 'self', linkTypeEnum.GET);
                        dm.links = new Array<Link>(l);
                        resultMessages.items.push(dm);
                    });
                    resultMessages.itemCount = collection.itemCount;
                    resultMessages.totalCount = collection.totalCount;
                    if (limit != null && skip != null) {
                        if (collection.totalCount > skip + limit) {
                            const nextSkip: number = skip + limit;
                            const lnext: Link = new Link('/api/notifications/company?limit=' + limit + '&skip=' + nextSkip, 'next', linkTypeEnum.GET);
                            collection.addLink(lnext);
                        }
                        if (skip > 0) {
                            const prevSkip = ((skip - limit) > 0) ? (skip - limit) : 0;
                            const lprev: Link = new Link('/api/notifications/company?limit=' + limit + '&skip=' + prevSkip, 'previous', linkTypeEnum.GET);
                            collection.addLink(lprev);
                        }
                    }
                    resolve(resultMessages);
                })
                .catch((err) => {
                    reject(err);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * returns a specifc notification
     * @param id notification id
     */
    public async GetNotificationById(id: string): Promise<MessageDetail> {
        return new Promise<MessageDetail>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: MessageRepository = new MessageRepository(this.pool);
                repo.findOne(id).then((item) => {
                    const dm: MessageDetail = item.toMessage();
                    const l: Link = new Link('/api/notifications/' + item.id, 'self', linkTypeEnum.GET);
                    dm.links = new Array<Link>(l);
                    resolve(dm);
                })
                .catch((err) => {
                    reject(err);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /* ******************************** */
    /* ********* ADD METHODS ********** */
    /* ******************************** */

    /**
     * adds a notification to the system
     * @param item a message object
     */
    public async AddNotification(item: Message): Promise<IdentityKey[]> {
        return new Promise<IdentityKey[]>((resolve, reject) => {
            const results: IdentityKey[] = new Array<IdentityKey>();
            this.createPool(this.cfg.db_config).then(() => {
                const repo: MessageRepository = new MessageRepository(this.pool);
                const dtos: Collection<MessageDTO> = MessageDTO.CreateFromMessage(item);
                dtos.items.forEach((mdto) => {
                    repo.create(mdto).then(async (key: IdentityKey) => {
                        results.push(key);
                        // check whether we need to queue a provider send event here
                        if (item.deliveryType === DeliveryType.EMAIL) {
                            const mailItem = {
                                id: key.id,
                                to: mdto.email,
                                from: this.cfg.mail_sender,
                                subj: mdto.subject,
                                msg: mdto.message,
                            };
                            await QueueSender.send(mailItem, this.cfg.mail_sendqueue, 'sendmail');
                        } else if (item.deliveryType === DeliveryType.SMS) {
                            const smsItem = {
                                id: key.id,
                                to: mdto.phone,
                                msg: mdto.message,
                            };
                            await QueueSender.send(smsItem, this.cfg.sms_sendqueue, 'sendsms');
                        } else {
                            // no further actions nexessary
                        }
                        if (results.length === dtos.items.length) {
                            resolve(results);
                        }
                    })
                    .catch((sqlErr) => {
                        reject(sqlErr);
                    });
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /* ******************************** */
    /* ******* UPDATE METHODS ********* */
    /* ******************************** */

    /**
     * updates an existing notification in the system
     * @param item notification to update
     */
    public async UpdateNotification(item: MessageDetail): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            if (item.recipients.length > 1) { reject('only one message can be updated at a time'); }
            this.createPool(this.cfg.db_config).then(() => {
                const repo: MessageRepository = new MessageRepository(this.pool);
                const dto: MessageDetailDTO = MessageDetailDTO.CreateFromMessageDetail(item).items[0];
                repo.update(dto.id, dto).then((response: boolean) => {
                    resolve(response);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /* ******************************** */
    /* ******* DELETE METHODS ********* */
    /* ******************************** */

    /**
     * deletes a notification by id
     * @param id notification id
     */
    public async DeleteNotification(id: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: MessageRepository = new MessageRepository(this.pool);
                repo.delete(id).then((response: boolean) => {
                    resolve(response);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * deletes one or more messages having a specific correlation id
     * @param id correlation id
     */
    public async DeleteNotificationByCorrelation(id: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: MessageRepository = new MessageRepository(this.pool);
                repo.deleteByCorrelation(id).then((response: boolean) => {
                    resolve(response);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /**
     * returns all notifications for a user, active and deleted
     * @param id user id
     * @param limit maximum number of records to return
     * @param skip number of records to skip
     */
    private async GetAllUserNotifications(id: string, limit?: number, skip?: number): Promise<Collection<MessageDetail>> {
        return new Promise<Collection<MessageDetail>>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                if (!limit) { limit = 100; }
                if (!skip) { skip = 0; }
                const resultMessages: Collection<MessageDetail> = Collection.Empty<MessageDetail>();
                const repo: MessageRepository = new MessageRepository(this.pool);
                repo.find(id, limit, skip).then((collection) => {
                    const items: MessageDetailDTO[] = collection.items;
                    items.forEach((element) => {
                        const dm: MessageDetail = element.toMessage();
                        const l: Link = new Link('/api/notifications/' + element.id, 'self', linkTypeEnum.GET);
                        dm.links = new Array<Link>(l);
                        resultMessages.items.push(dm);
                    });
                    resultMessages.itemCount = collection.itemCount;
                    resultMessages.totalCount = collection.totalCount;
                    if (limit != null && skip != null) {
                        if (collection.totalCount > skip + limit) {
                            const nextSkip: number = skip + limit;
                            const lnext: Link = new Link('/api/notifications?limit=' + limit + '&skip=' + nextSkip, 'next', linkTypeEnum.GET);
                            collection.addLink(lnext);
                        }
                        if (skip > 0) {
                            const prevSkip = ((skip - limit) > 0) ? (skip - limit) : 0;
                            const lprev: Link = new Link('/api/notifications?limit=' + limit + '&skip=' + prevSkip, 'previous', linkTypeEnum.GET);
                            collection.addLink(lprev);
                        }
                    }
                    resolve(resultMessages);
                })
                .catch((err) => {
                    reject(err);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * returns all notifications for a user, active only
     * @param id user id
     * @param limit maximum number of records to return
     * @param skip number of records to skip
     */
    private async GetActiveUserNotifications(id: string, limit?: number, skip?: number): Promise<Collection<MessageDetail>> {
        return new Promise<Collection<MessageDetail>>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                if (!limit) { limit = 100; }
                if (!skip) { skip = 0; }
                const resultMessages: Collection<MessageDetail> = Collection.Empty<MessageDetail>();
                const repo: MessageRepository = new MessageRepository(this.pool);
                repo.findActive(id, limit, skip).then((collection) => {
                    const items: MessageDetailDTO[] = collection.items;
                    items.forEach((element) => {
                        const dm: MessageDetail = element.toMessage();
                        const l: Link = new Link('/api/notifications/' + element.id, 'self', linkTypeEnum.GET);
                        dm.links = new Array<Link>(l);
                        resultMessages.items.push(dm);
                    });
                    resultMessages.itemCount = collection.itemCount;
                    resultMessages.totalCount = collection.totalCount;
                    if (limit != null && skip != null) {
                        if (collection.totalCount > skip + limit) {
                            const nextSkip: number = skip + limit;
                            const lnext: Link = new Link('/api/notifications?limit=' + limit + '&skip=' + nextSkip, 'next', linkTypeEnum.GET);
                            collection.addLink(lnext);
                        }
                        if (skip > 0) {
                            const prevSkip = ((skip - limit) > 0) ? (skip - limit) : 0;
                            const lprev: Link = new Link('/api/notifications?limit=' + limit + '&skip=' + prevSkip, 'previous', linkTypeEnum.GET);
                            collection.addLink(lprev);
                        }
                    }
                    resolve(resultMessages);
                })
                .catch((err) => {
                    reject(err);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /**
     * creates a connection pool
     * @param config config object
     */
    private async createPool(config: sql.config) {
        const initPool = new sql.ConnectionPool(config);
        this.pool = await initPool.connect();
    }

}
