
import { ServiceBusClient } from '@azure/service-bus';
import { Configuration } from '../config';

export class TopicSender {
    public static async send(content: string | {}, topicname: string, itemLabel: string) {
        const cfg: Configuration = new Configuration();
        const sbClient = ServiceBusClient.createFromConnectionString(cfg.sb_conn);
        const tClient = sbClient.createTopicClient(topicname);
        const sender = tClient.createSender();
        const item = {
            body: (typeof content === 'string') ? content : JSON.stringify(content),
            label: itemLabel,
        };
        await sender.send(item);
    }
}
