
import { ServiceBusClient } from '@azure/service-bus';
import { Configuration } from '../config';

export class QueueSender {
    public static async send(content: string | {}, queuename: string, itemLabel: string) {
        const cfg: Configuration = new Configuration();
        const sbClient = ServiceBusClient.createFromConnectionString(cfg.sb_conn);
        const qClient = sbClient.createQueueClient(queuename);
        const sender = qClient.createSender();
        const item = {
            body: (typeof content === 'string') ? content : JSON.stringify(content),
            label: itemLabel,
        };
        await sender.send(item);
    }
}
