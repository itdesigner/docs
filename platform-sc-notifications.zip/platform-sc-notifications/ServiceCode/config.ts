
import * as sql from 'mssql';

/**
 * The configuration handler
 */
export class Configuration {
    private _sql_username: string;
    private _sql_password: string;
    private _sql_server: string;
    private _sql_database: string;
    private _sb_uri: string;
    private _sb_channel: string;
    private _sb_conn: string;
    private _cache_key: string;
    private _cache_location: string;
    private _cache_port: number;
    private _cache_expiry: number;
    private _sms_accountid: string;
    private _sms_authtoken: string;
    private _sms_sourcenumber: string;
    private _sms_statushook: string;
    private _sms_statusqueue: string;
    private _sms_sendqueue: string;
    private _mail_statusqueue: string;
    private _mail_key: string;
    private _mail_sendqueue: string;
    private _mail_sender: string;
    private _notification_changetopic: string;
    /**
     * constructor for the configuration class
     */
    constructor() {
        this._sql_database = process.env.db_database;
        this._sql_server = process.env.db_server;
        this._sql_username = process.env.db_username;
        this._sql_password = process.env.db_password;
        this._sb_uri = process.env.sb_uri;
        this._sb_channel = process.env.sb_channel;
        this._sb_conn = process.env.sb_conn;
        this._cache_location = process.env.cache_location;
        this._cache_port = Number(process.env.cache_port);
        this._cache_key = process.env.cache_key;
        this._cache_expiry = Number(process.env.cache_expiry);
        this._sms_accountid = process.env.sms_accountid;
        this._sms_authtoken = process.env.sms_authtoken;
        this._sms_sourcenumber = process.env.sms_sourcenumber;
        this._sms_statushook = process.env.sms_statushook;
        this._sms_sendqueue = process.env.sms_sendqueue;
        this._mail_key = process.env.mail_key;
        this._sms_statusqueue = process.env.sms_statusqueue;
        this._mail_statusqueue = process.env.mail_statusqueue;
        this._mail_sendqueue = process.env.mail_sendqueue;
        this._mail_sender = process.env.mail_sender;
        this._notification_changetopic = process.env.notification_changetopic;
    }

    /**
     * getter for cache default expiration time
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    /* istanbul ignore next  */
    get cache_expiry(): number {
        /* istanbul ignore else */
        if (!this._cache_expiry) {
            this._cache_expiry = Number(process.env.cache_location);
        }
        return this._cache_expiry;
    }
    /**
     * getter for cache location
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    /* istanbul ignore next  */
    get cache_location(): string {
        /* istanbul ignore else */
        if (!this._cache_location) {
            this._cache_location = process.env.cache_location;
        }
        return this._cache_location;
    }
    /**
     * getter for cache port
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    /* istanbul ignore next  */
    get cache_port(): number {
        /* istanbul ignore else */
        if (!this._cache_port) {
            this._cache_port = Number(process.env.cache_port);
        }
        return this._cache_port;
    }
    /**
     * getter for cache key
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    /* istanbul ignore next  */
    get cache_key(): string {
        /* istanbul ignore else */
        if (!this._cache_key) {
            this._cache_key = process.env.cache_key;
        }
        return this._cache_key;
    }
    /**
     * getter for sql server
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    get sql_server(): string {
        /* istanbul ignore else  */
        if (!this._sql_server) {
            this._sql_server = process.env.db_server;
        }
        return this._sql_server;
    }
    /**
     * getter for database name
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    get sql_database(): string {
        /* istanbul ignore else  */
        if (!this._sql_database) {
            this._sql_database = process.env.db_database;
        }
        return this._sql_database;
    }
    /**
     * database user
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    get sql_username(): string {
        /* istanbul ignore else  */
        if (!this._sql_username) {
            this._sql_username = process.env.db_username;
        }
        return this._sql_username;
    }
    /**
     * database password
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    get sql_password(): string {
        /* istanbul ignore else  */
        if (!this._sql_password) {
            this._sql_password = process.env.db_password;
        }
        return this._sql_password;
    }
    /* istanbul ignore next  */
    get sb_channel(): string {
        if (!this._sb_channel) {
            this._sb_channel = process.env.sb_uri;
        }
        return this._sb_channel;
    }
    /* istanbul ignore next  */
    get sb_uri(): string {
        if (!this._sb_uri) {
            this._sb_uri = process.env.sb_channel;
        }
        return this._sb_uri;
    }
    get sb_conn(): string {
        if (!this._sb_conn) {
            this._sb_conn = process.env.sb_conn;
        }
        return this._sb_conn;
    }
    get db_config(): sql.config {
        return {
            user: this.sql_username,
            password: this.sql_password,
            server: this.sql_server,
            database: this.sql_database,
            options: {
                encrypt: true,
            }
        }
    }
    get sms_accountid(): string {
        if (!this._sms_accountid) {
            this._sms_accountid = process.env.sms_accountidl;
        }
        return this._sms_accountid;
    }
    get sms_authtoken(): string {
        if (!this._sms_authtoken) {
            this._sms_authtoken = process.env.sms_authtoken;
        }
        return this._sms_authtoken;
    }
    get sms_sourcenumber(): string {
        if (!this._sms_sourcenumber) {
            this._sms_sourcenumber = process.env.sms_sourcenumber;
        }
        return this._sms_sourcenumber;
    }
    get sms_statushook(): string {
        if (!this._sms_statushook) {
            this._sms_statushook = process.env.sms_statushook;
        }
        return this._sms_statushook;
    }
    get sms_statusqueue(): string {
        if (!this._sms_statusqueue) {
            this._sms_statusqueue = process.env.sms_statusqueue;
        }
        return this._sms_statusqueue;
    }
    get sms_sendqueue(): string {
        if (!this._sms_sendqueue) {
            this._sms_sendqueue = process.env.sms_sendqueue;
        }
        return this._sms_sendqueue;
    }
    get mail_statusqueue(): string {
        if (!this._mail_statusqueue) {
            this._mail_statusqueue = process.env.mail_statusqueue;
        }
        return this._mail_statusqueue;
    }
    get mail_key(): string {
        if (!this._mail_key) {
            this._mail_key = process.env.mail_key;
        }
        return this._mail_key;
    }
    get mail_sendqueue(): string {
        if (!this._mail_sendqueue) {
            this._mail_sendqueue = process.env.mail_sendqueue;
        }
        return this._mail_sendqueue;
    }
    get mail_sender(): string {
        if (!this._mail_sender) {
            this._mail_sender = process.env.mail_sender;
        }
        return this._mail_sender;
    }
    get notification_changetopic(): string {
        if (!this._notification_changetopic) {
            this._notification_changetopic = process.env.notification_changetopic;
        }
        return this._notification_changetopic;
    }
}
