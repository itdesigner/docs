
/**
 * Data store query parameter
 *
 * @export
 * @class Parameter
 */
export class Parameter {
    public name: string;
    public value: any;
    public type: any;
    constructor(name: string, type: any, value: any) {
        this.name = name;
        this.value = value;
        this.type = type;
    }
}