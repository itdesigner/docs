
/**
 * Identity key object
 *
 * @export
 * @class IdentityKey
 */
export class IdentityKey {
    /**
     * the identity key value
     */
    public id: string;
    /**
     * constructor
     * @param id identity key value
     */
    constructor(id: string) {
        this.id = id;
    }
}
