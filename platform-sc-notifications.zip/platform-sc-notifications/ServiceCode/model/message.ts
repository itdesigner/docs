
import { DeliveryType, emptyGuid, Priority } from './enumerations';
import { Recipient } from './recipient';

/**
 * represents a message
 */
export class Message {
    /**
     * creates an empty message object
     */
    public static Empty(): Message {
        return new Message(emptyGuid, Priority.INFO, null, null, null, DeliveryType.NONE);
    }
    /**
     * makes a copy of a message object
     * @param m message
     */
    public static Clone(m: Message): Message {
        return new Message(m.correlationid, m.priority, m.subject, m.message, m.source, m.deliveryType, m.recipients);
    }

    public id: string;
    public correlationid: string;
    public priority: Priority;
    public subject: string;
    public message: string;
    public source: string;
    public deliveryType: DeliveryType;
    public recipients: Recipient[];

    // tslint:disable-next-line: max-line-length
    constructor(correlationid: string, priority: Priority, subject: string, message: string, source: string, deliveryType: DeliveryType, recipients?: Recipient[]) {
        this.correlationid = correlationid;
        this.priority = priority;
        this.subject = subject;
        this.message = message;
        this.source = source;
        this.deliveryType = deliveryType;
        this.recipients = new Array<Recipient>();
        if (recipients && recipients.length > 0) {
            this.recipients = recipients;
        }
    }
}
