
/**
 * empty GUID/UUID
 */
export const emptyGuid = '00000000-0000-0000-0000-000000000000';
/**
 * priority enumeration
 */
export enum Priority {
    INFO = 1,
    WARNING = 2,
    ALERT = 3,
    CRITICAL = 4,
}
/**
 * delivery type enumeration
 */
export enum DeliveryType {
    SMS = 5,
    EMAIL = 6,
    NONE = 7,
}
/**
 * status enumeration
 */
export enum Status {
    UNPROCESSED = 8,
    PROCESSING = 9,
    SENT = 10,
    DELIVERED = 11,
    READ = 12,
    DELETED = 13,
}
export enum StatusLookup {
    posted,
    sent,
    delivered,
    read,
    deleted,
}