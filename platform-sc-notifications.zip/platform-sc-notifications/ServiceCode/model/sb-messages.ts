
export class SmsEventMessage {
    public sms_id: string;
    public event: string;
    public timestamp: Date;
    constructor(id: string, event: string, ts: Date) {
        this.sms_id = id;
        this.event = event;
        this.timestamp = ts;
    }
}

// tslint:disable-next-line: max-classes-per-file
export class EmailEventMessage {
    public mail_id: string;
    public event: string;
    public timestamp: Date;
    constructor(id: string, event: string, ts: Date) {
        this.mail_id = id;
        this.event = event;
        this.timestamp = ts;
    }
}
