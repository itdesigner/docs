
import { emptyGuid } from './enumerations';

/**
 * represents a recipient of a message
 */
export class Recipient {
    /**
     * creates an empty instance of a recipient
     */
    public static Empty(): Recipient {
        return new Recipient(emptyGuid, emptyGuid, null, null);
    }
    /**
     * creates a copy of a recipient
     * @param r recipient to copy
     */
    public static Clone(r: Recipient): Recipient {
        return new Recipient(r.userid, r.companyid, r.email, r.phone);
    }
    public userid: string;
    public companyid: string;
    public email: string;
    public phone: string;

    constructor(userid: string, companyid: string, email?: string, phone?: string) {
        this.userid = userid;
        this.companyid = companyid;
        this.email = email;
        this.phone = phone;
    }
}
