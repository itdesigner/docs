import { Link } from '.';
import { ICollection } from './icollection';

/**
 * represents a generic collection
 */
export class Collection<T> implements ICollection<T> {
    /**
     * creates an empty Collection<T>
     */
    public static Empty<T>(): Collection<T> {
        return new Collection<T>(new Array<T>(), 0, 0);
    }
    /**
     * the items contained in the collection
     */
    public items: T[];
    /**
     * the number of items in the ucrrent collection
     */
    public itemCount: number;
    /**
     * the total number of possible items matching criteria
     */
    public totalCount: number;
    /**
     * collection of hateos links for the collection
     */
    public links?: Link[];

    constructor(items: T[], itemCount: number, totalCount: number) {
        this.items = items;
        this.itemCount = itemCount;
        this.totalCount = totalCount;
    }

    /**
     * Adds a HATEOS link for the collection
     *
     * @param {Link} link
     * @memberof MessageDetailCollection
     */
    public addLink(link: Link): void {
        if (this.links == null) {
            this.links = new Array<Link>();
        }
        this.links.push(link);
    }
}
