
import { DeliveryType, emptyGuid, Priority, Status } from './enumerations';
import { Link } from './link';
import { Message } from './message';
import { Recipient } from './recipient';

/**
 * represents a Message Details object
 */
export class MessageDetail extends Message {
    /**
     * creates an empty MEssageDetail object
     */
    public static Empty(): MessageDetail {
        return new MessageDetail(
            emptyGuid,
            emptyGuid,
            Priority.INFO,
            null,
            null,
            null,
            DeliveryType.NONE,
            new Array<Recipient>(),
            Status.UNPROCESSED,
            null,
            null,
            null,
            null,
            null,
        );
    }
    /**
     * creates a copy of the supplied MessageDetail object
     * @param dm MessageDetail
     */
    public static Clone(dm: MessageDetail): MessageDetail {
        return new MessageDetail(
            dm.id,
            dm.correlationid,
            dm.priority,
            dm.subject,
            dm.message,
            dm.source,
            dm.deliveryType,
            dm.recipients,
            dm.status,
            dm.postedTime,
            dm.sentTime,
            dm.deliveredTime,
            dm.readTime,
            dm.deletedTime,
        );
    }
    public id: string;
    public postedTime: Date;
    public sentTime: Date;
    public deliveredTime: Date;
    public readTime: Date;
    public deletedTime: Date;
    public status: Status;
    public links?: Link[];

    // tslint:disable-next-line: max-line-length
    constructor(id: string, correlationid: string, priority: Priority, subject: string, message: string, source: string, deliveryType: DeliveryType, recipients?: Recipient[], status?: Status, postedTime?: Date, sentTime?: Date, deliveredTime?: Date, readTime?: Date, deletedTime?: Date) {
        super(correlationid, priority, subject, message, source, deliveryType, recipients);
        this.id = id;
        this.status = status;
        this.postedTime = postedTime;
        this.sentTime = sentTime;
        this.deliveredTime = deliveredTime;
        this.readTime = readTime;
        this.deletedTime = deletedTime;
    }
}
