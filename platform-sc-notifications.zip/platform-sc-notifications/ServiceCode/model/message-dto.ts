
import { Collection } from './collection';
import { DeliveryType, emptyGuid, Priority } from './enumerations';
import { Message } from './message';
import { Recipient } from './recipient';

/**
 * an internal message data transfer object used for interaction with the repository
 */
export class MessageDTO {
    /**
     * creates an empty DTO
     */
    public static Empty(): MessageDTO {
        return new MessageDTO(emptyGuid, Priority.INFO, null, null, null, DeliveryType.NONE, emptyGuid, emptyGuid, null, null);
    }
    /**
     * creates a copy of a messageDTO object
     * @param m messageDTO to clone
     */
    public static Clone(m: MessageDTO): MessageDTO {
        return new MessageDTO(m.correlationid, m.priority, m.subject, m.message, m.source, m.deliveryType, m.userId, m.companyId, m.email, m.phone);
    }
    /**
     * creates a collection of MessageDTO objects from a single message
     * @param m message
     */
    public static CreateFromMessage(m: Message): Collection<MessageDTO> {
        const items: MessageDTO[] = new Array<MessageDTO>();
        if (m && m.recipients && m.recipients.length > 0) {
            // there is at least one recipient
            m.recipients.forEach((r) => {
                items.push(new MessageDTO(m.correlationid, m.priority, m.subject, m.message, m.source, m.deliveryType, r.userid, r.companyid, r.email, r.phone));
            });
            return new Collection<MessageDTO>(items, items.length, items.length);
        } else {
            return Collection.Empty<MessageDTO>();
        }
    }

    public correlationid: string;
    public priority: Priority;
    public subject: string;
    public message: string;
    public source: string;
    public deliveryType: DeliveryType;
    public email?: string;
    public phone?: string;
    public userId: string;
    public companyId: string;

    // tslint:disable-next-line: max-line-length
    constructor(correlationid: string, priority: Priority, subject: string, message: string, source: string, deliveryType: DeliveryType, userid: string, companyid: string, email?: string, phone?: string) {
        this.correlationid = correlationid;
        this.priority = priority;
        this.subject = subject;
        this.message = message;
        this.source = source;
        this.deliveryType = deliveryType;
        this.userId = userid;
        this.companyId = companyid;
        this.email = email;
        this.phone = phone;
    }

    /**
     * converts the current MEssageDTO into a Message
     */
    public toMessage(): Message {
        const r: Recipient[] = new Array<Recipient>(new Recipient(this.userId, this.companyId, this.email, this.phone));
        return new Message(this.correlationid, this.priority, this.subject, this.message, this.source, this.deliveryType, r);
    }
}
