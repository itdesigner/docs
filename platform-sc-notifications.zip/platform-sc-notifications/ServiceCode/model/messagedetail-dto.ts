

import { Collection } from './collection';
import { MessageDetail } from './MessageDetail';
import { DeliveryType, emptyGuid, Priority, Status } from './enumerations';
import { Message } from './message';
import { Recipient } from './recipient';

/**
 * internal message detail class used for data transfer to and from repository
 */
export class MessageDetailDTO {
    /**
     * creates an empty dto
     */
    public static Empty(): MessageDetailDTO {
        return new MessageDetailDTO(emptyGuid, emptyGuid, Priority.INFO, null, null, null, DeliveryType.NONE, emptyGuid, emptyGuid, null, null, null, null, null, null, null, Status.UNPROCESSED);
    }
    /**
     * creates a copy of a given MessageDetailDTO
     * @param m messagedetailDTO
     */
    public static Clone(m: MessageDetailDTO): MessageDetailDTO {
        return new MessageDetailDTO(m.id, m.correlationId, m.priority, m.subject, m.message, m.source, m.deliverytype, m.userId, m.companyId, m.email, m.phone, m.postedTime, m.sentTime, m.deliveredTime, m.readTime, m.deletedTime, m.status);
    }
    /**
     * creates a MessageDetailDTO collection based on a MEssageDetail
     * @param dm MEssageDetail object
     */
    public static CreateFromMessageDetail(dm: MessageDetail): Collection<MessageDetailDTO> {
        const items: MessageDetailDTO[] = new Array<MessageDetailDTO>();
        if (dm && dm.recipients && dm.recipients.length > 0) {
            // there is at least one recipient
            dm.recipients.forEach((r) => {
                // tslint:disable-next-line: max-line-length
                items.push(new MessageDetailDTO(dm.id, dm.correlationid, dm.priority, dm.subject, dm.message, dm.source, dm.deliveryType, r.userid, r.companyid, r.email, r.phone, dm.postedTime, dm.sentTime, dm.deliveredTime, dm.readTime, dm.deletedTime, dm.status));
            });
            return new Collection<MessageDetailDTO>(items, items.length, items.length);
        } else {
            return Collection.Empty<MessageDetailDTO>();
        }
    }

    public id: string;
    public correlationId: string;
    public priority: Priority;
    public subject: string;
    public message: string;
    public source: string;
    public deliverytype: DeliveryType;
    public email?: string;
    public phone?: string;
    public userId: string;
    public companyId: string;
    public postedTime?: Date;
    public sentTime?: Date;
    public deliveredTime?: Date;
    public readTime?: Date;
    public deletedTime?: Date;
    public status: Status;

    // tslint:disable-next-line: max-line-length
    constructor(id: string, correlationid: string, priority: Priority, subject: string, message: string, source: string, deliveryType: DeliveryType, userid: string, companyid: string, email?: string, phone?: string, postedTime?: Date, sentTime?: Date, deliveredTime?: Date, readTime?: Date, deletedTime?: Date, status?: Status) {
        this.correlationId = correlationid;
        this.priority = priority;
        this.subject = subject;
        this.message = message;
        this.source = source;
        this.deliverytype = deliveryType;
        this.userId = userid;
        this.companyId = companyid;
        this.email = email;
        this.phone = phone;
        this.id = id;
        this.postedTime = postedTime;
        this.sentTime = sentTime;
        this.deliveredTime = deliveredTime;
        this.readTime = readTime;
        this.deletedTime = deletedTime;
        this.status = status;
    }

    /**
     * returns a MessageDetail object based on the current DTO
     */
    public toMessage(): MessageDetail {
        const r: Recipient[] = new Array<Recipient>(new Recipient(this.userId, this.companyId, this.email, this.phone));
        return new MessageDetail(this.id, this.correlationId, this.priority, this.subject, this.message, this.source, this.deliverytype, r, this.status, this.postedTime, this.sentTime, this.deliveredTime, this.readTime, this.deletedTime);
    }
}
