import { AzureFunction, Context, HttpRequest } from "@azure/functions";
import { Configuration } from '../ServiceCode/config';
import { TopicSender } from '../ServiceCode/utilities';

const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest): Promise<void> {
    context.log('HTTP AddNotification trigger function processed a request.');
    const message = req.body.message;

    if (message) {
        const cfg: Configuration = new Configuration();
        await TopicSender.send(message, cfg.notification_changetopic, 'notifyAdd');
        context.res = {
            status: 200, /* Defaults to 200 */
        };
    } else {
        context.res = {
            status: 400,
            body: 'Please pass a Message in the request body',
        };
    }
};

export default httpTrigger;
