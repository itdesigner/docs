import { AzureFunction, Context } from "@azure/functions";
import { MessageAPI } from '../ServiceCode/api';

const serviceBusTopicTrigger: AzureFunction = async function(context: Context, mySbMsg: any): Promise<void> {
    context.log('NotifyDeleteByCorrelation ServiceBus topic trigger function processed message', mySbMsg);
    const id: string = mySbMsg.id;
    const api: MessageAPI = new MessageAPI();
    const res: boolean = await api.DeleteNotificationByCorrelation(id);
};

export default serviceBusTopicTrigger;
