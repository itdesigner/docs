import { AzureFunction, Context } from "@azure/functions";
import { MessageAPI } from '../ServiceCode/api';
import { IdentityKey, MessageDetail } from '../ServiceCode/model';

const serviceBusTopicTrigger: AzureFunction = async function(context: Context, mySbMsg: any): Promise<void> {
    context.log('NotifyUpdate SB Topic trigger function processed message', mySbMsg);
    const m: MessageDetail = mySbMsg as MessageDetail;
    const api: MessageAPI = new MessageAPI();
    const res: boolean = await api.UpdateNotification(m);
};

export default serviceBusTopicTrigger;
