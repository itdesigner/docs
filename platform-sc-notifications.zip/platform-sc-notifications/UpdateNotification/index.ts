import { AzureFunction, Context, HttpRequest } from "@azure/functions";
import { Configuration } from '../ServiceCode/config';
import { TopicSender } from '../ServiceCode/utilities';

const httpTrigger: AzureFunction = async function (context: Context, req: HttpRequest): Promise<void> {
    context.log('HTTP UpdateNotification trigger function processed a request.');
    if (req && req.params && req.params.id) {
        const msgId: string = req.params.id;
        const messagedetails = (req.body && req.body.messagedetails) ? req.body.messagedetails : null;
        if (messagedetails && msgId && messagedetails.id === msgId) {
            const cfg: Configuration = new Configuration();
            await TopicSender.send(messagedetails, cfg.notification_changetopic, 'notifyUpdate');
            context.res = {
                status: 200, /* Defaults to 200 */
            };
        } else {
            context.res = {
                status: 400,
                body: 'Please pass a messageDetails in the request body',
            };
        }
    }
};

export default httpTrigger;
