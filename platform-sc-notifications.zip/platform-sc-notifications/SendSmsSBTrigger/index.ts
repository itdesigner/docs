import { AzureFunction, Context } from "@azure/functions";
import { SMS } from '../ServiceCode/providers';

const serviceBusQueueTrigger: AzureFunction = async function(context: Context, mySbMsg: any): Promise<void> {
    context.log('SendSMS ServiceBus queue trigger function processed message', mySbMsg);
    const content = JSON.parse(mySbMsg);
    if (content) {
        const sms: SMS = new SMS();
        const id: string = content.id;
        const to: string = content.to;
        const msg: string = content.msg;
        await sms.send(id, to, msg);
    }
};

export default serviceBusQueueTrigger;
