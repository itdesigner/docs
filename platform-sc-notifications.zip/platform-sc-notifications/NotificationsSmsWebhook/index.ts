import { AzureFunction, Context, HttpRequest } from '@azure/functions';
import {ServiceBusClient} from '@azure/service-bus';
import { Configuration } from '../ServiceCode/config';
import { TwilioStatusProcessor } from '../ServiceCode/providers';
import { QueueSender } from '../ServiceCode/utilities/queue-sender';

const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest): Promise<void> {
    context.log('SMS Event HTTP trigger function processed a request.');
    const content = req.body;
    let smsStatus: string = null;
    let smsId: string = null;
    // content from twilio is an ampersand (&) divided string
    if (typeof content === 'string') {
        const segments: string[] = content.split('&');
        segments.forEach((segment) => {
            if (segment.startsWith('SmsSid')) {
                // this is the sms msg id
                const kvp: string[] = segment.split('=');
                smsId = kvp[1];
            }
            if (segment.startsWith('SmsStatus')) {
                // this is the status code
                const kvp: string[] = segment.split('=');
                smsStatus = kvp[1];
            }
        });
    }
    const eventTime: Date = new Date();
    const cfg: Configuration = new Configuration();
    const sbSmsStatusMsg = {
        sms_id: smsId,
        event: smsStatus,
        timestamp: eventTime,
    };
    // push message to smsstatuseventq
    const body: string = JSON.stringify(sbSmsStatusMsg);
    await QueueSender.send(body, cfg.sms_statusqueue, 'smsstatusevent');
    context.res = {
        status: 200,
    };
};

export default httpTrigger;
