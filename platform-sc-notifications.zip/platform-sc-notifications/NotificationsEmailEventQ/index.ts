import { AzureFunction, Context } from "@azure/functions"
import { SendgridStatusProcessor } from '../ServiceCode/providers';

const serviceBusQueueTrigger: AzureFunction = async function(context: Context, mySbMsg: any): Promise<void> {
    context.log('EMail Status ServiceBus queue trigger function processed message', mySbMsg);
    const content = JSON.parse(mySbMsg);
    if (content) {
        const processor: SendgridStatusProcessor = new SendgridStatusProcessor();
        context.log('content type=> ' + typeof(content));
        context.log('af content => ' + JSON.stringify(content));
        await processor.processHook(content, context);
    }
};

export default serviceBusQueueTrigger;
