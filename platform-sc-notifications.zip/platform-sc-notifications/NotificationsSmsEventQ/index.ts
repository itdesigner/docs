import { AzureFunction, Context } from "@azure/functions"
import { TwilioStatusProcessor } from "../ServiceCode/providers";

const serviceBusQueueTrigger: AzureFunction = async function(context: Context, mySbMsg: any): Promise<void> {
    context.log('ServiceBus queue trigger function processed message', mySbMsg);
    const content = JSON.parse(mySbMsg);
    if (content) {
        const processor: TwilioStatusProcessor = new TwilioStatusProcessor();
        await processor.processHook(content);
    }
};

export default serviceBusQueueTrigger;
