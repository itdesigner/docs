DROP PROCEDURE [dbo].[usp_getEnum_ByType]
GO
DROP PROCEDURE [dbo].[usp_getNotifications_ById]
GO
DROP PROCEDURE [dbo].[usp_getNotifications_Active_ByUserId]
GO
DROP PROCEDURE [dbo].[usp_getNotifications_ByUserId]
GO
DROP PROCEDURE [dbo].[usp_getNotifications_ByCorrelationId]
GO
DROP PROCEDURE [dbo].[usp_getNotifications_ByCompanyId]
GO
DROP PROCEDURE [dbo].[usp_getNotifications_Deleted_ByUserId]
GO
DROP PROCEDURE [dbo].[usp_Notifications_DeleteByCorrelation]
GO
DROP PROCEDURE [dbo].[usp_Notifications_Delete]
GO
DROP PROCEDURE [dbo].[usp_Notifications_Insert]
GO
DROP PROCEDURE [dbo].[usp_Notifications_Update]
GO
DROP PROCEDURE [dbo].[usp_Notifications_UpdateFK]
GO
DROP TABLE [dbo].[DeletedNotifications]
GO
DROP TABLE [dbo].[Notifications]
GO
DROP TABLE [dbo].[Enumerations]
GO

