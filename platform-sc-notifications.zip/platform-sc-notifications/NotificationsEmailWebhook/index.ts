import { AzureFunction, Context, HttpRequest } from '@azure/functions';
import { ServiceBusClient } from '@azure/service-bus';
import { Configuration } from '../ServiceCode/config';
import { SendgridStatusProcessor } from '../ServiceCode/providers';
import { QueueSender } from '../ServiceCode/utilities/queue-sender';

const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest): Promise<void> {
    context.log('HTTP trigger function processed a request.');
    const content = req.body;
    if (content) {
        // push message to smsstatuseventq
        const cfg: Configuration = new Configuration();
        const body: string = JSON.stringify(content);
        await QueueSender.send(body, cfg.mail_statusqueue, 'emailstatusevent');
        context.res = {
            status: 200,
        };
    } else {
        context.res = {
            status: 400,
            body: 'invalid body content from email webhook caller',
        };
    }
};

export default httpTrigger;
