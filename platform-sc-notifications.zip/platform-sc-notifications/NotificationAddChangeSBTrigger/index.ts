import { AzureFunction, Context } from "@azure/functions"
import { MessageAPI } from "../ServiceCode/api";
import { IdentityKey, Message } from '../ServiceCode/model';

const serviceBusTopicTrigger: AzureFunction = async function(context: Context, mySbMsg: any): Promise<void> {
    context.log('NotifyAdd SB Topic trigger function processed message', mySbMsg);
    const m: Message = mySbMsg as Message;
    const api: MessageAPI = new MessageAPI();
    const ik: IdentityKey[] = await api.AddNotification(m);
};

export default serviceBusTopicTrigger;
