describe("My tests", async () => {
    it("Test 1", async () => {
        console.log("Test 1");
    });

    it("Test 2", async () => {
        console.log("Test 3");
    });

    it("Test 3", async () => {
        console.log("Test 4");
    });
});