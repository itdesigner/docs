module.exports = {
    plugins: [
        require("autoprefixer")
    ],
    sourceMap: true,
    minimize: true
}