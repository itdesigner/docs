/**
 * Cotract of HipCaptcha params 
 */

export interface CaptchaParams {
    HipUrl: string;
    EncryptedFlowId: string;
}
