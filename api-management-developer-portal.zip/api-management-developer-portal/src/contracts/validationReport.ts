/**
 * Cotract of validation Report
 */
export interface ValidationReport {
    source: string;
    errors: string[];
}