/**
 * User identity contract.
 */
export interface Identity {
    /**
     * User unique identifier.
     */
    id: string;
}