export interface TagProperties {
    displayName: string;
}

export interface TagContract {
    id: string;
    properties: TagProperties;
}