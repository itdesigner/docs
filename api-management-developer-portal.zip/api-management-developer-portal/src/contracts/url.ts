export interface Url {
    scheme: string;
    host: string;
    path: string;
}