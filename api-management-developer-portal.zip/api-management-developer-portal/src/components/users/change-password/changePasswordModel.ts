export class ChangePasswordModel { 
    public requireHipCaptcha: boolean;
}
