export class UserSignupModel { 
    requireHipCaptcha: boolean;
}
