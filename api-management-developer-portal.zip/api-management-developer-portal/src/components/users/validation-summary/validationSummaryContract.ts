import { Contract } from "@paperbits/common";

export interface ValidationSummaryContract extends Contract { }