export class ValidationSummaryModel { }
