import template from "./validationSummary.html";
import { Component } from "@paperbits/common/ko/decorators";

@Component({
    selector: "validationSummary",
    template: template
})
export class ValidationSummaryViewModel {
}