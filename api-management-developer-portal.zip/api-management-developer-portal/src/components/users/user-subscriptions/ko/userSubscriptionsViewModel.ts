import template from "./userSubscriptions.html";
import { Component } from "@paperbits/common/ko/decorators";

@Component({
    selector: "userSubscriptions",
    template: template
})
export class UserSubscriptionsViewModel {
}