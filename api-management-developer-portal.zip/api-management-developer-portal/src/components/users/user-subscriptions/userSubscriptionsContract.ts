import { Contract } from "@paperbits/common";

export interface UserSubscriptionsContract extends Contract { }
