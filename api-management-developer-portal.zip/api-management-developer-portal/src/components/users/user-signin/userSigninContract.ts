import { Contract } from "@paperbits/common";

export interface UserSigninContract extends Contract { }
