import { Contract } from "@paperbits/common";

export interface UserSigninSocialContract extends Contract { }
