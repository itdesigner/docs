export class ResetPasswordModel { 
    public requireHipCaptcha: boolean;
}
