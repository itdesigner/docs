import { Contract } from "@paperbits/common";

export interface UserDetailsContract extends Contract { }
