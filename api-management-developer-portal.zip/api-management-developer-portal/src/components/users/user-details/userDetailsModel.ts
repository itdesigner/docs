export class UserDetailsModel { }
