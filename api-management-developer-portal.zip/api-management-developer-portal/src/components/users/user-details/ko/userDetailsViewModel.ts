import template from "./userDetails.html";
import { Component } from "@paperbits/common/ko/decorators";

@Component({
    selector: "userDetails",
    template: template
})
export class UserDetailsViewModel {
}