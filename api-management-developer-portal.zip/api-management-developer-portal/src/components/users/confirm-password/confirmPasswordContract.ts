import { Contract } from "@paperbits/common";

export interface ConfirmPasswordContract extends Contract { }
