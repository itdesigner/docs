export class ConfirmPasswordModel { }
