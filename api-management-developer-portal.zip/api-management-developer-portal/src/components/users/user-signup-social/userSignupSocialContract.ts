import { Contract } from "@paperbits/common";

export interface UserSignupSocialContract extends Contract { }
