export class UserSignupSocialModel { }
