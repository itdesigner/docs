export class ProductDetailsModel { }
