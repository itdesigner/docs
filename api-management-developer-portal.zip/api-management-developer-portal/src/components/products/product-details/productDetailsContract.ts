import { Contract } from "@paperbits/common";

export interface ProductDetailsContract extends Contract { }
