export class ProductSubscribeModel { }
