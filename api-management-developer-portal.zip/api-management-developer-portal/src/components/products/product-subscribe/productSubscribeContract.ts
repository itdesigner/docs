import { Contract } from "@paperbits/common";

export interface ProductSubscribeContract extends Contract { }
