import template from "./productSubscribe.html";
import { Component } from "@paperbits/common/ko/decorators/component.decorator";

@Component({
    selector: "product-subscribe",
    template: template
})
export class ProductSubscribeViewModel {
}