export class ProductSubscriptionsModel { }
