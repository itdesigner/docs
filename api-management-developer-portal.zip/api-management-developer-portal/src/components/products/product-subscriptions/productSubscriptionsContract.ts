import { Contract } from "@paperbits/common";

export interface ProductSubscriptionsContract extends Contract { }
