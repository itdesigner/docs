import template from "./reports.html";
import { Component } from "@paperbits/common/ko/decorators";

@Component({
    selector: "reports",
    template: template
})
export class ReportsViewModel {
}