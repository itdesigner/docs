import { Contract } from "@paperbits/common";

export interface ReportsContract extends Contract { }
