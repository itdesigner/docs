export class ReportsModel { }
