import * as ko from "knockout";

export class TagGroupViewModel {
    public expanded: ko.Observable<boolean>;
}