export class OperationDetailsModel { }
