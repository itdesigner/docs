import { Contract } from "@paperbits/common";

export interface OperationDetailsContract extends Contract { }
