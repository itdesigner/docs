# Create an ASP.NET Core Web App in Azure

[Azure App Service](https://docs.microsoft.com/en-us/azure/app-service/overview) provides a highly scalable, self-patching web hosting service.

This sample shows how to deploy your first ASP.NET Core web app to Azure App Service. When you're finished, you'll have a resource group that consists of an App Service plan and an App Service app with a deployed web application.

If, instead, you would like to create either a [Node.js web app](./create-nodejs-webapp.md) or [Static HTMl webiste](./create-static-site.md), you may do so by navigating to the correct sample.

If you don't have an Azure subscription, create a free account before you begin.

## Prerequisites

To complete this sample, install [Visual Studio 2019](https://www.visualstudio.com/downloads/) with the ASP.NET and web development workload.

If you've installed Visual Studio 2019 already:

* Install the latest updates in Visual Studio by selecting ```Help > Check for Updates```.
* Add the workload by selecting ```Tools > Get Tools and Features```.


## Create an ASP.NET Core web app

Create an ASP.NET Core web app by following these steps:

1. Open Visual Studio and then select **Create a new project**.

2. In **Create a new project**, find and choose **ASP.NET Core Web Application for C#**, then select **Next**.

3. In **Configure your new project**, name the application myFirstAzureWebApp, and then select **Create**.

![Configure new project](./img/configure-core-web-app-project.png)

4. For this sample, choose the **Web Application** template. Make sure authentication is set to **No Authentication** and no other option is selected. Select **Create**.

![Create new app](./img/create-core-app.png)

5. From the Visual Studio menu, select Debug > Start Without Debugging to run the web app locally.

![core web app running locally](./img/core-web-app-running-locally.png)

## Publish your web app

1. In **Solution Explorer**, right-click the myFirstAzureWebApp project and select **Publish**.

2. Choose **App Service** and then select **Publish**.

![publish](./img/publish-core-app-vs2019.png)

3. In **App Service Create new**, your options depend on whether you're signed in to Azure already and whether you have a Visual Studio account linked to an Azure account. Select either **Add an account** or **Sign in** to sign in to your Azure subscription. If you're already signed in, select the account you want.

![create new](./img/sign-in-azure-vs2019.png)

4. For **Resource group**, select **New**.  
A [resource group](https://docs.microsoft.com/en-us/azure/azure-resource-manager/resource-group-overview#terminology) is a logical container into which Azure resources like web apps, databases, and storage accounts are deployed and managed. For example, you can choose to delete the entire resource group in one simple step later.

5. In **New resource group name**, enter myResourceGroup and select **OK**.

6. For the Hosting Plan, select New.  An [App Service plan](https://docs.microsoft.com/en-us/azure/app-service/overview-hosting-plans) specifies the location, size, and features of the web server farm that hosts your app. You can save money when hosting multiple apps by configuring the web apps to share a single App Service plan.

App Service plans define:

* Region (for example: North Europe, East US, or Southeast Asia)
* Instance size (small, medium, or large)
* Scale count (1 to 20 instances)
* SKU (Free, Shared, Basic, Standard, or Premium)

In the **Configure Hosting Plan** dialog, enter the values from the following table, and then select **OK**.

| Setting | Suggested Value | Description          |
| ------- | --------------- | -------------------- |
|App Svc Plan| myAppServicePlan | *Name of the App Service Plan* |
|Location | US South Central | *The datacenter where the web app is hosted* |
| Size | Free | *Pricing tier determines hosting features* |

![Hosting Plan](./img/app-service-plan-vs2019.png)

8. In **Name**, enter a unique app name that includes only the valid characters are a-z, A-Z, 0-9, and -. You can accept the automatically generated unique name. The URL of the web app is http://<app_name>.azurewebsites.net, where <app_name> is your app name.

![web app name](./img/web-app-name-vs2019.png)

9. Select **Create** to start creating the Azure resources.

Once the wizard completes, it publishes the ASP.NET Core web app to Azure, and then launches the app in the default browser.

![app running live](./img/web-app-running-live.png)

The app name specified in the **App Service Create** new page is used as the URL prefix in the format ```http://<app_name>.azurewebsites.net```.

Congratulations! Your ASP.NET Core web app is running live in Azure App Service.

## Update the app and redeploy

1. In Solution Explorer, under your project, open ```Pages > Index.cshtml```.

2. Replace the two ```<div>``` tags with the following code:

```html
<div class="jumbotron">
    <h1>ASP.NET in Azure!</h1>
    <p class="lead">This is a simple app that we’ve built that demonstrates how to deploy a .NET app to Azure App Service.</p>
</div>
```
3. To redeploy to Azure, right-click the myFirstAzureWebApp project in **Solution Explorer** and select **Publish**.

4. In the **Publish** summary page, select **Publish**.

![publish summary](./img/publish-summary-page-vs2019.png)

When publishing completes, Visual Studio launches a browser to the URL of the web app.

![updated live](./img/web-app-running-live-updated.png)

## Manage the Azure App

To manage the web app, go to the [Azure portal](https://portal.azure.com), and search for and select **App Services**.

![portal](./img/app-services.png)

On the App Services page, select the name of your web app.

![access app](./img/access-portal-vs2019.png)

You see your web app's Overview page. Here, you can do basic management like browse, stop, start, restart, and delete.

![app general](./img/web-app-general-vs2019.png)

The left menu provides different pages for configuring your app.

## Clean up resources

In the preceding steps, you created Azure resources in a resource group. If you don't expect to need these resources in the future, you can delete them by deleting the resource group.

From the Azure portal menu or Home page, select **Resource groups**, and on the Resource groups page, select myResourceGroup.

On the myResourceGroup page, make sure that the listed resources are the ones you want to delete.

Select **Delete**, type **myResourceGroup** in the text box, and then select **Delete**.