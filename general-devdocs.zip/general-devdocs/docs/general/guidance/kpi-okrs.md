# Key Performance Indicators

A Key Performance Indicator (KPI) is a measurable value that establishes just how effectively a company is achieving key business objectives. Key performance indicators are used at all levels of an organization to evaluate success at reaching targets. High-level KPIs may focus on the overall performance of the enterprise, while lower-level KPIs may focus on individual processes, applications, teams, or departments.

## Why are KPI's Important?

Setting key performance indicators for an organization usually happens during a strategic planning period, whether that is done yearly, quarterly or even more frequently, the goal is to ensure the entire organization is aligned towards the same objectives and goals. The important thing is that a KPI needs to be intimately connected with a key business objective - not just any objective, or something that someone thinks might be important. The KPI needs to be focused on something that is an integral factor in the organization’s success. Without that link, you are attacking a target that fails to address a business outcome. At best, you’d be working towards a goal that has no impact for your organization. At worst, it will result in your business wasting time, money and other resources that would have best been spent elsewhere.

In short, KPI's are all about focusing your resources on and moving everyone in the same direction. They help ensure that every effort is tied to a goal and every action supports "moving the needle"in the right direction for the organization.

## What makes an effective KPI?

Any KPI is only as valuable as the action it inspires. One of the most important aspects of KPIs is that they need to be communicated. Succinct, clear and relevant information is much more likely to be absorbed and acted upon. How are the people carrying out the vision for the organization supposed to follow through on goals if they don’t know or understand what they are? Failure to communicate your KPI's clearly and in context risks alienating and frustrating your teams and stakeholders who are unable to see the direction in which your organization is heading.

When developing a strategy for creating KPIs, your team should start with the basics and understand what your organizational objectives are, how you plan on achieving them, and who can act on this information. This should be an iterative process that involves feedback from business experts, department heads and managers. As this discovery process unfolds, you will gain a better understanding of which business processes need to be measured with a KPI dashboard and with whom that information should be shared.

## SMART(er) KPI's - A better way

One way to evaluate the relevance of a KPI is to use the SMART criteria. The letters are typically taken to stand for Specific, Measurable, Attainable, Relevant, Time-bound.

*  Is your objective **Specific**?
*  Can you **Measure** progress towards that goal?
*  Is the goal realistically **Attainable**?
*  How **Relevant** is the goal to your organization or team?
*  What is the **Time-frame** for achieving this goal?

![smart-kpis](./img/smart.jpg)

The SMART criteria can also be expanded to be SMARTER with the addition of **Evaluate** and **Reevaluate**. These two steps are very important, as they ensure you continually assess your KPIs and their relevance to your business. For example, if you've exceeded your revenue target for the current year, you should determine if that's because you set your goal too low or if that's attributable to some other factor. You should be regularly assessing the value and relevance of your KPI's.

## How to define a KPI
Defining key performance indicators can be tricky business. The operative word in KPI is “key” because every KPI should related to a specific business outcome with a performance measure. KPIs are often confused with business metrics. Although often used in the same spirit, KPIs need to be defined according to critical or core business objectives while metrics are typically focused on individual efforts to support a larger KPI. When defining a KPI, the main considerations should be:

*  What is your desired outcome?
*  Why does this outcome matter?
*  How are you going to measure progress?
*  How can you influence the outcome?
*  Who is responsible for the business outcome?
*  How will you know you’ve achieved your outcome?
*  How often will you review progress towards the outcome?

As an example, let’s say your objective is to increase sales revenue this year. You’re going to call this your Sales Growth KPI. Here’s how you might define the KPI:

*  To increase sales revenue by 20% this year
*  Achieving this target will allow the business to become profitable
*  Progress will be measured as an increase in revenue measured in dollars spent
*  By hiring additional sales staff, by promoting existing customers to buy more product
*  The Chief Sales Officer is responsible for this metric
*  Revenue will have increased by 20% this year
*  Will be reviewed on a monthly basis

## Useful Questions when planning KPI’s
Review these questions as a checklist when building out your key business performance measurement systems:

*  Be derived from strategy
*  Be simple to understand
*  Provide timely and accurate feedback
*  Be based on quantities that can be influenced, or controlled, by the user alone or in co-operation with others
*  Reflect the “business process” – i.e. both the supplier and customer should be involved in the definition of the measure
*  Relate to specific goals (targets)
*  Be relevant
*  Be part of a closed management loop
*  Be clearly defined
*  Have visual impact
*  Focus on improvement
*  Be consistent (in that they maintain their significance as time goes by)
*  Provide fast feedback
*  Have an explicit purpose
*  Be based on an explicitly defined formula and source of data
*  Employ ratios rather than absolute numbers
*  Use data which are automatically collected as part of a process whenever possible
*  Be reported in a simple consistent format
*  Be based on trends rather than snapshots
*  Provide information
*  Be precise – be exact about what is being measured
*  Be objective – not based on opinion

This list of questions is based off the work of Andy Neely at Cambridge. His work, [Design performance measures: a structured approach](https://www.emeraldinsight.com/doi/abs/10.1108/01443579710177888) is an excellent resource when thinking about KPI's.

KPIs are a useful tool for measuring the success of your organization and making the adjustments required to make it successful. The usefulness of individual KPIs, though, have their limits - the most important part of any KPI is its utility. Once its outlived its usefulness, you shouldn’t hesitate to toss it and get started on new ones that better align with your underlying business objectives.

# OKR's (Objective & Key Results)

**OKR** is an abbreviation for Objective & Key Result. OKRs are meant to set strategy and goals over a specified amount of time for both organization and even individual teams. At the end of a regular period, your OKRs provide a means to evaluate how well you did in executing your objectives.

Spending a concerted effort in identifying your organizations strategy and laying it out in a clear and understandable way with OKRs can truly help your employees see how their efforts are contributing to the big picture and how they fit in with other teams.


![okr](./img/okr.jpg)

## Objectives
Any initiative has an objective. The goal of setting an objective is to write out what you hope to accomplish such that at a later time you can easily tell if you have reached, or have a clear path to reaching, that objective. Choosing the right objectives is one of the hardest things to do and requires a great deal of thinking and an open mind to do well.

In short, KPI's are all about focusing your resources on and moving everyone in the same direction. They help ensure that every effort is tied to a goal and every action supports "moving the needle"in the right direction for the organization.

## Key Results
Assuming your Objectives are well thought through, Key Results are the secret sauce to using OKRs. Key Results are numerically-based expressions of success or progress towards an Objective. Expectations that are numerically defined produce results that can be quantitatively measured and scored.

The important element here is measuring success. It’s not good enough to make broad statements about improvement (that are subjectively evaluated). We need to know how well we are succeeding. Qualitative goals tend to under-represent our capabilities because the solution tends to be the lowest common denominator.

## OKRs, KPI's, and Metrics ... Oh My!

OKRs provide the missing link between ambition and reality. They help you break out of the status quo and take you into new, often unknown, territory. If you have a big dream — an inspiring Ultimate Goal — for your organization, you need OKRs that take you there.

A KPI, on the other hand, measures the success, the output, quantity, or quality of an ongoing process or activity. They measure processes or activities already in place.

Very often, a KPI that needs improvement will be a starting point for creating an OKR, and it will become a Key Result of an Objective. Accordingly, an OKR vs. KPI comparison is a bit like comparing a fruit salad with an orange, they both contain fruit, but one is a combination that contains the other. Because of their complementary scope, OKRs and KPIs are natural companions.

## EXAMPLE: A SUPPORT KPI BELOW TARGET BECOMES A KEY RESULT

Let’s say you want to measure the success of your Support team. You could create a KPI that measures the average reply time for incoming support tickets. If you agree with Support that the average reply time should be 30 minutes or less, you’ll be able to instantly see (on a KPI dashboard like Geckoboard) whether your target is met.

As long as that is the case, you’re all good. But what if the KPI indicates the average reply time currently is 48 minutes? You probably want to create an Objective to Improve customer support. How would you know you’ve improved it or not? Well, if the average reply time drops from 48 to 30 minutes. So that would be your Key Result. What will you do to make that happen? You may want to hire an extra support manager, streamline processes or implement Zendesk (which are all Initiatives).

OKRs provide the missing link between ambition and reality. They help you break out of the status quo and take you into new, often unknown, territory. If you have a big dream — an inspiring Ultimate Goal — for your organization, you need OKRs that take you there.