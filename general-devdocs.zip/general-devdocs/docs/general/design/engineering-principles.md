# Sphera's Engineering Principles

## Platform Committed

At Sphera, we’re committed to being a platform-as-a-service provider, so we're always delivering the highest quality, platform-optimized, and cost effective solutions for our business partners and customers.

## Business-Value Driven

We focus on translating the company's business vision and objectives into actionable and measurable deliverables. The goal is to ensure the strategic goals of a company drives progress and action at every level within Sphera and with our engineering efforts specifically.

By being business-driven and focusing on value, every employee moves in the same direction at the same time. This means we can deliver the right things at the right times to maximize the value to the company and our customers.

## 5 Pillar Approach to Delivery

The fundamental approach we’re taking for the Architecture of our applications and systems is based on our platform - Azure. Azure provides a core definition of what it means to have a well-architected system on their platform. Find additional details on Azure's documentation and [here on Sphera's approach](../guidance/sphera-5-pillars.md).

## Get Great at being Simple

Every engineering team member is responsible for quality software, and by making everyone responsible for quality software, all team members must be able to prove that their work on the software is moving the finished product into the hands of our customers and adding value. All team members are accountable for quality throughout the software lifecycle.

How do we address quality? By focusing on being simple. From deciding what we want, down to programming it and getting it right, software development can be very complex - yet we do best when we can find simplicity in how we work.

**Simple is good**.  Simple allows us to focus on delivering the one thing that will totally delight our customers. When we do one thing well, rather than several things as well as we can, the outcome will always be better. If we deliver on those tasks that will make a big difference, imagine how much more productive we can be. Simple allows us to focus our energy.

**Simple isn’t easy**. It takes hard work to find the one thing that you need to focus on: trying to work out what the problem you are trying to solve is.  It’s too easy to say “...and then we can add these additional features too.”  It’s hard not to continually tweak a good idea until it becomes confused.  Simple is all about bringing clarity to our work.

**Simple lets us be agile**.  Keeping things simple allows us to back up, learn from our experiences, but not be so committed that we can only continue in one direction. Simple enables us to adapt.

Sphera's [six required principles for effective software development](./simple-is-great.md) provide a powerful way to manage complexity and allow us to keep things simple.