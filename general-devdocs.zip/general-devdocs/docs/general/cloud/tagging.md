# Tagging Resources in SpheraCloud

Enterprises are now, more than ever, managing complex cloud environments, trying to come to grips with highly complex pricing structures and an onslaught of new cloud services. The key to success is implementing enterprise-grade governance platforms that enable you to efficiently optimize costs across all cloud providers and ensure that you have access to any and all of the cloud services that our company requires.

Tagging of cloud resources is a critical foundation for our cloud governance initiatives. We will need a consistent set of tags specifically for governance and will apply globally across all of our resources. These global tags will add metadata specific to our organization that helps us better categorize each of our cloud ​resources for cost allocation, reporting, chargeback and showback, cost optimization, compliance, and security.

## Tagging basics
Tags let you organize resources and resource groups by assigning them a name:value pair such as CostCenter:Marketing. This can be especially useful when it comes to things like:

*  Access control and compliance: keep track of who can interact with what, and protect sensitive data.
*  Automation: apply bulk actions to related resources automatically, e.g. “shut down all VMs with the tag Environment:dev overnight” or “in resource-group-1, delete resources that have been inactive for 90 days”.
*  Cost governance: most tags assigned to resources are included in your detailed usage data CSV and, as of this year, in the Cost Management Portal APIs. This lets you filter resources according to a common project, customer, department, etc., to facilitate reporting (how much is a particular application/workload costing?) and chargebacks (which department is responsible for which costs?). However, the usefulness of tags remains limited in Azure's native cost management offerings, which don't support tags assigned to resource groups, among other drawbacks.
*  Absent a tagging policy, it is common for teams or individuals within the same organization to use variations of the same tag, which makes it extremely difficult to achieve accurate reporting. To effectively use tags for reporting and governance purposes, it is critical to create a policy that defines consistent naming conventions including spelling, uppercase/lowercase conventions, and spacing.

## Tagging Best Practices
Adding tags to your Azure resources is very simple and can be done using Azure Portal, Azure PowerShell, CLI, or ARM JSON templates. You can tag any resources in Azure, and using this service is free. The tagging is done on the Azure platform level and does not impact the performance of the resource in any way. However, there are certain rules and limitations associated with tagging that users should be aware of:

*  Each resource can have a maximum of 15 tags associated with it. Resources in this case can be individual resources like VM, Network, etc., or the resource group that they are part of.
*  Resources that are deployed using the classic deployment model do not support tagging. It is an exclusive feature of the ARM model.
*  The maximum number of characters for a tag name is 512. For storage accounts, this is limited even further to 128 characters.
*  The maximum number of characters for a tag value is 256.
*  You should use JSON strings via ARM templates when you want to assign multiple values to a tag name.
*  There is no inheritance hierarchy for tags (e.g., tags applied at the resource group level are not inherited by any member resources).
*  The tag name prefixes “Azure,” “Windows,” and “Microsoft” are reserved and cannot be used.

## Global Sphera Tags
These are the tags that are REQUIRED when creating a resource in our Azure environment:

| Tag | Allowed Values        | Purpose      |
| --- | --------------------- | ------------ |
| Environment | env = dev, test, stage, prod | Used to identify the environment type |
|CostCenter | costcenter = sales, marketing, engineering, etc... | Tags used to allocate costs |
|Region | region = emea, us, etc... | Used to determine the location of the resource for regulatory purposes |
|Compliance | compliance = pii, hipaa, fedramp, nist-sp-800-171 | One or more tags used to define compliance requirements |
| Application | app = "app name" *or* vc = "service name" | One or more tags used to define the application or service |
| Tenancy | tenant = global, customerName | Tag used to define if a resource is multitenant or tenant specific |
| Owner | owner = owner email | Tag used to define the owner of a par​ticular resource (whom to contact) |

## Tag monitoring and compliance
As part of the longer term effort to ensure that we are tagging resources in Azure correctly, a process will be put in place via Azure Policies to prevent deployments to an environment if a resource does not have appropriate tags.

At a glance, tags are about as simple as it gets. But taking the time to consider your organization’s needs and design a solid framework for resource tagging will save you a lot of hassle moving forward. 

Management wants to know how much the VMs in your development environment have been costing lately? Need to target a set of related resources for automation purposes? There are so many circumstances in which a good set of tags can mean the difference between painstaking and painless.