# Azure Active Directory B2C

Azure Active Directory B2C provides business-to-customer identity as a service. Our customers use their preferred social, enterprise, or local account identities to get single sign-on access to our applications and APIs.

![AAD B2C](./img/azureadb2c-overview.png)

Azure Active Directory B2C (Azure AD B2C) is a customer identity access management (CIAM) solution capable of supporting millions of users and billions of authentications per day. It takes care of the scaling and safety of the authentication platform, monitoring and automatically handling threats like denial-of-service, password spray, or brute force attacks.

## Custom-branded identity solution

Azure AD B2C is a white-label authentication solution. We can customize the entire user experience with our brand so that it blends seamlessly with our web and mobile applications.

Every page displayed by Azure AD B2C can be customized when our users sign up, sign in, and modify their profile information. We Customize the HTML, CSS, and JavaScript in our user journeys so that the Azure AD B2C experience looks and feels like it's a native part of our application.

## Single sign-on access with a user-provided identity

Azure AD B2C uses standards-based authentication protocols including OpenID Connect, OAuth 2.0, and SAML. It integrates with most modern applications and commercial off-the-shelf software.

![SSO](./img/scenario-singlesignon.png)

By serving as the central authentication authority for our web applications, mobile apps, and APIs, Azure AD B2C enables us to build a single sign-on (SSO) solution for them all. We centralize the collection of user profile and preference information, and capture detailed analytics about sign-in behavior and sign-up conversion.

## Integrate with external user stores

Azure AD B2C provides a directory that can hold 100 custom attributes per user. However, we can also integrate with external systems. For example, use Azure AD B2C for authentication, but delegate to an external customer relationship management (CRM) or customer loyalty database as the source of truth for customer data.

Another external user store scenario is to have Azure AD B2C handle the authentication for your application, but integrate with an external system that stores user profile or personal data. For example, to satisfy data residency requirements like regional or on-premises data storage policies.

![delegating](./img/scenario-remoteprofile.png)

Azure AD B2C can facilitate collecting the information from the user during registration or profile editing, then hand that data off to the external system. Then, during future authentications, Azure AD B2C can retrieve the data from the external system and, if needed, include it as a part of the authentication token response it sends to our applications.

## Progressive profiling

Another user journey option includes progressive profiling. Progressive profiling allows your customers to quickly complete their first transaction by collecting a minimal amount of information. Then, gradually collect more profile data from the customer on future sign-ins.

## Third-party identity verification and proofing

We use Azure AD B2C to facilitate identity verification and proofing by collecting user data, then passing it to a third party system to perform validation, trust scoring, and approval for user account creation.

![idp](./img/scenario-idproofing.png)

These are just some of the things you can do with Azure AD B2C as your business-to-customer identity platform. The following sections of this overview walk you through a demo application that uses Azure AD B2C. You're also welcome to move on directly to a more in-depth [technical overview of Azure AD B2C](h./img/aadb2c-technical.md).