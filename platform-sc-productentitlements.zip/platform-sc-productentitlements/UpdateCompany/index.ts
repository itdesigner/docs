import { AzureFunction, Context, HttpRequest } from '@azure/functions';
import {CompaniesAPI, Company} from '../SharedCode';

/**
 * http trigger for company updates call
 * @param context
 * @param req
 */
const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest) {
    try {
        if (req && req.params && req.params.id) {
            const companyId = req.params.id;
            const company = (req.body && req.body.company);
            if (company && companyId) {
                const api: CompaniesAPI = new CompaniesAPI();
                const data = await api.UpdateCompany(companyId, company);
                context.res = {
                    // status: 200, /* Defaults to 200 */
                    headers: { 'Content-Type': 'application/json' },
                    body: data,
                };
            } else {
                context.res = {
                    status: 400,
                    body: 'Please pass a company model in the request body',
                };
            }
        } else {
            context.res = {
                status: 400,
                body: 'Please pass a companyid in the path',
            };
        }
    } catch (err) {
        context.log.error('ERROR', err);
        // This rethrown exception will be handled by the Functions Runtime and will only fail the individual invocation
        context.res = {
            status: 400,
            body: 'Please pass a companyid in the path',
        };
    }
};

export default httpTrigger;
