INSERT [dbo].[Companies] ([id], [name], [deleted]) VALUES (N'B54FC04E-8EAD-450B-B84D-4AAF9056C14B', N'Sphera Solutions', 0)
GO
INSERT [dbo].[Companies] ([id], [name], [deleted]) VALUES (N'4e858589-9abf-40b3-b7be-21799dc238d4', N'TestCompany 2', 0)
GO
INSERT [dbo].[Companies] ([id], [name], [deleted]) VALUES (N'60b7355a-0e53-476e-b72b-282be5fd41bf', N'SB Company 3', 0)
GO
INSERT [dbo].[Companies] ([id], [name], [deleted]) VALUES (N'9fd109eb-9323-4ca1-88c5-923fc6eab8d6', N'TestCompany 3', 0)
GO
INSERT [dbo].[Companies] ([id], [name], [deleted]) VALUES (N'674ce75b-2d41-4f6c-ab2b-957c9a2bba27', N'TestCompany 4', 0)
GO
INSERT [dbo].[Companies] ([id], [name], [deleted]) VALUES (N'd54a23cd-a9ec-4cb3-abbc-9daa4094978a', N'SB Company 2', 0)
GO
INSERT [dbo].[Companies] ([id], [name], [deleted]) VALUES (N'abfe0cae-1fc4-4813-885a-f87e3b256770', N'SB Company 1', 0)
GO
INSERT [dbo].[Product] ([id], [name], [description], [title], [marketingUrl], [marketingImage], [deleted]) VALUES (N'dd20d995-9778-4e46-8862-188598df197a', N'Insight', N'Insight', N'Insight', N'https://spheracloud.net/marketing/insight.html', N'../Content/img/GreySpheraCloud.png', 0)
GO
INSERT [dbo].[Product] ([id], [name], [description], [title], [marketingUrl], [marketingImage], [deleted]) VALUES (N'ec1ebd8a-8ec2-4d46-8d60-8972533732f8', N'Safeguard', N'Safeguard', N'Safeguard', N'https://sphera.com/spheracloud/health-safety/', N'../Content/img/GreySpheraCloud.png', 0)
GO
INSERT [dbo].[Product] ([id], [name], [description], [title], [marketingUrl], [marketingImage], [deleted]) VALUES (N'AD53F97D-996C-4237-A461-5E800118DA69', N'Stature', N'Stature', N'Stature', N'https://sphera.com/operational-risk/risk-assessment/', N'https://spheracloud.net/images/stature.png', 0)
GO
INSERT [dbo].[Product] ([id], [name], [description], [title], [marketingUrl], [marketingImage], [deleted]) VALUES (N'F2DF33E1-BEBC-4C52-84D8-EBAEAB229E97', N'SiteHawk', N'ISiteHawk', N'SiteHawk', N'https://sitehawk.com/', N'../Content/img/GreySitehawkv2.png', 0)
GO
INSERT [dbo].[Product] ([id], [name], [description], [title], [marketingUrl], [marketingImage], [deleted]) VALUES (N'F2DF33E1-BEBC-4C52-84D8-EBAEAB229E90', N'thinkstep', N'thinkstep', N'thinkstep', N'https://www.thinkstep.com/', N'../Content/img/GreySofi.PNG', 1)
GO
INSERT [dbo].[CompanyProducts] ([id], [companyId], [productId], [linkUrl], [linkImage], [startDate], [endDate], [deleted]) VALUES (N'610dc631-8455-4b00-a84c-214b7fc8c429', N'B54FC04E-8EAD-450B-B84D-4AAF9056C14B', N'DD20D995-9778-4E46-8862-188598DF197A', N'https://goldenlatitude.spheracloud.internal.spherasolutions.com/insight', N'../Content/img/SpheraCloud.png', CAST(N'2019-10-01T00:00:00.000' AS DateTime), CAST(N'2029-10-01T00:00:00.000' AS DateTime), 0)
GO
INSERT [dbo].[CompanyProducts] ([id], [companyId], [productId], [linkUrl], [linkImage], [startDate], [endDate], [deleted]) VALUES (N'e8ada616-8843-4396-9e81-886c3c41c7e0', N'B54FC04E-8EAD-450B-B84D-4AAF9056C14B', N'EC1EBD8A-8EC2-4D46-8D60-8972533732F8', N'https://goldenlatitude.spheracloud.internal.spherasolutions.com/', N'../Content/img/SpheraCloud.png', CAST(N'2019-10-01T00:00:00.000' AS DateTime), CAST(N'2029-10-01T00:00:00.000' AS DateTime), 0)
GO
INSERT [dbo].[CompanyProducts] ([id], [companyId], [productId], [linkUrl], [linkImage], [startDate], [endDate], [deleted]) VALUES (N'F56B0C88-AB21-4B41-9082-FC2AE6D1C8CB', N'B54FC04E-8EAD-450B-B84D-4AAF9056C14B', N'AD53F97D-996C-4237-A461-5E800118DA69', N'https://cra-app01-dev.devapps.spherasolutions.com/stature', N'https://sta-app-6.devapps.spherasolutions.com/stature/image.png', CAST(N'2019-10-01T00:00:00.000' AS DateTime), CAST(N'2029-10-01T00:00:00.000' AS DateTime), 0)
GO
