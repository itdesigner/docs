# Product Entitlements Service
## Description
The Product Entitlements Service is designed and built to act as a read-only System-Of-Record (SOR) repository for the SpheraCloud suite for serving product entitlements to callers.

The Product Entitlements service is focused specifically on the need to be able to map a company to a list of products that they are enabled to use as part of the SpheraCloud suite.  The basic functionality utilizes a corporate or company id for a given user to make the call which brings back a list of products.  Some, none, or all of the returned products will have an associated license object which can be used to indicate that a particuar product is enabled for a customer (and thus their users).

The primary consumer of this service is the home screen application which displays all products available that the user can choose from.
