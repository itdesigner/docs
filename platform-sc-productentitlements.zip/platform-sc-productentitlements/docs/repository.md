# Product Entitlements Repository

## General

The Product Entitlements repository is hosted as an Azure SQL as a Service database.  

## Security 

This repository has been locked down to allow access only from the Azure Function layer within the ProductEntitlements NSG (Network Security Group).  No other access is enabled.

In addition to the caller reztrictions, the database can only be interacted with via the use of stored procedures - direct database access is blocked with the default user accounts created.

## Entity Relationship Diagram

The following diagram represnets the basic data storage diagram for the Product Entitlements system.

![erd](./pe-erd.png "Product Entitlements ERD")

It is a simple structure based on the requirements defined for the product.  Each entity type is based on a primary key (uuid) for each of the elements.  The remaining elements are either descriptive in nature or provide metadata context around the objects themselves.

The Product and Company tables are simple singular entity tables - containing one entry for each each of their respective types.  The CompanyProducts table (logically, a license table) maps a company to a collection of products that a company has access enabled for.

The actual primary entitlements query peforms a multistep approach to meet its defined requirements.  

1.    A unique list of all products is retrieved.
2.    An secondary query retrieves all the license information for a specified company id.
3.    The results, at the database level, are returned as two datatable objects in a signle query.  The API then merges these two sets together to retrieve a master list of all products each one that is licensed then has a license file inswerted into its appropriate node.

## Entity Descriptions

### Company

The **Companies table** consists of three fields:

| Field | PK | Format | Description                          |
| ----- |:--:| ------| -----------------------------------|
| id | X | UUID | unique identifier for the company |
| name |  | nvarchar (2000) | the name of the company |
| deleted |  | bit | a flag field indicating whether the company is active or not (used to control whether this object is returned as part of a standard query) |

The only index on this table is that of the primary key (id).

### Products

The **Products table** consists of the following fields:

| Field | PK | Format | Description                          |
| ----- |:--:| ------| -----------------------------------|
| id | X | UUID | unique identifier for the product |
| name |  | nvarchar (1000) | name of the product |
| description |  | nvarchar (4000) | product description |
| title |  | nvarchar (1000) | display title of product |
| marketingUrl |  | nvarchar (2000) | default marketing page |
| marketingImage |  | nvarchar (2000) | default marketing image path or url |
| deleted |  | bit | active flag |

The only index on this table is the primary key ondex on id.  No other idenxes are defined because this is the primary query key used in all queries.

### CompanyProducts

The **CompanyProducts table*** represents a license that a company has for a particular product.  It consists of the following fields:

| Field | PK | Format | Description                          |
| ----- |:--:| ------| -----------------------------------|
| id | X | UUID | unique identifier for the license |
| companyid |  | UUID | unique identifier for the company |
| productid |  | UUID | unique identifier for the product |
| linkUrl |  | nvarchar (2000) | license-specific link to product |
| linkImage |  | nvarchar (2000) | license-specific image parh or url |
| startDate |  | datetime | datetime license period starts |
| endDate |  | datetime | datetime license period ends |
| deleted |  | bit | active flag |

There are additional indexes beyond the primary key (```id```) for this table.  These include an index on ```comapnyid``` and one on ```productid``` used to optimize query perfromance when retrieving license details for a specific company.

The ```companyid``` is a foreign key to the Companies table.

The ```productid``` is a foreign key to the Products table.


## Database Creation Scripts

The database creation scripts for the product entitlements service can be [downloaded from here](./db_create.sql).

```sql
/****** Object:  Table [dbo].[Companies]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Companies](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](2000) NOT NULL,
	[deleted] [bit] NOT NULL,
 CONSTRAINT [PK_Companies] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CompanyProducts]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CompanyProducts](
	[id] [uniqueidentifier] NOT NULL,
	[companyId] [uniqueidentifier] NOT NULL,
	[productId] [uniqueidentifier] NOT NULL,
	[linkUrl] [nvarchar](2000) NOT NULL,
	[linkImage] [nvarchar](2000) NOT NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
	[deleted] [bit] NOT NULL,
 CONSTRAINT [PK_CompanyProducts] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Product]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Product](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](1000) NOT NULL,
	[description] [nvarchar](4000) NOT NULL,
	[title] [nvarchar](1000) NOT NULL,
	[marketingUrl] [nvarchar](2000) NOT NULL,
	[marketingImage] [nvarchar](2000) NOT NULL,
	[deleted] [bit] NOT NULL,
 CONSTRAINT [PK_Product] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Companies] ADD  CONSTRAINT [DF_Companies_id]  DEFAULT (newid()) FOR [id]
GO
ALTER TABLE [dbo].[Companies] ADD  CONSTRAINT [DF_Companies_deleted]  DEFAULT ((0)) FOR [deleted]
GO
ALTER TABLE [dbo].[CompanyProducts] ADD  CONSTRAINT [DF_CompanyProducts_id]  DEFAULT (newid()) FOR [id]
GO
ALTER TABLE [dbo].[CompanyProducts] ADD  CONSTRAINT [DF_CompanyProducts_deleted]  DEFAULT ((0)) FOR [deleted]
GO
ALTER TABLE [dbo].[Product] ADD  CONSTRAINT [DF_Product_id]  DEFAULT (newid()) FOR [id]
GO
ALTER TABLE [dbo].[Product] ADD  CONSTRAINT [DF_Product_deleted]  DEFAULT ((0)) FOR [deleted]
GO
ALTER TABLE [dbo].[CompanyProducts]  WITH CHECK ADD  CONSTRAINT [FK_CompanyProducts_Companies] FOREIGN KEY([companyId])
REFERENCES [dbo].[Companies] ([id])
GO
ALTER TABLE [dbo].[CompanyProducts] CHECK CONSTRAINT [FK_CompanyProducts_Companies]
GO
ALTER TABLE [dbo].[CompanyProducts]  WITH CHECK ADD  CONSTRAINT [FK_CompanyProducts_Product] FOREIGN KEY([productId])
REFERENCES [dbo].[Product] ([id])
GO
ALTER TABLE [dbo].[CompanyProducts] CHECK CONSTRAINT [FK_CompanyProducts_Product]
GO
/****** Object:  StoredProcedure [dbo].[usp_Companies_Active_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Companies_Active_SelectAll]
(
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [id],
         [name]
    FROM [dbo].[Companies]
	WHERE [deleted] <> 1
    ORDER BY name
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*) as totalcount 
	FROM dbo.Companies 
	WHERE deleted <> 1);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Companies_Insert]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Companies_Insert]
(
    @deleted bit,
    @name nvarchar( 2000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with INSERT statements.
    SET NOCOUNT ON;
	DECLARE @out_id UNIQUEIDENTIFIER
	SET @out_id = NEWID()

    INSERT INTO [dbo].[Companies]
    (
		 [id],
         [deleted],
         [name]
    )
    VALUES
    (
		 @out_id,
         @deleted,
         @name
    )
	SELECT @out_id as id
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Companies_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Companies_SelectAll]
(
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [id],
         [name]
    FROM [dbo].[Companies]
    ORDER BY name
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*)
	FROM dbo.Companies);

	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Companies_SelectById]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Companies_SelectById]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [id],
         [name]
    FROM [dbo].[Companies]
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Companies_Update]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Companies_Update]
(
    @id uniqueidentifier,
    @deleted bit,
    @name nvarchar( 2000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with UPDATE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[Companies]
    SET
         [deleted]=@deleted,
         [id]=@id,
         [name]=@name
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Company_Delete]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Company_Delete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[Companies]
	SET [deleted] = 1
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
CREATE PROCEDURE [dbo].[usp_Company_FullDelete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;
    -- Additonal logic should exist here which prevents orphaned license data for company
    DELETE FROM [dbo].[Companies]
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_Active_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_Active_SelectAll]
(
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
	WHERE [deleted] <> 1
	ORDER BY productId
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*) as totalcount 
	FROM dbo.CompanyProducts 
	WHERE deleted <> 1);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_Active_SelectByCompanyId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_Active_SelectByCompanyId]
(
    @companyId uniqueidentifier,
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([companyId] = @companyId) AND [deleted] <> 1
    )
    ORDER BY productId
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*)
	FROM dbo.CompanyProducts 
	WHERE deleted <> 1 AND [companyId] = @companyId);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_AllDetails_SelectByCompanyId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_AllDetails_SelectByCompanyId]
(
    @companyId uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([companyId] = @companyId) 
    )
    ORDER BY productId

	    SELECT
         p.[deleted],
         p.[description],
         p.[id],
         p.[marketingImage],
         p.[marketingUrl],
         p.[name],
         p.[title]
    FROM [dbo].[Product] p INNER JOIN [dbo].[CompanyProducts] cp ON p.[id] = cp.[productId]
	WHERE cp.[companyId] = @companyId
    ORDER BY p.[id]

END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_Delete]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_Delete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[CompanyProducts]
SET [deleted] = 1
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_FullDelete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;

    DELETE FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_Insert]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_Insert]
(
    @companyId uniqueidentifier,
    @deleted bit,
    @endDate datetime,
    @linkImage nvarchar( 2000) ,
    @linkUrl nvarchar( 2000) ,
    @productId uniqueidentifier,
    @startDate datetime
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with INSERT statements.
    SET NOCOUNT ON;

DECLARE @out_id UNIQUEIDENTIFIER
SET @out_id = newid()

    INSERT INTO [dbo].[CompanyProducts]
    (
[id],
         [companyId],
         [deleted],
         [endDate],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    )
    VALUES
    (
@out_id,
         @companyId,
         @deleted,
         @endDate,
         @linkImage,
         @linkUrl,
         @productId,
         @startDate
    )

SELECT @out_id as id
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_SelectAll]
(
	@limit INT = 100,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
	ORDER BY productId
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*) as totalcount 
	FROM dbo.CompanyProducts);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_SelectByCompanyId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_SelectByCompanyId]
(
    @companyId uniqueidentifier,
	@limit INT = 100,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([companyId] = @companyId) 
    )
    ORDER BY productId
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*)
	FROM dbo.CompanyProducts);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_SelectByEntitlementId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_SelectByEntitlementId]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_Update]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_Update]
(
    @deleted bit,
    @endDate datetime,
    @startDate datetime,
    @id uniqueidentifier,
    @companyId uniqueidentifier,
    @productId uniqueidentifier,
    @linkImage nvarchar( 2000) ,
    @linkUrl nvarchar( 2000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with UPDATE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[CompanyProducts]
    SET
         [companyId]=@companyId,
         [deleted]=@deleted,
         [endDate]=@endDate,
         [linkImage]=@linkImage,
         [linkUrl]=@linkUrl,
         [productId]=@productId,
         [startDate]=@startDate
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Entitlements_Active_SelectByCompanyId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Entitlements_Active_SelectByCompanyId]
(
    @companyId uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

	SELECT
		[id],
		[name],
		[deleted]
	FROM [dbo].[Companies]
	WHERE [id] = @companyId

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([companyId] = @companyId) AND ([deleted] <> 1)
    )
    ORDER BY productId

	SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
	WHERE [deleted] <> 1
    ORDER BY id


END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Entitlements_SelectByCompanyId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Entitlements_SelectByCompanyId]
(
    @companyId uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

	SELECT
		[id],
		[name],
		[deleted]
	FROM [dbo].[Companies]
	WHERE [id] = @companyId

	SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
    ORDER BY id

	SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([companyId] = @companyId) 
    )
    ORDER BY productId
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_Delete]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Product_Delete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[Product]
	SET [deleted] = 1
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
CREATE PROCEDURE [dbo].[usp_Product_FullDelete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;

    DELETE FROM [dbo].[Product]
	WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_Insert]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Product_Insert]
(
    @deleted bit,
    @description nvarchar(MAX) ,
    @marketingImage nvarchar( 2000) ,
    @marketingUrl nvarchar( 2000) ,
    @name nvarchar( 1000) ,
    @title nvarchar( 1000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with INSERT statements.
    SET NOCOUNT ON;

DECLARE @out_id UNIQUEIDENTIFIER
SET @out_id = newid()

    INSERT INTO [dbo].[Product]
    (
[id],
         [deleted],
         [description],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    )
    VALUES
    (
		 @out_id,
         @deleted,
         @description,
         @marketingImage,
         @marketingUrl,
         @name,
         @title
    )

SELECT @out_id as id
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_SelectByName]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Product_SelectByName]
(
    @name nvarchar( 1000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
    WHERE
    (
         ([name] = @name) 
    )
    ORDER BY name

END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_Update]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Product_Update]
(
    @deleted bit,
    @description nvarchar(MAX) ,
    @title nvarchar( 1000) ,
    @id uniqueidentifier,
    @name nvarchar( 1000) ,
    @marketingImage nvarchar( 2000) ,
    @marketingUrl nvarchar( 2000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with UPDATE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[Product]
    SET
         [deleted]=@deleted,
         [description]=@description,
         [marketingImage]=@marketingImage,
         [marketingUrl]=@marketingUrl,
         [name]=@name,
         [title]=@title
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Products_Active_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Products_Active_SelectAll]
(
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
	WHERE [deleted] <> 1
    ORDER BY name
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*)
	FROM dbo.Product 
	WHERE deleted <> 1);
	RETURN @TOTALROWS

END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Products_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Products_SelectAll]
(
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
    ORDER BY name
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*)
	FROM dbo.Product);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Products_SelectById]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Products_SelectById]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
    WHERE
    (
         ([id] = @id) 
    )
    ORDER BY name

END 
GO


```