import { AzureFunction, Context, HttpRequest } from '@azure/functions'
import {License, LicensesAPI} from '../SharedCode';

/**
 * http trigger for remove license call
 * @param context
 * @param req
 */
const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest) {
    try {
        if (req && req.params && req.params.id) {
            const licenseId = req.params.id;
            if (licenseId) {
                const api: LicensesAPI = new LicensesAPI();
                const data = await api.RemoveLicense(licenseId);
                context.res = {
                    // status: 200, /* Defaults to 200 */
                    headers: { 'Content-Type': 'application/json' },
                    body: data,
                };
            }
        } else {
            context.res = {
                status: 400,
                body: 'Please pass a license id in the path',
            };
        }

    } catch (err) {
        context.log.error('ERROR', err);
        // This rethrown exception will be handled by the Functions Runtime and will only fail the individual invocation
        context.res = {
            status: 400,
            body: 'Please pass a license id in the path',
        };
    }
};

export default httpTrigger;
