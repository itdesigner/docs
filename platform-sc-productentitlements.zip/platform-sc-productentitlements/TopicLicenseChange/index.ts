import { AzureFunction, Context } from '@azure/functions';
import { ChangeType, ILicenseChange, License, LicensesAPI} from '../SharedCode';

const serviceBusTopicTrigger: AzureFunction = async function(context: Context, mySbMsg: any): Promise<void> {
    const m: ILicenseChange = mySbMsg as ILicenseChange;
    const api: LicensesAPI = new LicensesAPI();
    switch (m.changeType) {
        case ChangeType.new:
            // this is a new License to be added
            context.log('create new License');
            try {
                const item = new License(m.id, m.companyId, m.productId, m.linkUrl, m.linkImage, m.startDate, m.endDate, m.deleted);
                if (item) {
                    const data = await api.AddLicense(item);
                    context.log('License added => ' + JSON.stringify(data));
                } else {
                    context.log('invalid License data provided');
                }
            } catch (err) {
                context.log.error('ERROR', err);
            }
            break;
        case ChangeType.updated:
            // this is an updated License to be added
            try {
                const item = new License(m.id, m.companyId, m.productId, m.linkUrl, m.linkImage, m.startDate, m.endDate, m.deleted);
                if (item) {
                    const data = await api.UpdateLicense(item.id, item);
                    context.log('License updated (' + item.id + ')=> ' + JSON.stringify(data));
                } else {
                    context.log('invalid License');
                }
            } catch (err) {
                context.log.error('ERROR', err);
            }
            break;
        case ChangeType.deleted:
            // this is a License that needs to be deleted
            try {
                const itemId = m.id;
                if (itemId) {
                    const data = await api.RemoveLicense(itemId);
                    context.log('License deleted (' + itemId + ')=> ' + data);
                } else {
                    context.log('no License provided');
                }
            } catch (err) {
                context.log.error('ERROR', err);
            }
            break;
    }
};

export default serviceBusTopicTrigger;
