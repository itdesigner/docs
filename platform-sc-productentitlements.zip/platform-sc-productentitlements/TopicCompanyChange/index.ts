import { AzureFunction, Context } from '@azure/functions'
import { ChangeType, CompaniesAPI, Company, ICompanyChange } from '../SharedCode';

const serviceBusTopicTrigger: AzureFunction = async function(context: Context, mySbMsg: any): Promise<void> {
    const m: ICompanyChange = mySbMsg as ICompanyChange;
    const api: CompaniesAPI = new CompaniesAPI();
    switch (m.changeType) {
        case ChangeType.new:
            // this is a new company to be added
            context.log('create new company');
            try {
                const company = new Company(m.id, m.name, false);
                if (company) {
                    const data = await api.AddCompany(company);
                    context.log('company added => ' + JSON.stringify(data));
                } else {
                    context.log('invalid ompany data provided');
                }
            } catch (err) {
                context.log.error('ERROR', err);
            }
            break;
        case ChangeType.updated:
            // this is an updated company to be added
            context.log('update company');
            try {
                const company = new Company(m.id, m.name, false);
                if (company) {
                    const data = await api.UpdateCompany(company.id, company);
                    context.log('company updated (' + company.id + ')=> ' + JSON.stringify(data));
                } else {
                    context.log('invalid company');
                }
            } catch (err) {
                context.log.error('ERROR', err);
            }
            break;
        case ChangeType.deleted:
            // this is a company that needs to be deleted
            context.log('remove company');
            try {
                const companyId = m.id;
                if (companyId) {
                    const data = await api.RemoveCompany(companyId);
                    context.log('company delted (' + companyId + ')=> ' + data);
                } else {
                    context.log('no  company provided');
                }
            } catch (err) {
                context.log.error('ERROR', err);
            }
            break;
    }
};

export default serviceBusTopicTrigger;
