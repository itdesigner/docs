import { AzureFunction, Context, HttpRequest } from '@azure/functions'
import {Product, ProductsAPI} from '../SharedCode';

/**
 * http trigger for product create call
 * @param context
 * @param req
 */
const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest) {
    try {
        const product = (req.body && req.body.product);
        if (product) {
            const api: ProductsAPI = new ProductsAPI();
            const data = await api.AddProduct(product);
            context.res = {
                // status: 200, /* Defaults to 200 */
                headers: { 'Content-Type': 'application/json' },
                body: data,
            };
        } else {
            context.res = {
                status: 400,
                body: 'Please pass a product model in the request body',
            };
        }
    } catch (err) {
        context.log.error('ERROR', err);
        // This rethrown exception will be handled by the Functions Runtime and will only fail the individual invocation
        context.res = {
            status: 400,
            body: 'Please pass a product model in the request body',
        };
    }
};

export default httpTrigger;
