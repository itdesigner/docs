import { AzureFunction, Context, HttpRequest } from '@azure/functions'
import {Product, ProductsAPI} from '../SharedCode';

/**
 * http trigger for removing products call
 * @param context
 * @param req
 */
const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest) {
    try {
        if (req && req.params && req.params.id) {
            const productId = req.params.id;
            if (productId) {
                const api: ProductsAPI = new ProductsAPI();
                const data = await api.RemoveProduct(productId);
                context.res = {
                    // status: 200, /* Defaults to 200 */
                    headers: { 'Content-Type': 'application/json' },
                    body: data,
                };
            }
        } else {
            context.res = {
                status: 400,
                body: 'Please pass a productid on the query string or in the request body',
            };
        }

    } catch (err) {
        context.log.error('ERROR', err);
        // This rethrown exception will be handled by the Functions Runtime and will only fail the individual invocation
        context.res = {
            status: 400,
            body: 'Please pass a productid on the query string or in the request body',
        };
    }
};

export default httpTrigger;
