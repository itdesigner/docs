services = `[
        {
            "name": "Notifications Service",
            "link": "../platform-sc-notifications//index.html"
        },
        {
            "name": "Product Entitlements Service",
            "link": "../platform-sc-productentitlements/index.html"
        },
        {
            "name": "Hierarchy Service",
            "link": "../platform-sc-hierarchy/index.html"
        }
    ]`;
