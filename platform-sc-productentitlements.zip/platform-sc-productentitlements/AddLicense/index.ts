import { AzureFunction, Context, HttpRequest } from '@azure/functions'
import {License, LicensesAPI} from '../SharedCode';

/**
 * http trigger for License creation call
 * @param context
 * @param req
 */
const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest) {
    try {
        const license = (req.body && req.body.license);
        if (license) {
            const api: LicensesAPI = new LicensesAPI();
            const data = await api.AddLicense(license);
            context.res = {
                // status: 200, /* Defaults to 200 */
                headers: { 'Content-Type': 'application/json' },
                body: data,
            };
        } else {
            context.res = {
                status: 400,
                body: 'pass a license in the request body',
            };
        }
    } catch (err) {
        context.log.error('ERROR', err);
        // This rethrown exception will be handled by the Functions Runtime and will only fail the individual invocation
        context.res = {
            status: 400,
            body: 'pass a license in the request body',
        };
    }
};

export default httpTrigger;
