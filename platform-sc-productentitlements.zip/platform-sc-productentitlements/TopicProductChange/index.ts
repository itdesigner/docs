import { AzureFunction, Context } from '@azure/functions'
import { ChangeType, IProductChange, Product, ProductsAPI} from '../SharedCode';

const serviceBusTopicTrigger: AzureFunction = async function(context: Context, mySbMsg: any): Promise<void> {
    const m: IProductChange = mySbMsg as IProductChange;
    const api: ProductsAPI = new ProductsAPI();
    switch (m.changeType) {
        case ChangeType.new:
            // this is a new product to be added
            context.log('create new product');
            try {
                const item = new Product(m.id, m.name, m.description, m.title, m.marketingUrl, m.marketingImage, m.deleted);
                if (item) {
                    const data = await api.AddProduct(item);
                    context.log('company added => ' + JSON.stringify(data));
                } else {
                    context.log('invalid product data provided');
                }
            } catch (err) {
                context.log.error('ERROR', err);
            }
            break;
            case ChangeType.updated:
            // this is an updated product to be added
            try {
                const item = new Product(m.id, m.name, m.description, m.title, m.marketingUrl, m.marketingImage, m.deleted);
                if (item) {
                    const data = await api.UpdateProduct(item.id, item);
                    context.log('product updated (' + item.id + ')=> ' + JSON.stringify(data));
                } else {
                    context.log('invalid product');
                }
            } catch (err) {
                context.log.error('ERROR', err);
            }
            break;
            case ChangeType.deleted:
            // this is a product that needs to be deleted
            try {
                const itemId = m.id;
                if (itemId) {
                    const data = await api.RemoveProduct(itemId);
                    context.log('product deleted (' + itemId + ')=> ' + data);
                } else {
                    context.log('no product provided');
                }
            } catch (err) {
                context.log.error('ERROR', err);
            }
            break;
    }
};

export default serviceBusTopicTrigger;
