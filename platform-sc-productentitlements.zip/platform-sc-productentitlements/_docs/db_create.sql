/****** Object:  Table [dbo].[Companies]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Companies](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](2000) NOT NULL,
	[deleted] [bit] NOT NULL,
 CONSTRAINT [PK_Companies] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CompanyProducts]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CompanyProducts](
	[id] [uniqueidentifier] NOT NULL,
	[companyId] [uniqueidentifier] NOT NULL,
	[productId] [uniqueidentifier] NOT NULL,
	[linkUrl] [nvarchar](2000) NOT NULL,
	[linkImage] [nvarchar](2000) NOT NULL,
	[startDate] [datetime] NULL,
	[endDate] [datetime] NULL,
	[deleted] [bit] NOT NULL,
 CONSTRAINT [PK_CompanyProducts] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Product]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Product](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](1000) NOT NULL,
	[description] [nvarchar](4000) NOT NULL,
	[title] [nvarchar](1000) NOT NULL,
	[marketingUrl] [nvarchar](2000) NOT NULL,
	[marketingImage] [nvarchar](2000) NOT NULL,
	[deleted] [bit] NOT NULL,
 CONSTRAINT [PK_Product] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Companies] ADD  CONSTRAINT [DF_Companies_id]  DEFAULT (newid()) FOR [id]
GO
ALTER TABLE [dbo].[Companies] ADD  CONSTRAINT [DF_Companies_deleted]  DEFAULT ((0)) FOR [deleted]
GO
ALTER TABLE [dbo].[CompanyProducts] ADD  CONSTRAINT [DF_CompanyProducts_id]  DEFAULT (newid()) FOR [id]
GO
ALTER TABLE [dbo].[CompanyProducts] ADD  CONSTRAINT [DF_CompanyProducts_deleted]  DEFAULT ((0)) FOR [deleted]
GO
ALTER TABLE [dbo].[Product] ADD  CONSTRAINT [DF_Product_id]  DEFAULT (newid()) FOR [id]
GO
ALTER TABLE [dbo].[Product] ADD  CONSTRAINT [DF_Product_deleted]  DEFAULT ((0)) FOR [deleted]
GO
ALTER TABLE [dbo].[CompanyProducts]  WITH CHECK ADD  CONSTRAINT [FK_CompanyProducts_Companies] FOREIGN KEY([companyId])
REFERENCES [dbo].[Companies] ([id])
GO
ALTER TABLE [dbo].[CompanyProducts] CHECK CONSTRAINT [FK_CompanyProducts_Companies]
GO
ALTER TABLE [dbo].[CompanyProducts]  WITH CHECK ADD  CONSTRAINT [FK_CompanyProducts_Product] FOREIGN KEY([productId])
REFERENCES [dbo].[Product] ([id])
GO
ALTER TABLE [dbo].[CompanyProducts] CHECK CONSTRAINT [FK_CompanyProducts_Product]
GO
/****** Object:  StoredProcedure [dbo].[usp_Companies_Active_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Companies_Active_SelectAll]
(
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [id],
         [name]
    FROM [dbo].[Companies]
	WHERE [deleted] <> 1
    ORDER BY name
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*) as totalcount 
	FROM dbo.Companies 
	WHERE deleted <> 1);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Companies_Insert]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Companies_Insert]
(
    @deleted bit,
    @name nvarchar( 2000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with INSERT statements.
    SET NOCOUNT ON;
	DECLARE @out_id UNIQUEIDENTIFIER
	SET @out_id = NEWID()

    INSERT INTO [dbo].[Companies]
    (
		 [id],
         [deleted],
         [name]
    )
    VALUES
    (
		 @out_id,
         @deleted,
         @name
    )
	SELECT @out_id as id
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Companies_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Companies_SelectAll]
(
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [id],
         [name]
    FROM [dbo].[Companies]
    ORDER BY name
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*)
	FROM dbo.Companies);

	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Companies_SelectById]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Companies_SelectById]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [id],
         [name]
    FROM [dbo].[Companies]
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Companies_Update]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Companies_Update]
(
    @id uniqueidentifier,
    @deleted bit,
    @name nvarchar( 2000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with UPDATE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[Companies]
    SET
         [deleted]=@deleted,
         [id]=@id,
         [name]=@name
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Company_Delete]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Company_Delete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[Companies]
	SET [deleted] = 1
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
CREATE PROCEDURE [dbo].[usp_Company_FullDelete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;
    -- Additonal logic should exist here which prevents orphaned license data for company
    DELETE FROM [dbo].[Companies]
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_Active_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_Active_SelectAll]
(
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
	WHERE [deleted] <> 1
	ORDER BY productId
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*) as totalcount 
	FROM dbo.CompanyProducts 
	WHERE deleted <> 1);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_Active_SelectByCompanyId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_Active_SelectByCompanyId]
(
    @companyId uniqueidentifier,
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([companyId] = @companyId) AND [deleted] <> 1
    )
    ORDER BY productId
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*)
	FROM dbo.CompanyProducts 
	WHERE deleted <> 1 AND [companyId] = @companyId);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_AllDetails_SelectByCompanyId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_AllDetails_SelectByCompanyId]
(
    @companyId uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([companyId] = @companyId) 
    )
    ORDER BY productId

	    SELECT
         p.[deleted],
         p.[description],
         p.[id],
         p.[marketingImage],
         p.[marketingUrl],
         p.[name],
         p.[title]
    FROM [dbo].[Product] p INNER JOIN [dbo].[CompanyProducts] cp ON p.[id] = cp.[productId]
	WHERE cp.[companyId] = @companyId
    ORDER BY p.[id]

END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_Delete]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_Delete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[CompanyProducts]
SET [deleted] = 1
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_FullDelete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;

    DELETE FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_Insert]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_Insert]
(
    @companyId uniqueidentifier,
    @deleted bit,
    @endDate datetime,
    @linkImage nvarchar( 2000) ,
    @linkUrl nvarchar( 2000) ,
    @productId uniqueidentifier,
    @startDate datetime
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with INSERT statements.
    SET NOCOUNT ON;

DECLARE @out_id UNIQUEIDENTIFIER
SET @out_id = newid()

    INSERT INTO [dbo].[CompanyProducts]
    (
[id],
         [companyId],
         [deleted],
         [endDate],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    )
    VALUES
    (
@out_id,
         @companyId,
         @deleted,
         @endDate,
         @linkImage,
         @linkUrl,
         @productId,
         @startDate
    )

SELECT @out_id as id
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_SelectAll]
(
	@limit INT = 100,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
	ORDER BY productId
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*) as totalcount 
	FROM dbo.CompanyProducts);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_SelectByCompanyId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_SelectByCompanyId]
(
    @companyId uniqueidentifier,
	@limit INT = 100,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([companyId] = @companyId) 
    )
    ORDER BY productId
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*)
	FROM dbo.CompanyProducts);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_SelectByEntitlementId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_SelectByEntitlementId]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_CompanyProducts_Update]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_CompanyProducts_Update]
(
    @deleted bit,
    @endDate datetime,
    @startDate datetime,
    @id uniqueidentifier,
    @companyId uniqueidentifier,
    @productId uniqueidentifier,
    @linkImage nvarchar( 2000) ,
    @linkUrl nvarchar( 2000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with UPDATE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[CompanyProducts]
    SET
         [companyId]=@companyId,
         [deleted]=@deleted,
         [endDate]=@endDate,
         [linkImage]=@linkImage,
         [linkUrl]=@linkUrl,
         [productId]=@productId,
         [startDate]=@startDate
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Entitlements_Active_SelectByCompanyId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Entitlements_Active_SelectByCompanyId]
(
    @companyId uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

	SELECT
		[id],
		[name],
		[deleted]
	FROM [dbo].[Companies]
	WHERE [id] = @companyId

    SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([companyId] = @companyId) AND ([deleted] <> 1)
    )
    ORDER BY productId

	SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
	WHERE [deleted] <> 1
    ORDER BY id


END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Entitlements_SelectByCompanyId]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Entitlements_SelectByCompanyId]
(
    @companyId uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

	SELECT
		[id],
		[name],
		[deleted]
	FROM [dbo].[Companies]
	WHERE [id] = @companyId

	SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
    ORDER BY id

	SELECT
         [companyId],
         [deleted],
         [endDate],
         [id],
         [linkImage],
         [linkUrl],
         [productId],
         [startDate]
    FROM [dbo].[CompanyProducts]
    WHERE
    (
         ([companyId] = @companyId) 
    )
    ORDER BY productId
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_Delete]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Product_Delete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[Product]
	SET [deleted] = 1
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
CREATE PROCEDURE [dbo].[usp_Product_FullDelete]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with DELETE statements.
    SET NOCOUNT ON;

    DELETE FROM [dbo].[Product]
	WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_Insert]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Product_Insert]
(
    @deleted bit,
    @description nvarchar(MAX) ,
    @marketingImage nvarchar( 2000) ,
    @marketingUrl nvarchar( 2000) ,
    @name nvarchar( 1000) ,
    @title nvarchar( 1000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with INSERT statements.
    SET NOCOUNT ON;

DECLARE @out_id UNIQUEIDENTIFIER
SET @out_id = newid()

    INSERT INTO [dbo].[Product]
    (
[id],
         [deleted],
         [description],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    )
    VALUES
    (
		 @out_id,
         @deleted,
         @description,
         @marketingImage,
         @marketingUrl,
         @name,
         @title
    )

SELECT @out_id as id
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_SelectByName]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Product_SelectByName]
(
    @name nvarchar( 1000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
    WHERE
    (
         ([name] = @name) 
    )
    ORDER BY name

END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_Update]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Product_Update]
(
    @deleted bit,
    @description nvarchar(MAX) ,
    @title nvarchar( 1000) ,
    @id uniqueidentifier,
    @name nvarchar( 1000) ,
    @marketingImage nvarchar( 2000) ,
    @marketingUrl nvarchar( 2000) 
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with UPDATE statements.
    SET NOCOUNT ON;

    UPDATE [dbo].[Product]
    SET
         [deleted]=@deleted,
         [description]=@description,
         [marketingImage]=@marketingImage,
         [marketingUrl]=@marketingUrl,
         [name]=@name,
         [title]=@title
    WHERE
    (
         ([id] = @id) 
    )
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Products_Active_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Products_Active_SelectAll]
(
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
	WHERE [deleted] <> 1
    ORDER BY name
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*)
	FROM dbo.Product 
	WHERE deleted <> 1);
	RETURN @TOTALROWS

END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Products_SelectAll]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Products_SelectAll]
(
	@limit INT = 10,
	@skip INT = 0
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
    ORDER BY name
	OFFSET @skip ROWS
    FETCH NEXT @limit ROWS ONLY OPTION (RECOMPILE);

	DECLARE @TOTALROWS INT;
	SET @TOTALROWS = (SELECT COUNT(*)
	FROM dbo.Product);
	RETURN @TOTALROWS
END 
GO
/****** Object:  StoredProcedure [dbo].[usp_Products_SelectById]    Script Date: 10/21/2019 11:14:05 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_Products_SelectById]
(
    @id uniqueidentifier
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    SELECT
         [deleted],
         [description],
         [id],
         [marketingImage],
         [marketingUrl],
         [name],
         [title]
    FROM [dbo].[Product]
    WHERE
    (
         ([id] = @id) 
    )
    ORDER BY name

END 
GO
