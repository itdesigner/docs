
import {assert} from 'chai';
import * as sql from 'mssql';
import {Configuration} from '../SharedCode/config';
import { Company, CompanyCollection, EntitlementsRepository, EntitlementViewModel, Product, ProductCollection, ProductViewModel, Link } from '../SharedCode';
import {setEnv} from './environment-set';

let cfg: Configuration = new Configuration();
let pool: sql.ConnectionPool;
let repo: EntitlementsRepository;
let tempKey: string;


async function setRepo() {
    const initPool = new sql.ConnectionPool(cfg.db_config);
    pool = await initPool.connect();
    repo = new EntitlementsRepository(pool);
}

describe('Entitlements Repository', function() {
    before(async() => {
        await setEnv();
        await setRepo();
    });
    describe('Entitlements Repository constructors', function() {
        it('create a Entitlements repository instance', function() {
            const r: EntitlementsRepository = new EntitlementsRepository(pool);
            assert.exists(r, 'could not create a repository');
        });
    });
    describe('getEntitlements', function() {
        it('valid arguments - active only', function() {
            const coKey: string = '9fd109eb-9323-4ca1-88c5-923fc6eab8d6'.toUpperCase();
            return repo.getCompanyEntitlements(coKey, true).then((r) => {
                assert.exists(r, 'nothing returned');
                assert.isAtLeast(r.products.length, 1, 'not enough items returned');
                assert.equal(r.companyId, coKey, 'improper match');
            });
        });
        it('valid arguments - all items', function() {
            const coKey: string = '9fd109eb-9323-4ca1-88c5-923fc6eab8d6'.toUpperCase();
            return repo.getCompanyEntitlements(coKey, false).then((r) => {
                assert.exists(r, 'nothing returned');
                assert.isAtLeast(r.products.length, 1, 'not enough items returned');
                assert.equal(r.companyId, coKey, 'improper match');
            });
        });
        it('null company', async function() {
            const coKey: string = null;
            const r = await repo.getCompanyEntitlements(coKey, false);
            assert.exists(r, 'nothing returned');
            assert.isAtLeast(r.products.length, 1, 'not enough items returned');
            assert.equal(r.companyId, '', 'improper match');
        });
        it('null status - should be the same as all items', function() {
            const coKey: string = '9fd109eb-9323-4ca1-88c5-923fc6eab8d6'.toUpperCase();
            return repo.getCompanyEntitlements(coKey, null).then((r) => {
                assert.exists(r, 'nothing returned');
                assert.isAtLeast(r.products.length, 1, 'not enough items returned');
                assert.equal(r.companyId, coKey, 'improper match');
            });
        });
        it('invalid company', function() {
            const coKey: string = 'bfd109eb-9323-4ca1-88c5-923fc6eab8d6'.toUpperCase();
            return repo.getCompanyEntitlements(coKey, true).then((r) => {
                assert.exists(r, 'nothing returned');
                assert.isAtLeast(r.products.length, 1, 'invalid items returned');
                assert.equal(r.companyId, '', 'improper id match');
            });
        });
        it('cleanup', function() {
            pool.close();
        })
    });
});