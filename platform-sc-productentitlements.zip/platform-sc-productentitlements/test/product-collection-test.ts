
import {assert} from 'chai';
import {Link, Product, ProductCollection} from '../SharedCode';

const id: string = 'ID-123';
const name: string = 'Test Product';
const desc: string = 'Test Product description...';
const title: string = 'Test Product Title';
const marketingUrl: string = 'https://someurl.com';
const marketingImage: string = 'https://someurl.com/image';
const deleted: boolean = false;
function getProducts(): Product[] {
    const col: Product[] = new Array<Product>();
    const p = new Product(id, name, desc, title, marketingUrl, marketingImage, deleted);
    const p2 = new Product('ID-345', 'Second Product', desc, title, marketingUrl, marketingImage, deleted);
    col.push(p);
    col.push(p2);
    return col;
}

describe('Product Collection Model', function() {
    describe('Product collection constructors', function() {
        it('create a Product collection instance', function() {
            const cc: Product[] = getProducts();
            assert.equal(cc.length, 2, 'invalid Product array');
            const col: ProductCollection = new ProductCollection(cc, 2, 4);
            assert.exists(col, 'could not create ProductCollection');
            assert.equal(col.itemCount, 2, 'item count is invalid');
            assert.equal(col.totalCount, 4, 'total count is invalid');
            assert.isUndefined(col.links, 'ProductCollection links invalid');
        });
        it('create an empty ProductCollection instance', function() {
            const col = ProductCollection.Empty();
            assert.exists(col, 'could not create ProductCollection');
            assert.equal(col.itemCount, 0, 'item count is invalid');
            assert.equal(col.totalCount, 0, 'total count is invalid');
            assert.isUndefined(col.links, 'ProductCollection links invalid');
        });
    });
    describe('Product collecgion link functionality', function() {
        it('check empty links on creation', function() {
            const col: ProductCollection = new ProductCollection(getProducts(), 2, 4);
            assert.isUndefined(col.links, 'ProductCollection links invalid');
        });
        it('add a link after creation', function() {
            const col: ProductCollection = new ProductCollection(getProducts(), 2, 4);
            assert.isUndefined(col.links, 'ProductCollection links invalid');
            const link: Link = new Link('https://link', 'self', 'GET');
            col.addLink(link);
            assert.isArray(col.links, 'links collection is invalid size');
            assert.equal(col.links[0].href, 'https://link', 'invalid link href added');
        });
        it('add a second link after creation', function() {
            const col: ProductCollection = new ProductCollection(getProducts(), 2, 4);
            assert.isUndefined(col.links, 'ProductCCollection links invalid');
            const link: Link = new Link('https://link', 'self', 'GET');
            col.addLink(link);
            assert.isArray(col.links, 'links collection is invalid size');
            assert.equal(col.links[0].href, 'https://link', 'invalid link href added');
            const link2: Link = new Link('https://parent', 'parent', 'GET');
            col.addLink(link2);
            assert.isArray(col.links, 'links collection is invalid');
            assert.equal(col.links.length, 2, 'links wrong array size');
            assert.equal(col.links[1].href, 'https://parent', 'invalid link href added');
        });
    });
});