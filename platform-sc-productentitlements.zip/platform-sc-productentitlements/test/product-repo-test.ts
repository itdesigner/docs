
import {assert} from 'chai';
import * as sql from 'mssql';
import {Configuration} from '../SharedCode/config';
import { Product, ProductCollection, ProductRepository, Link } from '../SharedCode';
import {setEnv} from './environment-set';

let cfg: Configuration = new Configuration();
let pool: sql.ConnectionPool;
let repo: ProductRepository;
let tempKey: string;

async function setRepo() {
    const initPool = new sql.ConnectionPool(cfg.db_config);
    pool = await initPool.connect();
    repo = new ProductRepository(pool);
}

describe('Product Repository', function() {
    before(async() => {
        await setEnv();
        await setRepo();
    });
    describe('constructors', function() {
        it('create repository instance', function() {
            const r: ProductRepository = new ProductRepository(pool);
            assert.exists(r, 'could not create a repository');
        });
    });
    describe('find() variations', function() {
        it('find() - NoLimitNoSkip', function() {
            return repo.find().then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.isAtLeast(coll.items.length, 1, 'not enough items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
                tempKey = coll.items[0].id.toUpperCase();
            });
        });
        it('find() - LimitNoSkip', function() {
            return repo.find(1).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('find() - LimitSkip', function() {
            return repo.find(1,1).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
    });
    describe('findActive() variations', function() {
        it('findActive() - NoLimitNoSkip', function() {
            return repo.findActive().then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.isAtLeast(coll.items.length, 1, 'not enough items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('findActive() - LimitNoSkip', function() {
            return repo.findActive(1).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('findActive() - LimitSkip', function() {
            return repo.findActive(1,1).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
    });
    describe('CRUD() variations', function() {
        it('findOne() - valid Product', function() {
            repo.findOne(tempKey).then((c) => {
                assert.exists(c, 'no item returned');
                assert.equal(c.id, tempKey, 'wrong item returned');
            });  
        });
        it('cleanup', function() {
            pool.close();
        })
    });
});