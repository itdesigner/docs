
import {assert} from 'chai';
import * as sql from 'mssql';
import { Company, CompanyCollection, CompanyRepository, Link, ProductCollection, Product, License, LicenseCollection } from '../SharedCode';
import { CompaniesAPI } from '../SharedCode/apis/companies-api';
import {setEnv} from './environment-set';
import { ProductsAPI } from '../SharedCode/apis/products-api';
import { LicensesAPI } from '../SharedCode/apis/licenses-api';
import { EntitlementsAPI } from '../SharedCode/apis/entitlements-api';
import { EntitlementViewModel } from '../SharedCode/viewModels/entitlements-vm';

let tempKey: string;
let co: Company;
let po: Product;
let coid: string = 'B54FC04E-8EAD-450B-B84D-4AAF9056C14B'.toUpperCase();
let li: License;

describe('Companies API', function() {
    before(async() => {
        await setEnv();
    });
    describe('Company API constructors', function() {
        it('create a Company repository instance', async function() {
            const api: CompaniesAPI = new CompaniesAPI();
            assert.exists(api, 'no api created');
        });
    });
    describe('Company Fetch operations', function() {
        it('retrieve companies - no limit no skip', async function() {
            const api: CompaniesAPI = new CompaniesAPI();
            const companies: CompanyCollection = await api.GetCompanies();
            assert.exists(companies, 'no companies returned');
            assert.isArray(companies.items, 'no company array');
            assert.equal(companies.itemCount, companies.items.length, 'item counts fail to match');
        });
        it('retrieve companies - limit no skip', async function() {
            const api: CompaniesAPI = new CompaniesAPI();
            const companies: CompanyCollection = await api.GetCompanies(1);
            assert.exists(companies, 'no companies returned');
            assert.isArray(companies.items, 'no company array');
            assert.equal(companies.itemCount, companies.items.length, 'item counts fail to match');
        });
        it('retrieve companies - limit skip - get 3 from start', async function() {
            const api: CompaniesAPI = new CompaniesAPI();
            const companies: CompanyCollection = await api.GetCompanies(3,0);
            assert.exists(companies, 'no companies returned');
            assert.isArray(companies.items, 'no company array');
            assert.equal(companies.itemCount, companies.items.length, 'item counts fail to match');
        });
        it('retrieve companies - limit skip - repeat get 3 from start', async function() {
            const api: CompaniesAPI = new CompaniesAPI();
            const companies: CompanyCollection = await api.GetCompanies(3,0);
            assert.exists(companies, 'no companies returned');
            assert.isArray(companies.items, 'no company array');
            assert.equal(companies.itemCount, companies.items.length, 'item counts fail to match');
        });
        it('retrieve companies - limit skip - get the next 3', async function() {
            const api: CompaniesAPI = new CompaniesAPI();
            const companies: CompanyCollection = await api.GetCompanies(3,3);
            assert.exists(companies, 'no companies returned');
            assert.isArray(companies.items, 'no company array');
            assert.equal(companies.itemCount, companies.items.length, 'item counts fail to match');
        });
        it('get a single company', async function() {
            const api: CompaniesAPI = new CompaniesAPI();
            const company: Company = await api.GetCompanyById(coid);
            assert.exists(company, 'company not retrieved');
            assert.equal(company.id, coid, 'id is different');
        });
    });
});
describe('Products API', function() {
    before(async() => {
        await setEnv();
    });
    describe('Products API constructors', function() {
        it('create a Company repository instance', async function() {
            const api: ProductsAPI = new ProductsAPI();
            assert.exists(api, 'no api created');
        });
    });
    describe('Product Fetch operations', function() {
        it('retrieve products', async function() {
            const api: ProductsAPI = new ProductsAPI();
            const coll: ProductCollection = await api.GetProducts();
            assert.exists(coll, 'no products returned');
            assert.isArray(coll.items, 'no products array');
            assert.equal(coll.itemCount, coll.items.length, 'item counts fail to match');
            po = coll.items[0];
        });
        it('get a single product', async function() {
            const api: ProductsAPI = new ProductsAPI();
            const p: Product = await api.GetProductById(po.id);
            assert.exists(p, 'product not retrieved');
            assert.equal(po.id, p.id, 'id is different');
            assert.equal(po.name, p.name, 'names are different');
        });
    });
});
describe('Licenses API', function() {
    before(async() => {
        await setEnv();
    });
    describe('Licenses API constructors', function() {
        it('create a Licenses repository instance', async function() {
            const api: LicensesAPI = new LicensesAPI();
            assert.exists(api, 'no api created');
        });
    });
    describe('Licenses Fetch operations', function() {
        it('retrieve Licenses', async function() {
            const api: LicensesAPI = new LicensesAPI();
            const coll: LicenseCollection = await api.GetLicenses(coid, 100, 0);
            assert.exists(coll, 'no licenses returned');
            assert.isArray(coll.items, 'no licenses array');
            assert.equal(coll.itemCount, coll.items.length, 'item counts fail to match');
            li = coll.items[0];
        });
        it('get a single License', async function() {
            const api: LicensesAPI = new LicensesAPI();
            const l: License = await api.GetLicenseById(li.id);
            assert.exists(l, 'licenses not retrieved');
            assert.equal(li.id, l.id, 'id is different');
            assert.equal(li.companyId, l.companyId, 'company ids are different');
            assert.equal(li.productId, l.productId, 'product ids are different');
        });
    });
});
describe('Entitlements API', function() {
    before(async() => {
        await setEnv();
    });
    describe('Entitlements API constructors', function() {
        it('create a Entitlements repository instance', async function() {
            const api: EntitlementsAPI = new EntitlementsAPI();
            assert.exists(api, 'no api created');
        });
    });
    describe('Entitlements Fetch operations', function() {
        it('retrieve Entitlements', async function() {
            const api: EntitlementsAPI = new EntitlementsAPI();
            const id: string = 'B54FC04E-8EAD-450B-B84D-4AAF9056C14B'.toUpperCase();
            const coll: EntitlementViewModel = await api.GetEntitlements(id);
            assert.exists(coll, 'no entitlements returned');
            assert.isArray(coll.products, 'no products array');
            assert.equal(coll.companyId, coid, 'invalid company id');
        });
    });
});