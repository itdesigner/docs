export async function setEnv() {
    process.env['db_database'] = 'ProductEntitlements';
    process.env['db_server'] = 'spheraidentity.database.windows.net';
    process.env['db_username'] = 'idDirector';
    process.env['db_password'] = '5pheraCloud';
    process.env['cache_location'] = 'platform-sc-productentitlements-dev.redis.cache.windows.net';
    process.env['cache_port'] = '6380';
    process.env['cache_key'] = 'FJ1iH6n7OI14VJze+POtKafgQ0Ct92lqq2gtjMYNiLg=';
    process.env['cache_expiry'] = '3600';
}
