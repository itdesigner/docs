
import {assert} from 'chai';
import {License, Product, ProductViewModel} from '../SharedCode';

const id: string = 'ID-123';
const name: string = 'Test Product';
const desc: string = 'Test Product description...';
const title: string = 'Test Product Title';
const marketingUrl: string = 'https://someurl.com';
const marketingImage: string = 'https://someurl.com/image';
const deleted: boolean = false;
function getProduct(): Product {
    const p = new Product(id, name, desc, title, marketingUrl, marketingImage, deleted);
    return p;
}

const lid: string = 'ID-123';
const companyId: string = 'CO-123';
const productId: string = 'PROD-123';
const linkUrl: string = 'https://linkurl';
const linkImage: string = 'https://linkimage';
const startDate: Date = new Date();
const endDate: Date = addDays(startDate, 1);
const ldeleted: boolean = false;
function addDays(date: Date, days: number): Date {
    date.setDate(date.getDate() + days);
    return date;
}
function getLicense(): License {
    const l: License = new License(lid, companyId, productId, linkUrl, linkImage, startDate, endDate, ldeleted);
    return l;
}
function getLicense2(): License {
    const l: License = new License('badlicense', companyId, productId, linkUrl, linkImage, startDate, endDate, ldeleted);
    return l;
}

describe('Product ViewModel', function() {
    describe('constructors', function() {
        it('create a default ProductVM instance', function() {
            const p = getProduct();
            assert.exists(p, 'could not create product');
            const vm = new ProductViewModel(p);
            assert.exists(vm, 'could not create ProductVM');
            assert.equal(vm.id, id, 'ProductVM id is invalid');
            assert.equal(vm.name, name, 'ProductVM name is invalid');
            assert.equal(vm.title, title, 'ProductVM title is invalid');
            assert.equal(vm.description, desc, 'ProductVM description is invalid');
            assert.equal(vm.marketingUrl, marketingUrl, 'ProductVM has invalid marketing url');
            assert.equal(vm.marketingImage, marketingImage, 'ProductVM has invalid marketing image');
            assert.equal(vm.deleted, deleted, 'ProductVM has invalid status');
            assert.isUndefined(vm.links, 'ProductVM links invalid');
            assert.isUndefined(vm.license, 'should not have a license');
        });
        it('add license', function() {
            const g = getLicense();
            assert.exists(g, 'could not create License');
            const p = getProduct();
            assert.exists(p, 'could not create product');
            const vm = new ProductViewModel(p);
            vm.addLicense(g);
            assert.equal(vm.license.id, lid, 'invalid id');
            assert.equal(vm.license.companyId, companyId, 'invalid companyId');
            assert.equal(vm.license.productId, productId, 'invalid productId');
            assert.equal(vm.license.linkUrl, linkUrl, 'invalid linkUrl');
            assert.equal(vm.license.linkImage, linkImage, 'invalid linkImage');
            assert.equal(vm.license.startDate, startDate, 'invalid startDate');
            assert.equal(vm.license.endDate, endDate, 'invalid endDate');
            assert.equal(vm.license.deleted, ldeleted, 'invalid deleted');
        });
        it('try and add null license', function() {
            const g = null;
            const p = getProduct();
            assert.exists(p, 'could not create product');
            const vm = new ProductViewModel(p);
            vm.addLicense(g);
            assert.isUndefined(vm.license, 'null license should not have been added');
        });
    });
});