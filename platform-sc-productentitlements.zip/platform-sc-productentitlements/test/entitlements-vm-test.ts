
import {assert} from 'chai';
import {License, Link, Product, ProductCollection, EntitlementViewModel} from '../SharedCode';
import { ProductViewModel } from '../SharedCode/viewModels/product-vm';

const id: string = 'ID-123';
const name: string = 'Test Product';
const desc: string = 'Test Product description...';
const title: string = 'Test Product Title';
const marketingUrl: string = 'https://someurl.com';
const marketingImage: string = 'https://someurl.com/image';
const deleted: boolean = false;
const coId: string = 'CO-123';
const coName: string = 'TestCompany';
function getProduct(): Product {
    const p = new Product(id, name, desc, title, marketingUrl, marketingImage, deleted);
    return p;
}
function getProduct2(): Product {
    const p = new Product('P-345', 'Another Product', desc, title, marketingUrl, marketingImage, deleted);
    return p;
}
function getPVMs(): ProductViewModel[] {
    const col: ProductViewModel[] = new Array<ProductViewModel>();
    const pvm: ProductViewModel = new ProductViewModel(getProduct());
    const pvm2: ProductViewModel = new ProductViewModel(getProduct2());
    col.push(pvm);
    col.push(pvm2);
    return col;
}

describe('Entitlements View Model', function() {
    describe('Entitlements VM constructors', function() {
        it('create an Entitlements VM instance', function() {
            const cc: ProductViewModel[] = getPVMs();
            assert.equal(cc.length, 2, 'invalid Product array');
            const e: EntitlementViewModel = new EntitlementViewModel(coId, coName);
            assert.exists(e, 'could not create Entitlements VM');
            assert.equal(e.companyId, coId, 'id is invalid');
            assert.equal(e.companyName, coName, 'name is invalid');
            assert.equal(e.products.length, 0, 'Products array invalid');
        });
        it('create an empty Entitlements VM instance', function() {
            const e = EntitlementViewModel.Empty();
            assert.exists(e, 'could not create Entitlements VM');
            assert.equal(e.companyId, '', 'id is invalid');
            assert.equal(e.companyName, '', 'name is invalid');
            assert.equal(e.products.length, 0, 'Products array invalid');
        });
    });
    describe('Add products functionality', function() {
        it('add products after creation', function() {
            const cc: ProductViewModel[] = getPVMs();
            assert.equal(cc.length, 2, 'invalid Product VM array');
            const e: EntitlementViewModel = new EntitlementViewModel(coId, coName);
            assert.exists(e, 'could not create Entitlements VM');
            e.addProducts(cc);
            assert.equal(e.products.length, 2, 'product vm array is invalid');
            assert.equal(e.companyName, coName, 'name is invalid');
            assert.equal(e.companyId, coId, 'id is invalid');
        });
        it('try and add a null product vm collection after creation', function() {
            const cc: ProductViewModel[] = null;
            const e: EntitlementViewModel = new EntitlementViewModel(coId, coName);
            assert.exists(e, 'could not create Entitlements VM');
            e.addProducts(cc);
            assert.equal(e.products.length, 0, 'null products should not have been added');
        });
    });
});