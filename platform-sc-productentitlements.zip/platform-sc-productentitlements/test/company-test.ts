
import {assert} from 'chai';
import {Link, Company} from '../SharedCode';

const id: string = 'ID-123';
const name: string = 'Test Company';
const deleted: boolean = false;
function getCompany(): Company {
    const c = new Company(id, name, deleted);
    return c;
}

describe('Company Model', function() {
    describe('company constructors', function() {
        it('create a default company instance', function() {
            const p = new Company(id, name, deleted);
            assert.exists(p, 'could not create Company');
            assert.equal(p.id, id, 'Company id is invalid');
            assert.equal(p.name, name, 'Company name is invalid');
            assert.equal(p.deleted, deleted, 'Company has invalid status');
            assert.isUndefined(p.links, 'Company links invalid');
        });
        it('create an empty Company instance', function() {
            const p = Company.Empty();
            assert.exists(p, 'could not create Company');
            assert.equal(p.id, '', 'invalid id');
            assert.equal(p.name, '', 'invalid name');
            assert.equal(p.deleted, false, 'invalid status');
        });
        it('create a Company by load', function() {
            const p: Company = Company.Load(getCompany());
            assert.exists(p, 'could not create Company');
            assert.equal(p.id, id, 'Company id is invalid');
            assert.equal(p.name, name, 'Company name is invalid');
            assert.equal(p.deleted, deleted, 'Company has invalid status');
            assert.isUndefined(p.links, 'Company links invalid');
        });
    });
    describe('company link functionality', function() {
        it('check empty links on creation', function() {
            const p: Company = Company.Load(getCompany());
            assert.isUndefined(p.links, 'Company links invalid');
        });
        it('add a link after creation', function() {
            const c: Company = Company.Load(getCompany());
            assert.isUndefined(c.links, 'company links invalid');
            const link: Link = new Link('https://link', 'self', 'GET');
            c.addLink(link);
            assert.isArray(c.links, 'links collection is invalid size');
            assert.equal(c.links[0].href, 'https://link', 'invalid link href added');
        });
        it('add a second link after creation', function() {
            const c: Company = Company.Load(getCompany());
            assert.isUndefined(c.links, 'company links invalid');
            const link: Link = new Link('https://link', 'self', 'GET');
            c.addLink(link);
            assert.isArray(c.links, 'links collection is invalid size');
            assert.equal(c.links[0].href, 'https://link', 'invalid link href added');
            const link2: Link = new Link('https://parent', 'parent', 'GET');
            c.addLink(link2);
            assert.isArray(c.links, 'links collection is invalid');
            assert.equal(c.links.length, 2, 'links wrong array size');
            assert.equal(c.links[1].href, 'https://parent', 'invalid link href added');
        });
    });
});