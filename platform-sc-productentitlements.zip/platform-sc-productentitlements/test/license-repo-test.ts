
import {assert} from 'chai';
import * as sql from 'mssql';
import {Configuration} from '../SharedCode/config';
import { License, LicenseCollection, LicenseRepository, Link } from '../SharedCode';
import {setEnv} from './environment-set';

let cfg: Configuration = new Configuration();
let pool: sql.ConnectionPool;
let repo: LicenseRepository;
let tempKey: string = 'E8ADA616-8843-4396-9E81-886C3C41C7E0'.toUpperCase();
const companyKey: string = 'B54FC04E-8EAD-450B-B84D-4AAF9056C14B'.toUpperCase();

async function setRepo() {
    const initPool = new sql.ConnectionPool(cfg.db_config);
    pool = await initPool.connect();
    repo = new LicenseRepository(pool);
}
function addDays(date: Date, days: number): Date {
    date.setDate(date.getDate() + days);
    return date;
}

describe('License Repository', function() {
    before(async() => {
        await setEnv();
        await setRepo();
    });
    describe('constructors', function() {
        it('create repository instance', function() {
            const r: LicenseRepository = new LicenseRepository(pool);
            assert.exists(r, 'could not create a repository');
        });
    });
    describe('find() variations', function() {
        it('find() - NullLimitullSkip', function() {
            return repo.find(null, null, companyKey).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.isAtLeast(coll.items.length, 1, 'not enough items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('find() - LimitNNullSkip', function() {
            return repo.find(1, null, companyKey).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('find() - LimitSkip', function() {
            return repo.find(1,1, companyKey).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
    });
    describe('findActive() variations', function() {
        it('findActive() - NoLimitNoSkip', function() {
            return repo.findActive(null, null, companyKey).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.isAtLeast(coll.items.length, 1, 'not enough items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('findActive() - LimitNoSkip', function() {
            return repo.findActive(1, null, companyKey).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('findActive() - LimitSkip', function() {
            return repo.findActive(1,1, companyKey).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
    });
    describe('CRUD() variations', function() {
        it('findOne()- valid License', function() {
            repo.findOne(tempKey).then((c) => {
                assert.exists(c, 'no item returned');
                assert.equal(c.id, tempKey, 'wrong item returned');
            });
        });
        it('cleanup', function() {
            pool.close();
        })
    });
});