
import {assert} from 'chai';
import {IdentityKey, Parameter} from '../SharedCode';

const name: string = 'ID-123';
const type: string = 'any';
const value: boolean = false;
const ikey: string = 'ID-123';

describe('Internal Models', function() {
    describe('onstructors', function() {
        it('create a Parameter instance', function() {
            const p = new Parameter(name, type, value);
            assert.exists(p, 'could not create Parameter');
            assert.equal(p.name, name, 'Parameter name is invalid');
            assert.equal(p.value, value, 'Parameter value is invalid');
            assert.equal(p.type, type, 'Parameter has invalid type');
        });
        it('create an IdentityKey instance', function() {
            const p = new IdentityKey(ikey);
            assert.exists(p, 'could not create IdentityKey');
            assert.equal(p.id, ikey, 'invalid id');
        });
    });
});