
import {assert} from 'chai';
import * as sql from 'mssql';
import {Configuration} from '../SharedCode/config';
import { Company, CompanyCollection, CompanyRepository, Link } from '../SharedCode';
import {setEnv} from './environment-set';

let cfg: Configuration = new Configuration();
let pool: sql.ConnectionPool;
let repo: CompanyRepository;
let tempKey: string= '9fd109eb-9323-4ca1-88c5-923fc6eab8d6'.toUpperCase();

async function setRepo() {
    const initPool = new sql.ConnectionPool(cfg.db_config);
    pool = await initPool.connect();
    repo = new CompanyRepository(pool);
}

describe('Company Repository', function() {
    before(async() => {
        await setEnv();
        await setRepo();
    });
    describe('Company Repository constructors', function() {
        it('create a Company repository instance', function() {
            const r: CompanyRepository = new CompanyRepository(pool);
            assert.exists(r, 'could not create a repository');
        });
    });
    describe('find() variations', function() {
        it('find() - NoLimitNoSkip', function() {
            return repo.find().then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.isAtLeast(coll.items.length, 1, 'not enough items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('find() - LimitNoSkip', function() {
            return repo.find(1).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('find() - LimitSkip', function() {
            return repo.find(1,1).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
    });
    describe('findActive() variations', function() {
        it('findActive() - NoLimitNoSkip', function() {
            return repo.findActive().then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.isAtLeast(coll.items.length, 1, 'not enough items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('findActive() - LimitNoSkip', function() {
            return repo.findActive(1).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
        it('findActive() - LimitSkip', function() {
            return repo.findActive(1,1).then((coll) => {
                assert.exists(coll, 'to items returned');
                assert.equal(coll.items.length, 1, 'too many items returned');
                assert.equal(coll.items.length, coll.itemCount, 'item counts dont match');
            });
        });
    });
    describe('CRUD() variations', function() {
        it('findOne() - valid company', function() {
            repo.findOne(tempKey).then((c) => {
                assert.exists(c, 'no company returned');
                assert.equal(c.id, tempKey, 'wrong company returned');
            })
            .catch((err) => {
                console.error('Error: ' + err);
            });
        });
        it('cleanup', function() {
            pool.close();
        })
    });
});