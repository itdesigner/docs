
import {assert} from 'chai';
import {License, LicenseCollection, Link} from '../SharedCode';

const id: string = 'ID-123';
const companyId: string = 'CO-123';
const productId: string = 'PROD-123';
const linkUrl: string = 'https://linkurl';
const linkImage: string = 'https://linkimage';
const startDate: Date = new Date();
const endDate: Date = addDays(startDate, 1);
const deleted: boolean = false;
function addDays(date: Date, days: number): Date {
    date.setDate(date.getDate() + days);
    return date;
}
function getLicenses(): License[]{
    const col: License[] = new Array<License>();
    const l: License = new License(id, companyId, productId, linkUrl, linkImage, startDate, endDate, deleted);
    const l2: License = new License('ID-345', companyId, productId, linkUrl, linkImage, startDate, endDate, deleted);
    col.push(l);
    col.push(l2);
    return col;
}

describe('License Collection Model', function() {
    describe('License collection constructors', function() {
        it('create a License collection instance', function() {
            const cc: License[] = getLicenses();
            assert.equal(cc.length, 2, 'invalid License array');
            const col: LicenseCollection = new LicenseCollection(cc, 2, 4);
            assert.exists(col, 'could not create LicenseCollection');
            assert.equal(col.itemCount, 2, 'item count is invalid');
            assert.equal(col.totalCount, 4, 'total count is invalid');
            assert.isUndefined(col.links, 'LicenseCollection links invalid');
        });
        it('create an empty LicenseCollection instance', function() {
            const col = LicenseCollection.Empty();
            assert.exists(col, 'could not create LicenseCollection');
            assert.equal(col.itemCount, 0, 'item count is invalid');
            assert.equal(col.totalCount, 0, 'total count is invalid');
            assert.isUndefined(col.links, 'LicenseCollection links invalid');
        });
    });
    describe('License collecgion link functionality', function() {
        it('check empty links on creation', function() {
            const col: LicenseCollection = new LicenseCollection(getLicenses(), 2, 4);
            assert.isUndefined(col.links, 'LicenseCollection links invalid');
        });
        it('add a link after creation', function() {
            const col: LicenseCollection = new LicenseCollection(getLicenses(), 2, 4);
            assert.isUndefined(col.links, 'LicenseCollection links invalid');
            const link: Link = new Link('https://link', 'self', 'GET');
            col.addLink(link);
            assert.isArray(col.links, 'links collection is invalid size');
            assert.equal(col.links[0].href, 'https://link', 'invalid link href added');
        });
        it('add a second link after creation', function() {
            const col: LicenseCollection = new LicenseCollection(getLicenses(), 2, 4);
            assert.isUndefined(col.links, 'LicenseCCollection links invalid');
            const link: Link = new Link('https://link', 'self', 'GET');
            col.addLink(link);
            assert.isArray(col.links, 'links collection is invalid size');
            assert.equal(col.links[0].href, 'https://link', 'invalid link href added');
            const link2: Link = new Link('https://parent', 'parent', 'GET');
            col.addLink(link2);
            assert.isArray(col.links, 'links collection is invalid');
            assert.equal(col.links.length, 2, 'links wrong array size');
            assert.equal(col.links[1].href, 'https://parent', 'invalid link href added');
        });
    });
});