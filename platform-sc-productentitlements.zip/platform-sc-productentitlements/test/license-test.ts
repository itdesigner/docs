
import {assert} from 'chai';
import {Link, License} from '../SharedCode';

const id: string = 'ID-123';
const companyId: string = 'CO-123';
const productId: string = 'PROD-123';
const linkUrl: string = 'https://linkurl';
const linkImage: string = 'https://linkimage';
const startDate: Date = new Date();
const endDate: Date = addDays(startDate, 1);
const deleted: boolean = false;
function addDays(date: Date, days: number): Date {
    date.setDate(date.getDate() + days);
    return date;
}
function getLicense(): License {
    const l: License = new License(id, companyId, productId, linkUrl, linkImage, startDate, endDate, deleted);
    return l;
}

describe('License Model', function() {
    describe('license constructors', function() {
        it('create a default company instance', function() {
            const p = new License(id, companyId, productId, linkUrl, linkImage, startDate, endDate, deleted);
            assert.exists(p, 'could not create license');
            assert.equal(p.id, id, 'license id is invalid');
            assert.equal(p.companyId, companyId, 'license company is invalid');
            assert.equal(p.productId, productId, 'license product is invalid');
            assert.equal(p.linkUrl, linkUrl, 'license link url is invalid');
            assert.equal(p.linkImage, linkImage, 'license link image is invalid');
            assert.equal(p.startDate, startDate, 'license startdate is invalid');
            assert.equal(p.endDate, endDate, 'license enddate is invalid');
            assert.equal(p.deleted, deleted, 'license has invalid status');
            assert.isUndefined(p.links, 'license links invalid');
        });
        it('create an empty License instance', function() {
            const p = License.Empty();
            assert.exists(p, 'could not create license');
            assert.equal(p.id, '', 'invalid id');
            assert.equal(p.companyId, '', 'license company is invalid');
            assert.equal(p.productId, '', 'license product is invalid');
            assert.equal(p.linkUrl, '', 'license link url is invalid');
            assert.equal(p.linkImage, '', 'license link image is invalid');
            assert.equal(p.deleted, false, 'invalid status');
        });
        it('create a License by load', function() {
            const p: License = License.Load(getLicense());
            assert.exists(p, 'could not create license');
            assert.equal(p.id, id, 'product id is invalid');
            assert.equal(p.companyId, companyId, 'license company is invalid');
            assert.equal(p.productId, productId, 'license product is invalid');
            assert.equal(p.linkUrl, linkUrl, 'license link url is invalid');
            assert.equal(p.linkImage, linkImage, 'license link image is invalid');
            assert.equal(p.startDate, startDate, 'license startdate is invalid');
            assert.equal(p.endDate, endDate, 'license enddate is invalid');
            assert.equal(p.deleted, deleted, 'license has invalid status');
            assert.isUndefined(p.links, 'license links invalid');
        });
    });
    describe('license link functionality', function() {
        it('check empty links on creation', function() {
            const p: License = License.Load(getLicense());
            assert.isUndefined(p.links, 'license links invalid');
        });
        it('add a link after creation', function() {
            const c: License = License.Load(getLicense());
            assert.isUndefined(c.links, 'license links invalid');
            const link: Link = new Link('https://link', 'self', 'GET');
            c.addLink(link);
            assert.isArray(c.links, 'links collection is invalid size');
            assert.equal(c.links[0].href, 'https://link', 'invalid link href added');
        });
        it('add a second link after creation', function() {
            const l: License = License.Load(getLicense());
            assert.isUndefined(l.links, 'License links invalid');
            const link: Link = new Link('https://link', 'self', 'GET');
            l.addLink(link);
            assert.isArray(l.links, 'links collection is invalid size');
            assert.equal(l.links[0].href, 'https://link', 'invalid link href added');
            const link2: Link = new Link('https://parent', 'parent', 'GET');
            l.addLink(link2);
            assert.isArray(l.links, 'links collection is invalid ');
            assert.equal(l.links.length, 2, 'links wrong array size');
            assert.equal(l.links[1].href, 'https://parent', 'invalid link href added');
        });
    });
});