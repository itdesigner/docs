
import {assert} from 'chai';
import {Link, Product} from '../SharedCode';

const id: string = 'ID-123';
const name: string = 'Test Product';
const desc: string = 'Test Product description...';
const title: string = 'Test Product Title';
const marketingUrl: string = 'https://someurl.com';
const marketingImage: string = 'https://someurl.com/image';
const deleted: boolean = false;
function getProduct(): Product {
    const p = new Product(id, name, desc, title, marketingUrl, marketingImage, deleted);
    return p;
}

describe('Product Model', function() {
    describe('product constructors', function() {
        it('create a default product instance', function() {
            const p = new Product(id, name, desc, title, marketingUrl, marketingImage, deleted);
            assert.exists(p, 'could not create product');
            assert.equal(p.id, id, 'product id is invalid');
            assert.equal(p.name, name, 'product name is invalid');
            assert.equal(p.title, title, 'product title is invalid');
            assert.equal(p.description, desc, 'product description is invalid');
            assert.equal(p.marketingUrl, marketingUrl, 'product has invalid marketing url');
            assert.equal(p.marketingImage, marketingImage, 'product has invalid marketing image');
            assert.equal(p.deleted, deleted, 'product has invalid status');
            assert.isUndefined(p.links, 'product links invalid');
        });
        it('create an empty Product instance', function() {
            const p = Product.Empty();
            assert.exists(p, 'could not create product');
            assert.equal(p.id, '', 'invalid id');
            assert.equal(p.name, '', 'invalid name');
            assert.equal(p.description, '', 'invalid description');
            assert.equal(p.title, '', 'invalid title');
            assert.equal(p.marketingImage, '', 'invalid marketingImage');
            assert.equal(p.marketingUrl, '', 'invalid marketing url');
            assert.equal(p.deleted, false, 'invalid status');
        });
        it('create a product by load', function() {
            const p: Product = Product.Load(getProduct());
            assert.exists(p, 'could not create product');
            assert.equal(p.id, id, 'product id is invalid');
            assert.equal(p.name, name, 'product name is invalid');
            assert.equal(p.title, title, 'product title is invalid');
            assert.equal(p.description, desc, 'product description is invalid');
            assert.equal(p.marketingUrl, marketingUrl, 'product has invalid marketing url');
            assert.equal(p.marketingImage, marketingImage, 'product has invalid marketing image');
            assert.equal(p.deleted, deleted, 'product has invalid status');
            assert.isUndefined(p.links, 'product links invalid');
        });
    });
    describe('product link functionality', function() {
        it('check empty links on creation', function() {
            const p: Product = Product.Load(getProduct());
            assert.isUndefined(p.links, 'product links invalid');
        });
        it('add a link after creation', function() {
            const c: Product = Product.Load(getProduct());
            assert.isUndefined(c.links, 'product links invalid');
            const link: Link = new Link('https://link', 'self', 'GET');
            c.addLink(link);
            assert.isArray(c.links, 'links collection is invalid size');
            assert.equal(c.links[0].href, 'https://link', 'invalid link href added');
        });
        it('add a second link after creation', function() {
            const p: Product = Product.Load(getProduct());
            assert.isUndefined(p.links, 'Product links invalid');
            const link: Link = new Link('https://link', 'self', 'GET');
            p.addLink(link);
            assert.isArray(p.links, 'links collection is invalid size');
            assert.equal(p.links[0].href, 'https://link', 'invalid link href added');
            const link2: Link = new Link('https://parent', 'parent', 'GET');
            p.addLink(link2);
            assert.isArray(p.links, 'links collection is invalid ');
            assert.equal(p.links.length, 2, 'links wrong array size');
            assert.equal(p.links[1].href, 'https://parent', 'invalid link href added');
        });
    });
});