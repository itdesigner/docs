import { AzureFunction, Context, HttpRequest } from '@azure/functions';
import {CompaniesAPI, Company} from '../SharedCode';

/**
 * http trigger for company create call
 * @param context 
 * @param req 
 */
const httpTrigger: AzureFunction = async function (context: Context, req: HttpRequest) {
    try {
        const company = (req.body && req.body.company);
        if (company) {
            const api: CompaniesAPI = new CompaniesAPI();
            const data = await api.AddCompany(company);
            context.res = {
                // status: 200, /* Defaults to 200 */
                headers: { 'Content-Type': 'application/json' },
                body: data
            };
        } else {
            context.res = {
                status: 400,
                body: 'Please pass a company model in the request body',
            };
        }
    } catch (err) {
        context.log.error('ERROR', err);
        context.res = {
            status: 400,
            headers: { 'Content-Type': 'application/json' },
            body: 'Please pass a company model in the request body',
        };
    }
};

export default httpTrigger;
