import { AzureFunction, Context, HttpRequest } from "@azure/functions";
import {CompaniesAPI, Company} from '../SharedCode';

/**
 * http trigger for company fetch call
 * @param context
 * @param req
 */
const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest) {
    try {
        let limit: number = 100;
        let skip: number = 0;
        if (req && req.query && req.query.limit) {
            limit = parseInt(req.query.limit);
        }
        if (req && req.query && req.query.skip) {
            skip = parseInt(req.query.skip);
        }
        const api: CompaniesAPI = new CompaniesAPI();
        const data = await api.GetCompanies(limit, skip);
        context.res = {
            // status: 200, /* Defaults to 200 */
            headers: {
                'Content-Type': 'application/json',
                'X-TotalRecords-Count': data.totalCount,
            },
            body: data,
        };
    } catch (err) {
        context.log.error('ERROR', err);
        // This rethrown exception will be handled by the Functions Runtime and will only fail the individual invocation
        context.res = {
            status: 400,
            body: 'error occurred, please try again later',
        };
    }
};

export default httpTrigger;
