import { AzureFunction, Context, HttpRequest } from '@azure/functions'
import {License, LicensesAPI} from '../SharedCode';

/**
 * http trigger retrieves licenses for a given company call
 * @param context
 * @param req
 */
const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest) {
    try {
        let limit: number = 100;
        let skip: number = 0;
        if (req && req.query && req.query.limit) {
            limit = parseInt(req.query.limit);
        }
        if (req && req.query && req.query.skip) {
            skip = parseInt(req.query.skip);
        }
        if (req && req.params && req.params.id) {
            const companyId = req.params.id;
            if (companyId) {
                const api: LicensesAPI = new LicensesAPI();
                const data = await api.GetLicenses(companyId, limit, skip);
                context.res = {
                    // status: 200, /* Defaults to 200 */
                    headers: {
                        'Content-Type': 'application/json',
                        'X-TotalRecords-Count': data.totalCount,
                    },
                    body: data,
                };
            }
        } else {
            context.res = {
                status: 400,
                body: 'Please pass a companyid on the query string or in the request body',
            };
        }
    } catch (err) {
        context.log.error('ERROR', err);
        // This rethrown exception will be handled by the Functions Runtime and will only fail the individual invocation
        context.res = {
            status: 400,
            body: 'Please pass a companyid on the query string or in the request body',
        };
    }
};

export default httpTrigger;
