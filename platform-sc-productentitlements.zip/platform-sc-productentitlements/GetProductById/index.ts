import { AzureFunction, Context, HttpRequest } from '@azure/functions'
import {Product, ProductsAPI} from '../SharedCode';

/**
 * http trigger for retrieving products by id call
 * @param context
 * @param req
 */
const httpTrigger: AzureFunction = async function(context: Context, req: HttpRequest) {
    try {
        if (req && req.params && req.params.id) {
            const productId = req.params.id;
            if (productId) {
                const api: ProductsAPI = new ProductsAPI();
                const data = await api.GetProductById(productId);
                context.res = {
                    // status: 200, /* Defaults to 200 */
                    headers: { 'Content-Type': 'application/json' },
                    body: data,
                };
            }
        } else {
            context.res = {
                status: 400,
                body: 'Please pass a productid in the path',
            };
        }

    } catch (err) {
        context.log.error('ERROR', err);
        // This rethrown exception will be handled by the Functions Runtime and will only fail the individual invocation
        context.res = {
            status: 400,
            body: 'Please pass a productid in the path',
        };
    }
};

export default httpTrigger;
