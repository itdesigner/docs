import { ChangeType } from './enumerations';

/**
 * interface used by foreign company change messages
 * NOTE: This is used by the SpheraCloud EventHub for
 * messaging based interactions with the API
 */
export interface ICompanyChange {
    /**
     * The primary company key
     *
     * @type {string}
     * @memberof ICompanyChange
     */
    id: string;
    /**
     * The company name
     *
     * @type {string}
     * @memberof ICompanyChange
     */
    name: string;
    /**
     * the type of change that has occurred
     */
    changeType: ChangeType;

}
