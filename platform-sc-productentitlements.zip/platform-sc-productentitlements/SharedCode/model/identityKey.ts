/**
 * Identity key object
 *
 * @export
 * @class IdentityKey
 */
export class IdentityKey {
    public id: string;
    constructor(id: string) {
        this.id = id;
    }
}
