/**
 * HATEOAS link object
 */
export class Link {
    /**
     * uri reference to resource
     */
    public href: string;
    /**
     * relation to resource
     */
    public rel: string;
    /**
     * operation supported
     */
    public type?: LinkTypeEnum;
    constructor(href: string, rel: string, type: LinkTypeEnum) {
        this.href = href;
        this.rel = rel;
        this.type = type;
    }
}
export type LinkTypeEnum = 'GET' | 'POST' | 'PUT';
export const linkTypeEnum = {
    GET: 'GET' as LinkTypeEnum,
    POST: 'POST' as LinkTypeEnum,
    PUT: 'PUT' as LinkTypeEnum,
};
