
import {Link, LinkTypeEnum} from '../model';

/**
 * The Entitlements Product Model
 */
export class Product {

    /**
     * return an empty product
     */
    public static Empty(): Product {
        return new Product('', '', '', '', '', '', false);
    }
    /**
     * returns a product loaded from another object
     * @param p Product
     */
    public static Load(p: Product): Product {
        return new Product(p.id, p.name, p.description, p.title, p.marketingUrl, p.marketingImage, p.deleted);
    }

    /**
     * The primary key for the product
     *
     * @type {string}
     * @memberof Product
     */
    public id: string;
    /**
     * The name of the product
     *
     * @type {string}
     * @memberof Product
     */
    public name: string;
    /**
     * The description of the product
     *
     * @type {string}
     * @memberof Product
     */
    public description: string;
    /**
     * The title for the product
     *
     * @type {string}
     * @memberof Product
     */
    public title: string;
    /**
     * The default marketing url for the product
     *
     * @type {string}
     * @memberof Product
     */
    public marketingUrl: string;
    /**
     * The default marketing image for the product
     *
     * @type {string}
     * @memberof Product
     */
    public marketingImage: string;
    /**
     * Flag indicating whether this producted has been removed from the system (deleted)
     *
     * @type {boolean}
     * @memberof Product
     */
    public deleted: boolean;
    /**
     * A collection of HATEOS links associated with this entry
     *
     * @type {Link[]}
     * @memberof Product
     */
    public links?: Link[];

    /**
     * Creates an instance of Product.
     * @param {string} id
     * @param {string} name
     * @param {string} description
     * @param {string} title
     * @param {string} marketingUrl
     * @param {string} marketingImage
     * @param {boolean} deleted
     * @memberof Product
     */
    constructor(
        id: string,
        name: string,
        description: string,
        title: string,
        marketingUrl: string,
        marketingImage: string,
        deleted: boolean,
        ) {

            this.id = id;
            this.name = name;
            this.description = description;
            this.title = title;
            this.marketingUrl = marketingUrl;
            this.marketingImage = marketingImage;
            this.deleted = deleted;
    }

    /**
     * Adds a HATEOS link to the Product
     *
     * @param {Link} link
     * @memberof Product
     */
    public addLink(link: Link): void {
        if (this.links == null) {
            this.links = new Array<Link>();
        }
        this.links.push(link);
    }
}
