
import {Link, LinkTypeEnum} from '../model';

/**
 * The Entitlements License Model
 *
 * @export
 * @class License
 */
export class License {

    /**
     * returns an empty license
     */
    public static Empty(): License {
        return new License('', '', '', '', '', new Date(), new Date(), false);
    }
    /**
     * returns a license populated from another object
     * @param l license
     */
    public static Load(l: License): License {
        return new License(l.id, l.companyId, l.productId, l.linkUrl, l.linkImage, l.startDate, l.endDate, l.deleted);
    }
    /**
     * The primary license key
     *
     * @type {string}
     * @memberof License
     */
    public id: string;
    /**
     * The company identifier
     *
     * @type {string}
     * @memberof License
     */
    public companyId: string;
    /**
     * The product identifier
     *
     * @type {string}
     * @memberof License
     */
    public productId: string;
    /**
     * The link to the company-specific product url
     *
     * @type {string}
     * @memberof License
     */
    public linkUrl: string;
    /**
     * The link to company-specific product image
     *
     * @type {string}
     * @memberof License
     */
    public linkImage: string;
    /**
     * License start Date
     *
     * @type {Date}
     * @memberof License
     */
    public startDate: Date;
    /**
     * License end date
     *
     * @type {Date}
     * @memberof License
     */
    public endDate: Date;
    /**
     * Flag indicating whether the license has been removed (deleted)
     *
     * @type {boolean}
     * @memberof License
     */
    public deleted: boolean;
    /**
     * Collection of HATEOS links associated with this resource
     *
     * @type {Link[]}
     * @memberof License
     */
    public links?: Link[];

    /**
     * Creates an instance of License.
     * @param {string} id
     * @param {string} companyId
     * @param {string} productId
     * @param {string} linkUrl
     * @param {string} linkImage
     * @param {Date} startDate
     * @param {Date} endDate
     * @param {boolean} deleted
     * @memberof License
     */
    constructor(id: string, companyId: string, productId: string, linkUrl: string, linkImage: string, startDate: Date, endDate: Date, deleted: boolean) {
        this.id = id;
        this.companyId = companyId;
        this.productId = productId;
        this.linkUrl = linkUrl;
        this.linkImage = linkImage;
        this.startDate = startDate;
        this.endDate = endDate;
        this.deleted = deleted;
    }

    /**
     * Adds a HATEOS link to the License
     *
     * @param {Link} link
     * @memberof Product
     */
    public addLink(link: Link): void {
        if (this.links == null) {
            this.links = new Array<Link>();
        }
        this.links.push(link);
    }
}
