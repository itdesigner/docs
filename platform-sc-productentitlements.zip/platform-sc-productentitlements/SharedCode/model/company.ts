
import {Link, LinkTypeEnum} from '../model';

/**
 * The Entitlements Company Model
 *
 * @export
 * @class Company
 */
export class Company {

    /**
     * return an empty company
     */
    public static Empty(): Company {
        return new Company('', '', false)
    }
    /**
     * returns a company loaded from another object
     * @param c Company
     */
    public static Load(c: Company): Company {
        return new Company(c.id, c.name, c.deleted);
    }

    /**
     * The primary company key
     *
     * @type {string}
     * @memberof Company
     */
    public id: string;
    /**
     * The company name
     *
     * @type {string}
     * @memberof Company
     */
    public name: string;
    /**
     * Flag indicating whether the company has been removed (deleted)
     *
     * @type {boolean}
     * @memberof Company
     */
    public deleted: boolean;
    /**
     * Collection of HATEOS links associated with this resource
     *
     * @type {Link[]}
     * @memberof Company
     */
    public links?: Link[];

    /**
     * Creates an instance of Company.
     * @param {string} id
     * @param {string} name
     * @param {boolean} deleted
     * @memberof Company
     */
    constructor(id: string, name: string, deleted: boolean) {
        this.id = id;
        this.name = name;
        this.deleted = deleted;
    }

    /**
     * Adds a HATEOS link to the Company
     *
     * @param {Link} link
     * @memberof Product
     */
    public addLink(link: Link): void {
        if (this.links == null) {
            this.links = new Array<Link>();
        }
        this.links.push(link);
    }
}