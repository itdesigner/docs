
/**
 * Change type enumeration
 */
export enum ChangeType {
    /**
     * represents a new object change
     */
    new = 'new',
    /**
     * represents a deleted object change
     */
    deleted = 'deleted',
    /**
     * represents an updated object change
     */
    updated = 'Updated',
}
