import { ChangeType } from './enumerations';

/**
 * interface used by foreign product change messages
 * NOTE: This is used by the SpheraCloud EventHub for
 * messaging based interactions with the API
 */
export interface IProductChange {
    /**
     * The primary key for the product
     *
     * @type {string}
     * @memberof IProductChange
     */
    id: string;
    /**
     * The name of the product
     *
     * @type {string}
     * @memberof IProductChange
     */
    name: string;
    /**
     * The description of the product
     *
     * @type {string}
     * @memberof IProductChange
     */
    description: string;
    /**
     * The title for the product
     *
     * @type {string}
     * @memberof IProductChange
     */
    title: string;
    /**
     * The default marketing url for the product
     *
     * @type {string}
     * @memberof IProductChange
     */
    marketingUrl: string;
    /**
     * The default marketing image for the product
     *
     * @type {string}
     * @memberof IProductChange
     */
    marketingImage: string;
    /**
     * Flag indicating whether this producted has been removed from the system (deleted)
     *
     * @type {boolean}
     * @memberof IProductChange
     */
    deleted: boolean;
    /**
     * the type of change that has occurred
     */
    changeType: ChangeType;

}
