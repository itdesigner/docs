import { ChangeType } from './enumerations';

/**
 * interface used by foreign license change messages
 * NOTE: This is used by the SpheraCloud EventHub for
 * messaging based interactions with the API
 */
export interface ILicenseChange {
    /**
     * The primary license key
     *
     * @type {string}
     * @memberof ILicenseChange
     */
    id: string;
    /**
     * The company identifier
     *
     * @type {string}
     * @memberof ILicenseChange
     */
    companyId: string;
    /**
     * The product identifier
     *
     * @type {string}
     * @memberof ILicenseChange
     */
    productId: string;
    /**
     * The link to the company-specific product url
     *
     * @type {string}
     * @memberof ILicenseChange
     */
    linkUrl: string;
    /**
     * The link to company-specific product image
     *
     * @type {string}
     * @memberof ILicenseChange
     */
    linkImage: string;
    /**
     * License start Date
     *
     * @type {Date}
     * @memberof ILicenseChange
     */
    startDate: Date;
    /**
     * License end date
     *
     * @type {Date}
     * @memberof ILicenseChange
     */
    endDate: Date;
    /**
     * Flag indicating whether the license has been removed (deleted)
     *
     * @type {boolean}
     * @memberof ILicenseChange
     */
    deleted: boolean;
    /**
     * the type of change that has occurred
     */
    changeType: ChangeType;

}
