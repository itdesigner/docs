import { Link, Product } from '../model';
import { ICollection } from './ICollection';

/*
 * viewmodel for a collection of products
 * 
 */
export class ProductCollection implements ICollection<Product> {
    /**
     * creates an empty CompanyCollection
     */
    public static Empty(): ProductCollection {
        return new ProductCollection(new Array<Product>(), 0, 0);
    }
    /**
     * the products in the collection
     *
     * @type {Product[]}
     * @memberof ProductCollection
     */
    public items: Product[];
    /**
     * the number of items in this collection
     *
     * @type {number}
     * @memberof ProductCollection
     */
    public itemCount: number;
    /**
     * the total number of items that exist as part of the extended collection
     *
     * @type {number}
     * @memberof ProductCollection
     */
    public totalCount: number;
    /**
     * HATEOS links for next and previous portions of collection
     *
     * @type {Link[]}
     * @memberof ProductCollection
     */
    public links?: Link[];

    constructor(items: Product[], itemCount: number, totalCount: number) {
        this.items = items;
        this.itemCount = itemCount;
        this.totalCount = totalCount;
    }
    /**
     * Adds a HATEOS link for the collection
     *
     * @param {Link} link
     * @memberof ProductCollection
     */
    public addLink(link: Link): void {
        if (this.links == null) {
            this.links = new Array<Link>();
        }
        this.links.push(link);
    }
}