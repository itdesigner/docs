import {Link} from '../model';

export interface ICollection<T> {
    items: T[];
    itemCount: number;
    totalCount: number;
    links?: Link[];
}