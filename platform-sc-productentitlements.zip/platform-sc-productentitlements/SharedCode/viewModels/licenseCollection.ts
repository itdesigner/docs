import { License, Link } from '../model';
import { ICollection } from './ICollection';

/*
 * viewmodel for a collection of licenses
 *
 */
export class LicenseCollection implements ICollection<License> {
    /**
     * creates an empty Licenseollection
     */
    public static Empty(): LicenseCollection {
        return new LicenseCollection(new Array<License>(), 0, 0);
    }
    /**
     * the licenses in the collection
     *
     * @type {License[]}
     * @memberof LicenseCollection
     */
    public items: License[];
    /**
     * the number of items in this collection
     *
     * @type {number}
     * @memberof LicenseCollection
     */
    public itemCount: number;
    /**
     * the total number of items that exist as part of the extended collection
     *
     * @type {number}
     * @memberof LicenseCollection
     */
    public totalCount: number;
    /**
     * HATEOS links for next and previous portions of collection
     *
     * @type {Link[]}
     * @memberof LicenseCollection
     */
    public links?: Link[];

    constructor(items: License[], itemCount: number, totalCount: number) {
        this.items = items;
        this.itemCount = itemCount;
        this.totalCount = totalCount;
    }
    /**
     * Adds a HATEOS link for the collection
     *
     * @param {Link} link
     * @memberof LicenseCollection
     */
    public addLink(link: Link): void {
        if (this.links == null) {
            this.links = new Array<Link>();
        }
        this.links.push(link);
    }
}