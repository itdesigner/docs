import {License, Product} from '../model';
import {ProductViewModel} from './index';
/**
 * The Entitlements ViewModel
 *
 * @export
 * @class EntitlementViewModel
 */
export class EntitlementViewModel {

    public static Empty(): EntitlementViewModel {
        return new EntitlementViewModel('', '');
    }
    /**
     * the company id
     *
     * @type {string}
     * @memberof EntitlementViewModel
     */
    public companyId: string;
    /**
     * the company name
     *
     * @type {string}
     * @memberof EntitlementViewModel
     */
    public companyName: string;
    /**
     * collection of company products
     *
     * @type {ProductViewModel}
     * @memberof EntitlementViewModel
     */
    public products: ProductViewModel[];

    /**
     * constructor for entitlement viewmodel
     * @param id company id
     * @param name company name
     */
    constructor(id: string, name: string) {
       this.companyId = id;
       this.companyName = name;
       this.products = new Array<ProductViewModel>();
    }

    /**
     * adds products to the Entitlements view model
     * @param products product viewmodel collection
     */
    public addProducts(products: ProductViewModel[]) {
        if (products != null) {
            this.products = products;
        }
    }
}
