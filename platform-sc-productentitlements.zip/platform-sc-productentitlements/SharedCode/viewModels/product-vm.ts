import {License, Product} from '../model';

/**
 * The Product ViewModel
 *
 * @export
 * @class ProductViewModel
 * @extends {Product}
 */
export class ProductViewModel extends Product {
    /**
     * The optional License data for the product
     *
     * @type {License}
     * @memberof ProductViewModel
     */
    public license?: License;

    /**
     * Creates an instance of ProductViewModel.
     * @param {Product} product
     * @memberof ProductViewModel
     */
    constructor(product: Product) {
        super(product.id, product.name, product.description, product.title, product.marketingUrl, product.marketingImage, product.deleted);
        this.links = product.links;
    }

    /**
     * Adds a license to the Product Entitlement
     *
     * @param {License} lic
     * @memberof ProductViewModel
     */
    public addLicense(lic: License) {
        if (lic != null) {
            this.license = new License(lic.id, lic.companyId, lic.productId, lic.linkUrl, lic.linkImage, lic.startDate, lic.endDate, lic.deleted);
            this.license.links = lic.links;
        }
    }
}
