import * as sql from 'mssql';
import { Configuration } from '../config';
import { Company, IdentityKey, Link, linkTypeEnum } from '../model';
import { CompanyRepository } from '../repositories';
import { CompanyCollection} from '../viewModels';
import {cache, cachepromise} from './cache-decorator';


/**
 * Companies API class
 */
export class CompaniesAPI {

    /**
     * configuration object
     */
    private cfg: Configuration = new Configuration();
    /**
     * internal connection pool
     */
    private pool: sql.ConnectionPool;

    /**
     * Retrieves the list of companies
     */
    @cachepromise('companies')
    public async GetCompanies(limit?: number, skip?: number): Promise<CompanyCollection> {
        return new Promise<CompanyCollection>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                if (!limit) { limit = 100; }
                if (!skip) { skip = 0; }
                const repo: CompanyRepository = new CompanyRepository(this.pool);
                repo.findActive(limit, skip).then((collection) => {
                    const items: Company[] = collection.items;
                    items.forEach((element) => {
                        const l: Link = new Link('/api/companies/' + element.id, 'self', linkTypeEnum.GET);
                        element.addLink(l);
                    });
                    if (limit != null && skip != null) {
                        if (collection.totalCount > skip + limit) {
                            const nextSkip: number = skip + limit;
                            const lnext: Link = new Link('/api/companies?limit=' + limit + '&skip=' + nextSkip, 'next', linkTypeEnum.GET);
                            collection.addLink(lnext);
                        }
                        if (skip > 0) {
                            const prevSkip = ((skip - limit) > 0) ? (skip - limit) : 0;
                            const lprev: Link = new Link('/api/companies?limit=' + limit + '&skip=' + prevSkip, 'previous', linkTypeEnum.GET);
                            collection.addLink(lprev);
                        }
                    }
                    resolve(collection);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /**
     * retrieves a specific company by id
     * @param id company id
     */
    public async GetCompanyById(id: string): Promise<Company> {
        return new Promise<Company>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: CompanyRepository = new CompanyRepository(this.pool);
                repo.findOne(id).then((item: Company) => {
                    const l: Link = new Link('/companies/' + item.id, 'self', linkTypeEnum.GET);
                    item.addLink(l);
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /**
     * adds a new company
     * @param product company model
     */
    public async AddCompany(company: Company): Promise<IdentityKey> {
        return new Promise<IdentityKey>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: CompanyRepository = new CompanyRepository(this.pool);
                repo.create(company).then((item: IdentityKey) => {
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /**
     * removes a company
     * @param id company id
     */
    public async RemoveCompany(id: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: CompanyRepository = new CompanyRepository(this.pool);
                repo.delete(id).then((item: boolean) => {
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /**
     * updates a Company
     * @param id Company id
     * @param product the Company model
     */
    public async UpdateCompany(id: string, company: Company): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: CompanyRepository = new CompanyRepository(this.pool);
                repo.update(id, company).then((item: boolean) => {
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /**
     * creates a connection pool
     * @param config config object
     */
    private async createPool(config: sql.config) {
        const initPool = new sql.ConnectionPool(config);
        this.pool = await initPool.connect();
    }
}
