import * as sql from 'mssql';
import {Configuration} from '../config';
import { EntitlementsRepository } from '../repositories';
import { EntitlementViewModel } from '../viewModels';
import { cachepromise } from './cache-decorator';

/**
 * entitlements API class
 */
export class EntitlementsAPI {
    /**
     * configuration object
     */
    private cfg: Configuration = new Configuration();
    /**
     * internal connection pool
     */
    private pool: sql.ConnectionPool;

    /**
     * Retrieves the list of product entitlements for a company
     * @param companyId the company id
     */
    @cachepromise('entitlements', 3600)
    public async GetEntitlements(companyId: string): Promise<EntitlementViewModel> {
        return new Promise<EntitlementViewModel>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const eRepo: EntitlementsRepository = new EntitlementsRepository(this.pool);
                eRepo.getCompanyEntitlements(companyId, false).then((entitlement: EntitlementViewModel) => {
                    resolve(entitlement);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        })
    }
    /**
     * creates a connection pool
     * @param config config object
     */
    private async createPool(config: sql.config) {
        const initPool = new sql.ConnectionPool(config);
        this.pool = await initPool.connect();
    }
}
