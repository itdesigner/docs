import * as md5 from 'md5';
import * as serialize from 'serialize-javascript';
import { Cache } from './cache';

export type IPreInjectFunction = (name: string, ...args: any[]) => any;
export type IPostInjectFunction = (name: string, args: any, expireSeconds: number) => any;
export type INamingFunction = (baseName: string, ...args: any[]) => string;

/**
 * Generates a repeatable unique key name for a given call
 * @param baseName - the basename for the cache key
 * @param args - an arguments collection
 */
const generateKey: INamingFunction = (baseName: string, context: any, ...args: any[] ): string => {
    const callMap = { baseName, context, args };
    const serializedKey: string = serialize(callMap);
    const hashKey: string = md5(serializedKey);
    return baseName + '-' + hashKey;
};
/**
 * check the cache for an item matching the provided key
 * @param cacheItemName  - cache item key name
 * @param args
 */
const cacheCheck: IPreInjectFunction = async (cacheItemName: string, ...args: any[]): Promise<any> => {
    const c: Cache = new Cache();
    const result = await c.getValue(cacheItemName);
    if (result) {
        const item = JSON.parse(result);
        return item;
    } else {
        return null;
    }
};
/**
 * update the named cache key item with the supplied value
 * @param cacheItemName  - cache item key name
 * @param args - cache item value
 * @param expiry - expiration time in seconds (optional)
 */
const cacheExUpdate: IPostInjectFunction = async (cacheItemName: string, args: any, expiry?: number): Promise<any> => {
    const c: Cache = new Cache();
    // convert item to JSON format
    const jsonItem = JSON.stringify(args);
    const result = await c.setExValue(cacheItemName, jsonItem, expiry);
    return args;
};

/**
 * attempts to retrieve a cached item with the given key.  If found, returns item; else, completes the original call and updates cache.
 * @param baseKey  - cache item key base (actual key is a hash of this and several other items including arguments and current context)
 */
export function cachepromise(baseKey: string, expireSeconds?: number) {
    return (target: object, propertyKey: string, descriptor: TypedPropertyDescriptor<any>) => {
        const originalMethod = descriptor.value;
        descriptor.value = async function(...args: any[]) {
            try {
                const nm: string = generateKey(baseKey, this, args);
                let cachedItem: any = args;
                cachedItem = (cacheCheck  && typeof(cacheCheck) === 'function') ?  await cacheCheck(nm, args) : args;
                if (cachedItem) {
                    // found item in the cache - simply don't call the rest of this function
                    return cachedItem;
                } else {
                    const result = await originalMethod.apply(this, args);
                    if (result) {
                        if (cacheExUpdate && typeof(cacheExUpdate) === 'function') {
                            await cacheExUpdate(nm, result, expireSeconds);
                        }
                        return result;
                    } else {
                        throw new Error('could not evaluate promise');
                    }
                }
            } catch (ex) {
                throw ex;
            }
        };
    };
}
/**
 * attempts to retrieve a cached item with the given key.  If found, returns item; else, completes the original call and updates cache.
 * @param cacheItemName  - cache item key
 */
export function cache(baseKey?: string, expireSeconds?: number) {
    return (target: object, propertyKey: string, descriptor: TypedPropertyDescriptor<any>) => {
        const originalMethod = descriptor.value;
        descriptor.value = function(...args: any[]) {
            try {
                const nm: string = generateKey(baseKey, this, args);
                const cacheItem = (cacheCheck  && typeof(cacheCheck) === 'function') ? cacheCheck(nm, args) : args;
                if (cacheItem) {
                    return cacheItem;
                } else {
                    const result = originalMethod.apply(this, args);
                    const newResult =  (cacheExUpdate && typeof(cacheExUpdate) === 'function') ? cacheExUpdate(nm, result, expireSeconds) : result;
                    return result;
                }
            } catch (ex) {
                throw ex;
            }
        };
        return descriptor;
    };
}
