import * as sql from 'mssql';
import {Configuration} from '../config';
import { IdentityKey, Link, linkTypeEnum, Product } from '../model';
import { ProductRepository } from '../repositories';
import { ProductCollection } from '../viewModels';
import { cachepromise } from './cache-decorator';

/**
 * products API class
 */
export class ProductsAPI {
    /**
     * configuration object
     */
    private cfg: Configuration = new Configuration();
    /**
     * internal connection pool
     */
    private pool: sql.ConnectionPool;

    /**
     * Retrieves the list of products
     */
    @cachepromise('products', 21600)
    public async GetProducts(limit?: number, skip?: number): Promise<ProductCollection> {
        return new Promise<ProductCollection>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: ProductRepository = new ProductRepository(this.pool);
                repo.findActive(limit, skip).then((collection) => {
                    collection.items.forEach((item) => {
                        let l: Link = new Link('/products/' + item.id, 'self', linkTypeEnum.GET);
                        item.addLink(l);
                    });
                    if (limit != null && skip != null) {
                        if (collection.totalCount > skip + limit) {
                            const nextSkip: number = skip + limit;
                            const lnext: Link = new Link('/api/products?limit=' + limit + '&skip=' + nextSkip, 'next', linkTypeEnum.GET);
                            collection.addLink(lnext);
                        }
                        if (skip > 0) {
                            const prevSkip = ((skip - limit) > 0) ? (skip - limit) : 0;
                            const lprev: Link = new Link('/api/products?limit=' + limit + '&skip=' + prevSkip, 'previous', linkTypeEnum.GET);
                            collection.addLink(lprev);
                        }
                    }
                    resolve(collection);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * retrieves a specific product by id
     * @param id product id
     */
    public async GetProductById(id: string): Promise<Product> {
        return new Promise<Product>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: ProductRepository = new ProductRepository(this.pool);
                repo.findOne(id).then((item: Product) => {
                    let l: Link = new Link('/products/' + item.id, 'self', linkTypeEnum.GET);
                    item.addLink(l);
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * adds a new product
     * @param product product model
     */
    public async AddProduct(product: Product): Promise<IdentityKey> {
        return new Promise<IdentityKey>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: ProductRepository = new ProductRepository(this.pool);
                repo.create(product).then((item: IdentityKey) => {
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * updates a product
     * @param id product id
     * @param product the product model
     */
    public async UpdateProduct(id: string, product: Product): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: ProductRepository = new ProductRepository(this.pool);
                repo.update(id, product).then((item: boolean) => {
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * removes a product
     * @param id product id
     */
    public async RemoveProduct(id: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: ProductRepository = new ProductRepository(this.pool);
                repo.delete(id).then((item: boolean) => {
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /**
     * creates a connection pool
     * @param config config object
     */
    private async createPool(config: sql.config) {
        const initPool = new sql.ConnectionPool(config);
        this.pool = await initPool.connect();
    }
}
