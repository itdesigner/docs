import * as redis from 'redis';
import * as util from 'util';
import {Configuration} from '../config';

/**
 * the base Cache class
 * this is a lightweight caching framework for typescript using redis
 */
export class Cache {
    private redisClient: redis.RedisClient;
    private cfg: Configuration = new Configuration();

    private getAsync: any;
    private setExAsync: any;

    /**
     * default constructor for the cache
     */
    constructor() {
        this.setClient(this.cfg);
    }
    /**
     * Retrieves a cached value with a given key
     * @param key - the cache item key to find and return
     */
    public async getValue(key: string) {
        return await this.getAsync(key);
    }
    /**
     * Sets a item in the cache with a given cache item key and value
     * @param key - the key name for the cached item
     * @param value - the value of the cached item
     * @param expiry - expiration time in seconds (optional)
     */
    public async setExValue(key: string, value: any, expiry?: number) {
        if (!expiry) { expiry = this.cfg.cache_expiry; }
        return await this.setExAsync(key, expiry, value);
    }
    /**
     * used to configure and setup the caching components
     * @param config - configuration object
     */
    private setClient(config: Configuration) {
        this.redisClient = redis.createClient(
            this.cfg.cache_port,
            this.cfg.cache_location,
            {auth_pass: this.cfg.cache_key, tls: {servername: this.cfg.cache_location}},
        );
        this.getAsync = util.promisify(this.redisClient.get).bind(this.redisClient);
        this.setExAsync = util.promisify(this.redisClient.setex).bind(this.redisClient);
    }
}


