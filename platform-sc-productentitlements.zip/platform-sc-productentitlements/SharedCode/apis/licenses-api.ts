import * as sql from 'mssql';
import {Configuration} from '../config';
import { IdentityKey, License, Link, linkTypeEnum } from '../model';
import { LicenseRepository } from '../repositories';
import { LicenseCollection } from '../viewModels';
import { cachepromise } from './cache-decorator';

/**
 * licenses API class
 */
export class LicensesAPI {
    /**
     * configuration object
     */
    private cfg: Configuration = new Configuration();
    /**
     * internal connection pool
     */
    private pool: sql.ConnectionPool;

    /**
     * list of licenses for a specific company
     * @param id company id
     */
    @cachepromise('licenses', 3600)
    public async GetLicenses(id: string, limit?: number, skip?: number): Promise<LicenseCollection> {
        return new Promise<LicenseCollection>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: LicenseRepository = new LicenseRepository(this.pool);
                if (!skip) { skip = 0; }
                if (!limit) { limit = 100; }
                repo.findActive(limit, skip, id).then((collection) => {
                    collection.items.forEach((item) => {
                        const l: Link = new Link('/licenses/' + item.id, 'self', linkTypeEnum.GET);
                        item.addLink(l);
                    });
                    if (limit != null && skip != null) {
                        if (collection.totalCount > skip + limit) {
                            const nextSkip: number = skip + limit;
                            const lnext: Link = new Link('/api/companies?limit=' + limit + '&skip=' + nextSkip, 'next', linkTypeEnum.GET);
                            collection.addLink(lnext);
                        }
                        if (skip > 0) {
                            const prevSkip = ((skip - limit) > 0) ? (skip - limit) : 0;
                            const lprev: Link = new Link('/api/companies?limit=' + limit + '&skip=' + prevSkip, 'previous', linkTypeEnum.GET);
                            collection.addLink(lprev);
                        }
                    }
                    resolve(collection);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * retrieves a specific License by id
     * @param id License id
     */
    public async GetLicenseById(id: string): Promise<License> {
        return new Promise<License>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: LicenseRepository = new LicenseRepository(this.pool);
                repo.findOne(id).then((item: License) => {
                    let l: Link = new Link('/licenses/' + item.id, 'self', linkTypeEnum.GET);
                    item.addLink(l);
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * adds a new License
     * @param product License model
     */
    public async AddLicense(lic: License): Promise<IdentityKey> {
        return new Promise<IdentityKey>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: LicenseRepository = new LicenseRepository(this.pool);
                repo.create(lic).then((item: IdentityKey) => {
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * updates a License
     * @param id License id
     * @param product the License model
     */
    public async UpdateLicense(id: string, lic: License): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: LicenseRepository = new LicenseRepository(this.pool);
                repo.update(id, lic).then((item: boolean) => {
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }
    /**
     * removes a License
     * @param id License id
     */
    public async RemoveLicense(id: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this.createPool(this.cfg.db_config).then(() => {
                const repo: LicenseRepository = new LicenseRepository(this.pool);
                repo.delete(id).then((item: boolean) => {
                    resolve(item);
                })
                .catch((sqlErr) => {
                    reject(sqlErr);
                });
            })
            .catch((connErr) => {
                reject(connErr);
            });
        });
    }

    /**
     * creates a connection pool
     * @param config config object
     */
    private async createPool(config: sql.config) {
        const initPool = new sql.ConnectionPool(config);
        this.pool = await initPool.connect();
    }

}

