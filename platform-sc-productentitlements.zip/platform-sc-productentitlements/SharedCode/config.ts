import * as sql from 'mssql';
/**
 * The configuration handler
 */
export class Configuration {
    private _sql_username: string;
    private _sql_password: string;
    private _sql_server: string;
    private _sql_database: string;
    private _sb_uri: string;
    private _sb_channel: string;
    private _sb_conn: string;
    private _cache_key: string;
    private _cache_location: string;
    private _cache_port: number;
    private _cache_expiry: number;

    /**
     * constructor for the configuration class
     */
    constructor() {
        this._sql_database = process.env['db_database'];
        this._sql_server = process.env['db_server'];
        this._sql_username = process.env['db_username'];
        this._sql_password = process.env['db_password'];
        this._sb_uri = process.env['sb_uri'];
        this._sb_channel = process.env['sb_channel'];
        this._sb_conn = process.env.sb_conn;
        this._cache_location = process.env['cache_location'];
        this._cache_port = Number(process.env['cache_port']);
        this._cache_key = process.env['cache_key'];
        this._cache_expiry = Number(process.env['cache_expiry']);
    }

    /**
     * getter for cache default expiration time
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    /* istanbul ignore next  */
    get cache_expiry(): number {
        /* istanbul ignore else */
        if(!this._cache_expiry) {
            this._cache_expiry = Number(process.env['cache_expiry']);
        }
        return this._cache_expiry;
    }
    /**
     * getter for cache location
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    /* istanbul ignore next  */
    get cache_location(): string {
        /* istanbul ignore else */
        if(!this._cache_location) {
            this._cache_location = process.env['cache_location'];
        }
        return this._cache_location;
    }
    /**
     * getter for cache port
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    /* istanbul ignore next  */
    get cache_port(): number {
        /* istanbul ignore else */
        if(!this._cache_port) {
            this._cache_port = Number(process.env['cache_port']);
        }
        return this._cache_port;
    }
    /**
     * getter for cache key
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    /* istanbul ignore next  */
    get cache_key(): string {
        /* istanbul ignore else */
        if(!this._cache_key) {
            this._cache_key = process.env['cache_key'];
        }
        return this._cache_key;
    }
    /**
     * getter for sql server
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    get sql_server(): string {
        /* istanbul ignore else  */
        if(!this._sql_server) {
            this._sql_server = process.env['db_server'];
        }
        return this._sql_server;
    }
    /**
     * getter for database name
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    get sql_database(): string {
        /* istanbul ignore else  */
        if(!this._sql_database) {
            this._sql_database = process.env['db_database'];
        }
        return this._sql_database;
    }
    /**
     * database user
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    get sql_username(): string {
        /* istanbul ignore else  */
        if(!this._sql_username) {
            this._sql_username = process.env['db_username'];
        }
        return this._sql_username;
    }
    /**
     * database password
     *
     * @readonly
     * @type {string}
     * @memberof Configuration
     */
    get sql_password(): string {
        /* istanbul ignore else  */
        if(!this._sql_password) {
            this._sql_password = process.env['db_password'];
        }
        return this._sql_password;
    }
    /* istanbul ignore next  */
    get sb_channel(): string {
        if(!this._sb_channel) {
            this._sb_channel = process.env['sb_channel'];
        }
        return this._sb_channel;
    }
    /* istanbul ignore next  */
    get sb_uri(): string {
        if(!this._sb_uri) {
            this._sb_uri = process.env['sb_uri'];
        }
        return this._sb_uri;
    }
    get sb_conn(): string {
        if (!this._sb_conn) {
            this._sb_conn = process.env.sb_conn;
        }
        return this._sb_conn;
    }
    get db_config(): sql.config {
        return {
            user: this.sql_username,
            password: this.sql_password,
            server: this.sql_server,
            database: this.sql_database,
            options: {
                encrypt: true,
            }
        }
    }
}
