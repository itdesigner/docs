import {CompanyRepository} from './companyRepository';
import {EntitlementsRepository} from './entitlementsRepository';
import {LicenseRepository} from './licenseRepository';
import {ProductRepository} from './productRepository';

export {CompanyRepository, LicenseRepository, EntitlementsRepository, ProductRepository};
