
import * as sql from 'mssql';
import {Connection, Request, TYPES} from 'tedious';
import {Parameter} from '../../model';
import {IReadMany, IReadOne, IWrite} from '../interfaces/';

import { connect } from 'tls';

class BaseRepository<T> {
    public static pool: sql.ConnectionPool;

    public static async executeSPQuery(spName: string, parameters: Parameter[]) {
        await BaseRepository.pool;
        try {
            const req: sql.Request = BaseRepository.pool.request();
            /* istanbul ignore else  */
            if (parameters) {
                parameters.forEach((p) => {
                    req.input(p.name, p.type, p.value);
                });
            }
            const result = await req.execute(spName);
            /* istanbul ignore else  */
            if (result) {
                return result;
            } else {
                return undefined;
            }
        } catch (err) {
            /* istanbul ignore next  */
            return undefined;
        }
    }
    /* istanbul ignore next  */
    public static async executeSPCommand(spName: string, parameters: Parameter[]) {
        await BaseRepository.pool;
        try {
            const req: sql.Request = BaseRepository.pool.request();
            /* istanbul ignore else  */
            if (parameters) {
                parameters.forEach((p) => {
                    req.input(p.name, p.type, p.value);
                });
            }
            const result = await req.execute(spName);
            /* istanbul ignore else  */
            if (result) {
                /* istanbul ignore else  */
                if (result.returnValue === 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (err) {
            /* istanbul ignore next  */
            return undefined;
        }
    }
    /* istanbul ignore next  */
    public static async executeBulkInsert(table: sql.Table) {
        await BaseRepository.pool;
        try {
            if (table != null) {
                const req: sql.Request = BaseRepository.pool.request();
                const result = await req.bulk(table);
                if (result) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (err) {
            /* istanbul ignore next  */
            return undefined;
        }
    }

    constructor(pool: sql.ConnectionPool) {
        BaseRepository.pool = pool;
    }
}
export  {BaseRepository};
