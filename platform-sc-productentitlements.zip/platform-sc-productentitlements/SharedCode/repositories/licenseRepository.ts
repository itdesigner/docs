import * as sql from 'mssql';
import { IdentityKey, License, Parameter } from '../model';
import { LicenseCollection } from '../viewModels';
import {BaseRepository} from './base/BaseRepository';
import {IReadMany, IReadOne, IWrite} from './interfaces';

class LicenseRepository extends BaseRepository<License> implements IReadOne<License>, IReadMany<LicenseCollection>, IWrite<License> {

    constructor(pool: sql.ConnectionPool) {
        super(pool);
    }
    /* istanbul ignore next */
    public create(item: License): Promise<IdentityKey> {
        return new Promise<IdentityKey>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('companyID', sql.UniqueIdentifier, item.companyId));
            params.push(new Parameter('productId', sql.UniqueIdentifier, item.productId));
            params.push(new Parameter('linkUrl', sql.NVarChar(2000), item.linkUrl));
            params.push(new Parameter('linkImage', sql.NVarChar(2000), item.linkImage));
            params.push(new Parameter('endDate', sql.DateTime, new Date(item.endDate)));
            params.push(new Parameter('startDate', sql.DateTime, new Date(item.startDate)));
            params.push(new Parameter('deleted', sql.Bit, item.deleted));
            const promisedInsert = BaseRepository.executeSPQuery('usp_CompanyProducts_Insert', params);
            promisedInsert.then((result) => {
                if (result && result.recordsets && result.recordsets.length > 0) {
                    const recordset = result.recordsets[0];
                    /* istanbul ignore else  */
                    if (recordset && recordset.length > 0) {
                        resolve(recordset[0] as IdentityKey);
                    }
                } else {
                    const err: Error = new Error('insert failed');
                    reject(err);
                }
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /* istanbul ignore next  */
    public bulkCreate(items: License[]): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            if (items && items.length > 0) {
                const table = new sql.Table('LicensedVersions');
                table.columns.add('companyId', sql.UniqueIdentifier, {nullable: false});
                table.columns.add('productId', sql.UniqueIdentifier, {nullable: false});
                table.columns.add('linkUrl', sql.NVarChar(2000), {nullable: false});
                table.columns.add('linkImage', sql.NVarChar(2000), {nullable: false});
                table.columns.add('startDate', sql.DateTime, {nullable: false});
                table.columns.add('endDate', sql.DateTime, {nullable: false});
                table.columns.add('deleted', sql.Bit, {nullable: false});
                items.forEach((item) => {
                    table.rows.add(
                        item.companyId,
                        item.productId,
                        item.linkUrl,
                        item.linkImage,
                        new Date(item.startDate),
                        new Date(item.endDate), item.deleted,
                    );
                });

                const promisedBulkInsert = BaseRepository.executeBulkInsert(table);
                promisedBulkInsert.then((success) => {
                    resolve(success);
                })
                .catch((reason) => {
                    /* istanbul ignore next  */
                    reject(reason);
                });
            } else {
                reject('no licenses to insert');
            }
        });
    }
    /* istanbul ignore next */
    public update(id: string, item: License): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            params.push(new Parameter('companyID', sql.UniqueIdentifier, item.companyId));
            params.push(new Parameter('productId', sql.UniqueIdentifier, item.productId));
            params.push(new Parameter('linkUrl', sql.NVarChar(2000), item.linkUrl));
            params.push(new Parameter('linkImage', sql.NVarChar(2000), item.linkImage));
            params.push(new Parameter('endDate', sql.DateTime, new Date(item.endDate)));
            params.push(new Parameter('startDate', sql.DateTime, new Date(item.startDate)));
            params.push(new Parameter('deleted', sql.Bit, item.deleted));
            const promisedUpdate = BaseRepository.executeSPCommand('usp_CompanyProducts_Update', params);
            promisedUpdate.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /* istanbul ignore next */
    public delete(id: string, trueDelete?: boolean): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            let spName: string = 'usp_CompanyProducts_Delete';
            if (trueDelete) {
                spName = 'usp_CompanyProducts_FullDelete';
            }
            const promisedDelete = BaseRepository.executeSPCommand(spName, params);
            promisedDelete.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }

    public find(limit: number, skip: number, key: string): Promise<LicenseCollection> {
        return new Promise<LicenseCollection>((resolve, reject) => {
            let collection: LicenseCollection;
            const items: License[] = new Array<License>();
            const params: Parameter[] = new Array<Parameter>();
            if (limit) {
                params.push(new Parameter('limit', sql.Int, limit));
            }
            if (skip) {
                params.push(new Parameter('skip', sql.Int, skip));
            }
            params.push(new Parameter('companyId', sql.UniqueIdentifier, key));
            const promisedItems = BaseRepository.executeSPQuery('usp_CompanyProducts_SelectByCompanyId', params);
            promisedItems.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            const r = License.Load(row as License);
                            items.push(r);
                        });
                    });
                    collection = new LicenseCollection(items, items.length, result.returnValue);
                }
                resolve(collection);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    public findActive(limit: number, skip: number, key: string): Promise<LicenseCollection> {
        return new Promise<LicenseCollection>((resolve, reject) => {
            let collection: LicenseCollection;
            const items: License[] = new Array<License>();
            const params: Parameter[] = new Array<Parameter>();
            if (limit) {
                params.push(new Parameter('limit', sql.Int, limit));
            }
            if (skip) {
                params.push(new Parameter('skip', sql.Int, skip));
            }
            params.push(new Parameter('companyId', sql.UniqueIdentifier, key));
            const promisedItems = BaseRepository.executeSPQuery('usp_CompanyProducts_Active_SelectByCompanyId', params);
            promisedItems.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            const r = License.Load(row as License);
                            items.push(r);
                        });
                    });
                    collection = new LicenseCollection(items, items.length, result.returnValue);
                }
                resolve(collection);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }


    public findOne(id: string): Promise<License> {
        return new Promise<License>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            const promisedItems = BaseRepository.executeSPQuery('usp_CompanyProducts_SelectByEntitlementId', params);
            promisedItems.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets && result.recordsets.length > 0) {
                    const recordset = result.recordsets[0];
                    /* istanbul ignore else  */
                    if (recordset && recordset.length > 0) {
                        const r = License.Load(recordset[0] as License);
                        resolve(r);
                    }
                }
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
}

export {LicenseRepository};
