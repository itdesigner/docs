import * as sql from 'mssql';
import { IdentityKey, Parameter, Product} from '../model';
import {ProductCollection} from '../viewModels';
import {BaseRepository} from './base/BaseRepository';
import {IReadMany, IReadOne, IWrite} from './interfaces';

/**
 * The Product repository for the data stroe
 *
 * @class ProductRepository
 * @extends {BaseRepository<Product>}
 * @implements {IRead<Product>}
 * @implements {IWrite<Product>}
 */
class ProductRepository extends BaseRepository<Product> implements IReadOne<Product>, IReadMany<ProductCollection>, IWrite<Product> {

    /**
     * Creates an instance of ProductRepository.
     * @param {sql.ConnectionPool} pool
     * @memberof ProductRepository
     */
    constructor(pool: sql.ConnectionPool) {
        super(pool);
    }

    /**
     * Adds a new Product to the data store
     *
     * @param {Product} item
     * @returns {Promise<IdentityKey>}
     * @memberof ProductRepository
     */
    /* istanbul ignore next */
    public create(item: Product): Promise<IdentityKey> {
        return new Promise<IdentityKey>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('name', sql.NVarChar(1000), item.name));
            params.push(new Parameter('description', sql.NVarChar(), item.description));
            params.push(new Parameter('title', sql.NVarChar(1000), item.title));
            params.push(new Parameter('marketingUrl', sql.NVarChar(2000), item.marketingUrl));
            params.push(new Parameter('marketingImage', sql.NVarChar(2000), item.marketingImage));
            params.push(new Parameter('deleted', sql.Bit, item.deleted));
            const promisedInsert = BaseRepository.executeSPQuery('usp_Product_Insert', params);
            promisedInsert.then((result) => {
                if (result && result.recordsets && result.recordsets.length > 0) {
                    const recordset = result.recordsets[0];
                    /* istanbul ignore else  */
                    if (recordset && recordset.length > 0) {
                        resolve(recordset[0] as IdentityKey);
                    }
                } else {
                    const err: Error = new Error('insert failed');
                    reject(err);
                }
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Adds one or more products to the data store
     *
     * @param {Product[]} items
     * @returns {Promise<boolean>}
     * @memberof ProductRepository
     */
    /* istanbul ignore next  */
    public bulkCreate(items: Product[]): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            if (items && items.length > 0) {
                const table = new sql.Table('Product');
                table.columns.add('name', sql.NVarChar(1000), {nullable: false});
                table.columns.add('description', sql.NVarChar(4000), {nullable: false});
                table.columns.add('title', sql.NVarChar(1000), {nullable: false});
                table.columns.add('marketingUrl', sql.NVarChar(2000), {nullable: false});
                table.columns.add('marketingImage', sql.NVarChar(2000), {nullable: false});
                table.columns.add('deleted', sql.Bit, {nullable: false});
                items.forEach((item) => {
                    table.rows.add(item.name, item.description, item.title, item.marketingUrl, item.marketingImage, item.deleted);
                });
                const promisedBulkInsert = BaseRepository.executeBulkInsert(table);
                promisedBulkInsert.then((success) => {
                    resolve(success);
                })
                .catch((reason) => {
                    /* istanbul ignore next  */
                    reject(reason);
                });
            } else {
                reject('no products to insert');
            }
        });
    }
    /**
     * Updates an existing product in the datastore
     *
     * @param {string} id
     * @param {Product} item
     * @returns {Promise<boolean>}
     * @memberof ProductRepository
     */
    /* istanbul ignore next */
    public update(id: string, item: Product): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            params.push(new Parameter('description', sql.NVarChar(), item.description));
            params.push(new Parameter('name', sql.NVarChar(1000), item.name));
            params.push(new Parameter('title', sql.NVarChar(1000), item.title));
            params.push(new Parameter('marketingUrl', sql.NVarChar(2000), item.marketingUrl));
            params.push(new Parameter('marketingImage', sql.NVarChar(2000), item.marketingImage));
            params.push(new Parameter('deleted', sql.Bit, item.deleted));
            const promisedUpdate = BaseRepository.executeSPCommand('usp_Product_Update', params);
            promisedUpdate.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Deletes a product from the datastore (mark deleted)
     *
     * @param {string} id
     * @returns {Promise<boolean>}
     * @memberof ProductRepository
     */
    /* istanbul ignore next */
    public delete(id: string, trueDelete?: boolean): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            let spName: string = 'usp_Product_Delete';
            /* istanbul ignore else  */
            if (trueDelete == true) {
                spName = 'usp_Product_FullDelete';
            }
            const promisedDelete = BaseRepository.executeSPCommand(spName, params);
            promisedDelete.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * returns all products
     * @param limit items to return
     * @param skip  items to skip
     */
    public find(limit?: number, skip?: number): Promise<ProductCollection> {
        return new Promise<ProductCollection>((resolve, reject) => {
            let collection: ProductCollection;
            const items: Product[] = new Array<Product>();
            const params: Parameter[] = new Array<Parameter>();
            if (limit) {
                params.push(new Parameter('limit', sql.Int, limit));
            }
            if (skip) {
                params.push(new Parameter('skip', sql.Int, skip));
            }
            const promisedFind = BaseRepository.executeSPQuery('usp_Products_SelectAll', params);
            promisedFind.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            const r = Product.Load(row as Product);
                            items.push(r);
                        });
                    });
                    collection = new ProductCollection(items, items.length, result.returnValue);
                }
                resolve(collection);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * returns all active products
     * @param limit number of items to return
     * @param skip  number of items to skip
     */
    public findActive(limit?: number, skip?: number): Promise<ProductCollection> {
        return new Promise<ProductCollection>((resolve, reject) => {
            let collection: ProductCollection;
            const items: Product[] = new Array<Product>();
            const params: Parameter[] = new Array<Parameter>();
            if (limit) {
                params.push(new Parameter('limit', sql.Int, limit));
            }
            if (skip) {
                params.push(new Parameter('skip', sql.Int, skip));
            }
            const promisedFind = BaseRepository.executeSPQuery('usp_Products_Active_SelectAll', params);
            promisedFind.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            const r = Product.Load(row as Product);
                            items.push(r);
                        });
                    });
                    collection = new ProductCollection(items, items.length, result.returnValue);
                }
                resolve(collection);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * finds a single product based on a product id
     * @param id the product id
     */
    public findOne(id: string): Promise<Product> {
        return new Promise<Product>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            const promisedFind = BaseRepository.executeSPQuery('usp_Products_SelectById', params);
            promisedFind.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets && result.recordsets.length > 0) {
                    const recordset = result.recordsets[0];
                    /* istanbul ignore else  */
                    if (recordset && recordset.length > 0) {
                        const r = Product.Load(recordset[0] as Product);
                        resolve(r);
                    }
                }
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
}

export {ProductRepository};
