import * as sql from 'mssql';
import { Company, IdentityKey, Parameter } from '../model';
import { CompanyCollection } from '../viewModels';
import {BaseRepository} from './base/BaseRepository';
import {IReadMany, IReadOne, IWrite} from './interfaces';

/**
 * Company Datastore Repository
 *
 * @class CompanyRepository
 * @extends {BaseRepository<Company>}
 * @implements {IRead<Company>}
 * @implements {IWrite<Company>}
 */
class CompanyRepository extends BaseRepository<Company> implements IReadOne<Company>, IReadMany<CompanyCollection>, IWrite<Company> {

    /**
     * Creates an instance of CompanyRepository.
     * @param {sql.ConnectionPool} pool
     * @memberof CompanyRepository
     */
    constructor(pool: sql.ConnectionPool) {
        super(pool);
    }

    /**
     * Creates a company in the datastore
     *
     * @param {Company} item
     * @returns {Promise<IdentityKey>}
     * @memberof CompanyRepository
     */
    /* istanbul ignore next */
    public create(item: Company): Promise<IdentityKey> {
        return new Promise<IdentityKey>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('name', sql.NVarChar(2000), item.name));
            params.push(new Parameter('deleted', sql.Bit, item.deleted));
            const promisedInsert = BaseRepository.executeSPQuery('usp_Companies_Insert', params);
            promisedInsert.then((result) => {
                if (result && result.recordsets && result.recordsets.length > 0) {
                    const recordset = result.recordsets[0];
                    /* istanbul ignore else  */
                    if (recordset && recordset.length > 0) {
                        resolve(recordset[0] as IdentityKey);
                    }
                } else {
                    const err: Error = new Error('insert failed');
                    reject(err);
                }
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Bulk creates companies in the datastore
     *
     * @param {Company[]} items
     * @returns {Promise<boolean>}
     * @memberof CompanyRepository
     */
    /* istanbul ignore next  */
    public bulkCreate(items: Company[]): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            if (items && items.length > 0) {
                const table = new sql.Table('Companies');
                table.columns.add('name', sql.NVarChar(2000), {nullable: false, primary: false});
                table.columns.add('deleted', sql.Bit, {nullable: false, primary: false});
                items.forEach((item) => {
                    table.rows.add(item.name, item.deleted);
                });

                const promisedBulkInsert = BaseRepository.executeBulkInsert(table);
                promisedBulkInsert.then((success) => {
                    resolve(success);
                })
                .catch((reason) => {
                    /* istanbul ignore next  */
                    reject(reason);
                });
            } else {
                reject('no companies to insert');
            }
        });
    }
    /**
     * Updates a single company in the datastore
     *
     * @param {string} id
     * @param {Company} item
     * @returns {Promise<boolean>}
     * @memberof CompanyRepository
     */
    /* istanbul ignore next */
    public update(id: string, item: Company): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            params.push(new Parameter('deleted', sql.Bit, item.deleted));
            params.push(new Parameter('name', sql.NVarChar(2000), item.name));
            const promisedUpdate = BaseRepository.executeSPCommand('usp_Companies_Update', params);
            promisedUpdate.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Deletes a single company from the datastore
     *
     * @param {string} id
     * @returns {Promise<boolean>}
     * @memberof CompanyRepository
     */
    /* istanbul ignore next */
    public delete(id: string, trueDelete?: boolean): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            let spName: string = 'usp_Company_Delete';
            if (trueDelete) {
                spName = 'usp_Company_FullDelete';
            }
            const promisedDelete = BaseRepository.executeSPCommand(spName, params);
            promisedDelete.then((success) => {
                resolve(success);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Retrieves all companies from the datastore
     *
     * @returns {Promise<CompanyCollection>}
     * @memberof CompanyRepository
     */
    public find(limit?: number, skip?: number): Promise<CompanyCollection> {
        return new Promise<CompanyCollection>((resolve, reject) => {
            let collection: CompanyCollection;
            const items: Company[] = new Array<Company>();
            const params: Parameter[] = new Array<Parameter>();
            if (limit) {
                params.push(new Parameter('limit', sql.Int, limit));
            }
            if (skip) {
                params.push(new Parameter('skip', sql.Int, skip));
            }
            const promisedProjects = BaseRepository.executeSPQuery('usp_Companies_SelectAll', params);
            promisedProjects.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            const r = Company.Load(row as Company);
                            items.push(r);
                        });
                    });
                    collection = new CompanyCollection(items, items.length, result.returnValue);
                }
                resolve(collection);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Retrieves all non-deleted companies from the datastore
     *
     * @returns {Promise<CompanyCollection>}
     * @memberof CompanyRepository
     */
    public findActive(limit?: number, skip?: number): Promise<CompanyCollection> {
        return new Promise<CompanyCollection>((resolve, reject) => {
            let collection: CompanyCollection;
            const items: Company[] = new Array<Company>();
            const params: Parameter[] = new Array<Parameter>();
            if (limit) {
                params.push(new Parameter('limit', sql.Int, limit));
            }
            if (skip) {
                params.push(new Parameter('skip', sql.Int, skip));
            }
            const promisedProjects = BaseRepository.executeSPQuery('usp_Companies_Active_SelectAll', params);
            promisedProjects.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            const r = Company.Load(row as Company);
                            items.push(r);
                        });
                    });
                    collection = new CompanyCollection(items, items.length, result.returnValue);
                }
                resolve(collection);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
    /**
     * Retrieves a specific company from the datastore
     *
     * @param {string} id
     * @returns {Promise<Company>}
     * @memberof CompanyRepository
     */
    public findOne(id: string): Promise<Company> {
        return new Promise<Company>((resolve, reject) => {
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('id', sql.UniqueIdentifier, id));
            const promisedProjects = BaseRepository.executeSPQuery('usp_Companies_SelectById', params);
            promisedProjects.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets && result.recordsets.length > 0) {
                    const recordset = result.recordsets[0];
                    if (recordset && recordset.length > 0) {
                        const r = Company.Load(recordset[0] as Company);
                        resolve(r);
                    } else {
                        const err: Error = new Error('item not found');
                        reject(err);
                    }
                } else {
                    const err: Error = new Error('item not found');
                    reject(err);
                }
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
}

export {CompanyRepository};
