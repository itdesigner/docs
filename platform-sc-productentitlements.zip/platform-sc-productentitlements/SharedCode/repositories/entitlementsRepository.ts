import * as sql from 'mssql';
import {Company, License, Link, linkTypeEnum, Parameter, Product } from '../model';
import {ProductViewModel} from '../viewModels';
import { EntitlementViewModel } from '../viewModels/entitlements-vm';
import {BaseRepository} from './base/BaseRepository';

/**
 * The entitlements Entitlement repository
 */
class EntitlementsRepository extends BaseRepository<ProductViewModel> {

    /**
     * constructor for the Entitlements repository
     * @param pool connection pool
     */
    constructor(pool: sql.ConnectionPool) {
        super(pool);
    }

    /**
     * reteives all entitlements for a company
     * @param companyId company id
     * @param activeOnly whether tobring back only active (non-deleted) items
     */
    public getCompanyEntitlements(companyId: string, activeOnly: boolean): Promise<EntitlementViewModel> {
        return new Promise<EntitlementViewModel>((resolve, reject) => {
            let entitlements: EntitlementViewModel = EntitlementViewModel.Empty();
            const items: ProductViewModel[] = new Array<ProductViewModel>();
            const params: Parameter[] = new Array<Parameter>();
            params.push(new Parameter('companyId', sql.UniqueIdentifier, companyId));
            const spName: string = (activeOnly) ? 'usp_Entitlements_Active_SelectByCompanyId' : 'usp_Entitlements_SelectByCompanyId';
            const promisedEntitlements = BaseRepository.executeSPQuery(spName, params);
            promisedEntitlements.then((result) => {
                /* istanbul ignore else  */
                if (result && result.recordsets) {
                    let rs: number = 0;
                    result.recordsets.forEach((recordset) => {
                        recordset.forEach((row) => {
                            switch (rs) {
                                case 0:
                                    const c: Company = Company.Load(row as Company);
                                    entitlements = new EntitlementViewModel(c.id, c.name);
                                    break;
                                case 1:
                                    // all product data items
                                    const p: Product = Product.Load(row as Product);
                                    const l: Link = new Link('/products/' + p.id, 'self', linkTypeEnum.GET);
                                    p.addLink(l);
                                    items.push(new ProductViewModel(p));
                                    break;
                                case 2:
                                    // all licenses for the company
                                    const v = License.Load(row as License);
                                    const link: Link = new Link('/licenses/' + v.id, 'self', linkTypeEnum.GET);
                                    v.addLink(link);
                                    const parentProduct: ProductViewModel | undefined = items.find(function(item) {
                                        return item.id === v.productId;
                                    });
                                    if (parentProduct) {
                                        parentProduct.addLicense(v);
                                    }
                                    break;
                            }
                        });
                        rs++;
                    });
                }
                entitlements.addProducts(items);
                resolve(entitlements);
            })
            .catch((reason) => {
                /* istanbul ignore next  */
                reject(reason);
            });
        });
    }
}

export {EntitlementsRepository as EntitlementsRepository};
