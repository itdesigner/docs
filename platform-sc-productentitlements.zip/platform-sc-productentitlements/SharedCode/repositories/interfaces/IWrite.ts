import { IdentityKey } from '../../model';

export interface IWrite<T> {
    create(item: T): Promise<IdentityKey | boolean | undefined>;
    bulkCreate(items: T[]): Promise<IdentityKey[] | boolean | undefined>;
    update(id: number | string, item: T): Promise<boolean | undefined>;
    delete(id: number | string): Promise<boolean | undefined>;
}
