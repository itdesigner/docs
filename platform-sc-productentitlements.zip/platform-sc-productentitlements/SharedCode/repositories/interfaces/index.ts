import {IReadMany, IReadOne} from './IRead';
import {IWrite} from './IWrite';

export {IReadOne, IReadMany, IWrite};
