export interface IReadOne<T> {
    findOne(id: number | string): Promise<T | undefined>;
}
export interface IReadMany<T> {
    find(limit?: number, skip?: number, key?: number | string): Promise<T | undefined>;
    findActive(limit?: number, skip?: number, key?: number | string): Promise<T | undefined>;
}
